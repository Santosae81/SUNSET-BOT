const { createCanvas, loadImage } = require("@napi-rs/canvas");

const W = 1300;
const H = 600;
const VERMELHO = "#ed2630";
const VERDE = "#2ecc71";
const FONTE = '"DejaVu Sans", "Segoe UI", Roboto, Arial, sans-serif';

async function carregar(src) {
  if (!src) return null;
  try {
    if (Buffer.isBuffer(src)) return await loadImage(src);
    if (typeof src === "string" && /^https?:\/\//.test(src)) {
      const res = await fetch(src, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) return null;
      return await loadImage(Buffer.from(await res.arrayBuffer()));
    }
    return await loadImage(src);
  } catch {
    return null;
  }
}

function cobrir(ctx, img, x, y, w, h) {
  const r = Math.max(w / img.width, h / img.height);
  const dw = img.width * r;
  const dh = img.height * r;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

function rgba(hex, a) {
  const n = parseInt(hex.replace("#", ""), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}

function texto(ctx, str, x, y, { size, weight = "bold", color = "#fff", align = "center", max, glow, blur = 22 }) {
  ctx.font = `${weight} ${size}px ${FONTE}`;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = "alphabetic";
  if (max) {
    while (ctx.measureText(str).width > max && size > 14) {
      size -= 2;
      ctx.font = `${weight} ${size}px ${FONTE}`;
    }
    if (ctx.measureText(str).width > max) {
      while (str.length > 1 && ctx.measureText(str + "…").width > max) str = str.slice(0, -1);
      str = str.trimEnd() + "…";
    }
  }
  if (glow) {
    ctx.save();
    ctx.shadowColor = glow;
    ctx.shadowBlur = blur;
    ctx.fillText(str, x, y);
    ctx.shadowBlur = blur / 2;
    ctx.fillText(str, x, y);
    ctx.restore();
  }
  ctx.fillStyle = color;
  ctx.fillText(str, x, y);
}

function barraGlow(ctx, x, y, w, h, cor, blur = 18) {
  ctx.save();
  ctx.shadowColor = cor;
  ctx.shadowBlur = blur;
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, h / 2);
  ctx.fill();
  ctx.restore();
}

function luzLateral(ctx, lado, cor) {
  const x = lado === "esq" ? 0 : W;
  const g = ctx.createRadialGradient(x, H / 2, 0, x, H / 2, 640);
  g.addColorStop(0, rgba(cor, 0.38));
  g.addColorStop(0.5, rgba(cor, 0.12));
  g.addColorStop(1, rgba(cor, 0));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

function avatarPadrao(ctx, cx, cy, r) {
  ctx.fillStyle = "#c8cfe3";
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(cx, cy - r * 0.15, r * 0.32, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.85, r * 0.62, r * 0.55, 0, Math.PI, 0);
  ctx.fill();
}

function corPorcentagem(p) {
  if (p >= 75) return VERDE;
  if (p >= 50) return "#f1c40f";
  return VERMELHO;
}

async function gerarCanvasComandoErrado({ comandoErrado, sugestao, porcentagem = 0, foto, nome, fundo }) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");
  const pct = Math.max(0, Math.min(100, Number(porcentagem) || 0));

  // Fundo
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  const bg = await carregar(fundo);
  if (bg) cobrir(ctx, bg, 0, 0, W, H);
  ctx.fillStyle = "rgba(0,0,0,0.85)";
  ctx.fillRect(0, 0, W, H);

  // Luzes laterais
  const corDir = sugestao ? corPorcentagem(pct) : "#a7a9b0";
  luzLateral(ctx, "esq", VERMELHO);
  luzLateral(ctx, "dir", corDir);

  // Moldura em degradê com brilho
  const gm = ctx.createLinearGradient(0, 0, W, 0);
  gm.addColorStop(0, rgba(VERMELHO, 0.9));
  gm.addColorStop(0.5, "rgba(255,255,255,0.12)");
  gm.addColorStop(1, rgba(corDir, 0.9));
  ctx.save();
  ctx.strokeStyle = gm;
  ctx.lineWidth = 2;
  ctx.shadowColor = "rgba(255,255,255,0.35)";
  ctx.shadowBlur = 10;
  ctx.strokeRect(16, 16, W - 32, H - 32);
  ctx.restore();

  texto(ctx, "COMANDO NÃO ENCONTRADO", W / 2, 80, { size: 30, color: "#fff", glow: "rgba(255,255,255,0.7)", blur: 14, max: 900 });

  // Centro: foto
  const cx = W / 2;
  const cy = 300;
  const r = 120;
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();
  const av = await carregar(foto);
  if (av) cobrir(ctx, av, cx - r, cy - r, r * 2, r * 2);
  else avatarPadrao(ctx, cx, cy, r);
  ctx.restore();
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r + 3, 0, Math.PI * 2);
  ctx.strokeStyle = VERMELHO;
  ctx.lineWidth = 6;
  ctx.shadowColor = VERMELHO;
  ctx.shadowBlur = 35;
  ctx.stroke();
  ctx.shadowBlur = 15;
  ctx.stroke();
  ctx.restore();
  if (nome) texto(ctx, String(nome).toUpperCase(), cx, cy + r + 50, { size: 22, glow: "rgba(255,255,255,0.5)", blur: 8, max: 300 });

  // Esquerda: comando errado
  const lx = 195;
  texto(ctx, "VOCÊ DIGITOU", lx, 245, { size: 20, weight: "normal", color: "#a7a9b0" });
  texto(ctx, comandoErrado, lx, 315, { size: 54, color: "#ff3b45", glow: VERMELHO, blur: 26, max: 330 });
  barraGlow(ctx, lx - 120, 335, 240, 8, VERMELHO);
  texto(ctx, "NÃO EXISTE", lx + 12, 385, { size: 20, weight: "normal", color: "rgba(237,38,48,0.9)", glow: VERMELHO, blur: 8 });
  // X desenhado (a fonte não tem o símbolo ✕)
  ctx.save();
  ctx.strokeStyle = VERMELHO;
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  ctx.shadowColor = VERMELHO;
  ctx.shadowBlur = 8;
  ctx.font = `normal 20px ${FONTE}`;
  const tw = ctx.measureText("NÃO EXISTE").width;
  const xx = lx + 12 - tw / 2 - 20;
  ctx.beginPath();
  ctx.moveTo(xx - 6, 372); ctx.lineTo(xx + 6, 384);
  ctx.moveTo(xx + 6, 372); ctx.lineTo(xx - 6, 384);
  ctx.stroke();
  ctx.restore();

  // Direita: sugestão + porcentagem
  const rx = W - 195;
  if (sugestao) {
    const cor = corPorcentagem(pct);
    texto(ctx, "QUE TAL USAR", rx, 245, { size: 20, weight: "normal", color: "#a7a9b0" });
    texto(ctx, sugestao, rx, 315, { size: 54, color: cor, glow: cor, blur: 26, max: 330 });

    const bw = 240;
    const bx = rx - bw / 2;
    ctx.fillStyle = "rgba(255,255,255,0.1)";
    ctx.beginPath();
    ctx.roundRect(bx, 335, bw, 8, 4);
    ctx.fill();
    barraGlow(ctx, bx, 335, Math.max(8, (bw * pct) / 100), 8, cor);

    texto(ctx, `${pct.toFixed(1).replace(/\.0$/, "")}%`, rx, 395, { size: 38, color: cor, glow: cor, blur: 20 });
    texto(ctx, "DE SEMELHANÇA", rx, 425, { size: 18, weight: "normal", color: "#a7a9b0" });
  } else {
    texto(ctx, "SEM SUGESTÃO", rx, 300, { size: 34, color: "#a7a9b0", glow: "#a7a9b0", blur: 14, max: 330 });
    texto(ctx, "nenhum comando parecido", rx, 335, { size: 18, weight: "normal", color: "#a7a9b0" });
  }

  // Rodapé
  texto(ctx, "DIGITE O MENU PARA VER TODOS OS COMANDOS", W / 2, 548, { size: 20, weight: "normal", color: "rgba(255,255,255,0.45)" });

  return canvas.toBuffer("image/png");
}

module.exports = { gerarCanvasComandoErrado };
