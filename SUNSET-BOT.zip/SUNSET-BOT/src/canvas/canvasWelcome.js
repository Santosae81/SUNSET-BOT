// Canvas de boas-vindas (tema vermelho) gerado localmente com @napi-rs/canvas.
const { createCanvas, loadImage } = require("@napi-rs/canvas");

const W = 1300;
const H = 600;
const VERMELHO = "#ed2630";
const FONTE = '"DejaVu Sans", "Segoe UI", Roboto, Arial, sans-serif';

async function carregar(src) {
  if (!src) return null;
  try {
    if (Buffer.isBuffer(src)) return await loadImage(src);
    if (typeof src === "object" && src.url) src = src.url;
    if (typeof src === "string" && /^https?:\/\//.test(src)) {
      const res = await fetch(src, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) return null;
      return await loadImage(Buffer.from(await res.arrayBuffer()));
    }
    return await loadImage(src);
  } catch {
    return null;
  }
}

// Desenha a imagem preenchendo todo o espaço (cover).
function cobrir(ctx, img, x, y, w, h) {
  const r = Math.max(w / img.width, h / img.height);
  const dw = img.width * r;
  const dh = img.height * r;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

function texto(ctx, str, x, y, { size, weight = "bold", color = "#fff", align = "center", max }) {
  ctx.font = `${weight} ${size}px ${FONTE}`;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = "alphabetic";
  if (max) {
    while (ctx.measureText(str).width > max && size > 12) {
      size -= 2;
      ctx.font = `${weight} ${size}px ${FONTE}`;
    }
  }
  ctx.fillText(str, x, y);
}

function avatarPadrao(ctx, cx, cy, r) {
  ctx.fillStyle = "#c8cfe3";
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(cx, cy - r * 0.15, r * 0.32, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(cx, cy + r * 0.85, r * 0.62, r * 0.55, 0, Math.PI, 0);
  ctx.fill();
}

async function gerarCanvasWelcome({ fundo, foto, nome, titulo = "NEW MEMBER", grande = "BEM-VINDO AO GRUPO" }) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  // Fundo
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  const bg = await carregar(fundo);
  if (bg) cobrir(ctx, bg, 0, 0, W, H);
  ctx.fillStyle = "rgba(0,0,0,0.82)";
  ctx.fillRect(0, 0, W, H);

  // Moldura fina
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 2;
  ctx.strokeRect(20, 20, W - 40, H - 40);

  // Crédito
  texto(ctx, "© YutaAPI's 2026", 36, 55, { size: 16, weight: "normal", color: "rgba(255,255,255,0.4)", align: "left" });

  // Avatar
  const cx = 160;
  const cy = 300;
  const r = 103;
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();
  const av = await carregar(foto);
  if (av) cobrir(ctx, av, cx - r, cy - r, r * 2, r * 2);
  else avatarPadrao(ctx, cx, cy, r);
  ctx.restore();
  ctx.beginPath();
  ctx.arc(cx, cy, r + 2, 0, Math.PI * 2);
  ctx.strokeStyle = VERMELHO;
  ctx.lineWidth = 5;
  ctx.stroke();
  texto(ctx, String(nome || "").toUpperCase(), cx, 450, { size: 20, max: 260 });

  // Título + barra vermelha
  texto(ctx, titulo, 650, 250, { size: 58 });
  ctx.fillStyle = VERMELHO;
  ctx.beginPath();
  ctx.roundRect(465, 259, 370, 10, 5);
  ctx.fill();

  texto(ctx, "WELCOME MESSAGE", 650, 320, { size: 20, weight: "normal", color: "#a7a9b0" });
  texto(ctx, grande, 650, 402, { size: 52, max: 680 });
  texto(ctx, "SEJA BEM-VINDO(A) AO SERVIDOR", 650, 460, { size: 22, weight: "normal", color: "#a7a9b0" });

  // Rodapé direito
  texto(ctx, "ENTRE NO SERVIDOR COM", 850, 500, { size: 25, align: "left" });
  texto(ctx, "MODERAÇÃO.", 850, 535, { size: 25, align: "left", color: VERMELHO });

  return canvas.toBuffer("image/png");
}

module.exports = { gerarCanvasWelcome };
