const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const W = 1830, H = 600;
const COR = "#ef4444";
const BOT_NOME = "Kira";
const FONTE = "CardFont";

let fonteOk = false;
function carregarFontes() {
  if (fonteOk) return;
  fonteOk = true;
  const pastas = [
    path.join(process.cwd(), "assets", "fonts"),
    path.join(process.env.PREFIX || "/usr", "share", "fonts"),
    "/usr/share/fonts", "/system/fonts"
  ];
  const achar = (er) => {
    const pilha = [...pastas];
    while (pilha.length) {
      const d = pilha.shift();
      let itens = [];
      try { itens = fs.readdirSync(d, { withFileTypes: true }); } catch { continue; }
      for (const it of itens) {
        const p = path.join(d, it.name);
        if (it.isDirectory()) pilha.push(p);
        else if (er.test(it.name)) return p;
      }
    }
    return null;
  };
  const normal = achar(/^(DejaVuSans|Roboto-Regular|RobotoStatic-Regular|NotoSans-Regular|DroidSans)\.ttf$/i);
  const negrito = achar(/^(DejaVuSans-Bold|Roboto-Bold|RobotoStatic-Bold|NotoSans-Bold|DroidSans-Bold)\.ttf$/i);
  try { if (normal) GlobalFonts.registerFromPath(normal, FONTE); } catch {}
  try { if (negrito) GlobalFonts.registerFromPath(negrito, FONTE); } catch {}
  if (!normal && !negrito) console.log("[playCard] Nenhuma fonte encontrada! Coloque um .ttf em assets/fonts/ (ex: DejaVuSans.ttf e DejaVuSans-Bold.ttf).");
}
const f = (peso, px) => `${peso} ${px}px "${FONTE}", sans-serif`;

async function baixarImagem(url) {
  const r = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 });
  return loadImage(Buffer.from(r.data));
}

function cover(ctx, img, x, y, w, h) {
  const s = Math.max(w / img.width, h / img.height);
  const dw = img.width * s, dh = img.height * s;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

function cortar(ctx, texto, maxW) {
  let t = String(texto);
  if (ctx.measureText(t).width <= maxW) return t;
  while (t.length > 1 && ctx.measureText(t + "…").width > maxW) t = t.slice(0, -1);
  return t.trimEnd() + "…";
}

function paraSeg(d) {
  const p = String(d || "").split(":").map(Number);
  if (p.some(isNaN) || !p.length) return 0;
  return p.reduce((a, n) => a * 60 + n, 0);
}
function fmt(seg) {
  const h = Math.floor(seg / 3600), m = Math.floor((seg % 3600) / 60), s = Math.floor(seg % 60);
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

function retArred(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

async function gerarCardPlay({ titulo, canal, duracao, thumb }) {
  carregarFontes();
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");
  const img = await baixarImagem(thumb);

  const mini = createCanvas(40, 13);
  cover(mini.getContext("2d"), img, 0, 0, 40, 13);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(mini, 0, 0, W, H);
  ctx.fillStyle = "rgba(0,0,0,0.78)";
  ctx.fillRect(0, 0, W, H);

  ctx.strokeStyle = "rgba(255,255,255,0.08)"; ctx.lineWidth = 2;
  ctx.strokeRect(20, 20, W - 40, H - 40);

  ctx.textAlign = "left"; ctx.fillStyle = "rgba(255,255,255,0.3)";
  ctx.font = f("normal", 19);
  ctx.fillText(`© ${BOT_NOME} ${new Date().getFullYear()}`, 36, 55);

  const cx = 220, cy = 300, r = 150;
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.clip();
  cover(ctx, img, cx - r, cy - r, r * 2, r * 2);
  ctx.restore();
  ctx.lineWidth = 5; ctx.strokeStyle = COR;
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();

  ctx.textAlign = "center"; ctx.fillStyle = "#fff";
  ctx.font = f("bold", 30);
  ctx.fillText(cortar(ctx, canal, 380), cx, 520);

  const mx = 915;
  ctx.font = f("bold", 68);
  ctx.fillText("NEW MUSIC", mx, 210);

  const total = paraSeg(duracao);
  const atual = total ? Math.floor(total * 0.3) : 0;
  const bx = 655, bw = 520, by = 265, bh = 10;
  ctx.fillStyle = "rgba(255,255,255,0.09)";
  retArred(ctx, bx, by, bw, bh, 5); ctx.fill();
  ctx.fillStyle = COR;
  retArred(ctx, bx, by, bw * 0.3, bh, 5); ctx.fill();

  ctx.font = f("normal", 21); ctx.fillStyle = "#cfcfcf";
  ctx.textAlign = "left";  ctx.fillText(total ? fmt(atual) : "0:00", bx, 249);
  ctx.textAlign = "right"; ctx.fillText(total ? fmt(total) : "--:--", bx + bw, 249);

  ctx.textAlign = "center"; ctx.fillStyle = "#9a9a9a";
  ctx.font = f("normal", 23);
  ctx.fillText("NOW PLAYING", mx, 320);

  ctx.fillStyle = "#fff";
  let tam = 34;
  ctx.font = f("bold", tam);
  while (tam > 24 && ctx.measureText(titulo).width > 920) { tam -= 2; ctx.font = f("bold", tam); }
  ctx.fillText(cortar(ctx, titulo, 920), mx, 410);

  ctx.fillStyle = "#9a9a9a"; ctx.font = f("normal", 27);
  ctx.fillText(cortar(ctx, canal, 600), mx, 469);

  ctx.textAlign = "left"; ctx.font = f("bold", 28);
  ctx.fillStyle = "#fff"; ctx.fillText("ESCUTE A MÚSICA COM", 1180, 499);
  ctx.fillStyle = COR;    ctx.fillText("MODERAÇÃO.", 1180, 534);

  return canvas.toBuffer("image/png");
}

module.exports = { gerarCardPlay };
