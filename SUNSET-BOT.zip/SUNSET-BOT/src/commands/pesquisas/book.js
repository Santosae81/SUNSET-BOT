module.exports = {
nome: ["book"],
executar: async ({
args,
axios,
caption,
from,
getBuffer,
mess,
quoted,
reply,
selo,
  prefix,
  command,
kira
}) => {

if (args.length == 0)
return reply(`📖 \`BOOK\`\n\n> 🙇‍♂️ Digite o nome do livro! Ex: ${prefix}${command} Nome do Livro`);
try {
const takeBook = await axios.get(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(q)}&langRestrict=pt`);
const getBook = await axios.get(`${takeBook.data.items[0].selfLink}`);
var bookImage = await getBuffer(getBook.data.volumeInfo.imageLinks.thumbnail);
await kira.sendMessage(from, {image: bookImage, caption: mess.searchBooks(getBook)}, {quoted: selo});
} catch (error) {
reply(mess.error());
}
}
};
