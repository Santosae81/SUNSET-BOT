module.exports = {
nome: ["screenshot"],
executar: async ({
q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`📸 \`SCREENSHOT\`\n\n> 🙇‍♂️ Envie a URL do site! Ex: ${prefix}${command} https://google.com`);
reagir(from, "🖼️");
try {
await kira.sendMessage(from, { image: { url: `${API_kira}/screenshot?url=${q}&apitoken=${KEY_kira}` } }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei essa imagem... tenta de novo!"); }
}
};
