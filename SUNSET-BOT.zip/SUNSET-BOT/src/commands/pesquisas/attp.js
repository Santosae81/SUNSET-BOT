// /attp <texto>: figurinha animada com texto (rota /api/stickers/attp da Yuta)
const { yutaSticker, enviarFigurinha } = require("../../utils/yutaApi");

module.exports = {
nome: ["attp", "attp2"],
executar: async (ctx) => {
const { from, q, reagir, reply, prefix, command, API_kira, KEY_kira } = ctx;
const texto = String(q || "").trim();
if (!texto) return reply(`🎨 \`ATTP\`\n\n> 🙇‍♂️ Envie um texto! Ex: ${prefix}${command} duck`);
try { reagir(from, "✅️"); } catch {}
try {
const buf = await yutaSticker(API_kira, KEY_kira, "attp", { text: texto });
await enviarFigurinha(ctx, from, buf);
} catch (err) {
console.log("[attp] falhou:", err?.message || err);
try { reagir(from, "❌"); } catch {}
reply("❌️ `ATTP`\n> Não consegui gerar a figurinha! Confira o token da API (pode ter expirado ou batido o limite diário).");
}
}
};
