const axios = require('axios');
const cooldowns = new Map();

const HEADERS = {
"accept": "application/json, text/javascript, */*; q=0.01",
"accept-language": "en-US,en;q=0.9",
"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
"x-requested-with": "XMLHttpRequest",
"x-pinterest-appstate": "active",
"x-pinterest-pws-handler": "www/[username]/[slug].js",
"referer": "https://www.pinterest.com/",
"origin": "https://www.pinterest.com"
};

function normalize(url) {
return url.replace(/236x/g, "736x")
};

async function pinterestSearch(query, bookmark) {
try {
const options = { query: query, scope: "pins" };
if (bookmark) options.bookmarks = [bookmark];
const url = `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=/search/pins/?q=${encodeURIComponent(query)}&data=${encodeURIComponent(JSON.stringify({
options,
context: {}
}))}`;
const res = await axios.get(url, { headers: HEADERS })
const pins = res.data.resource_response.data.results
const urls = []
for (const pin of pins) {
if (pin.images?.orig?.url) {
urls.push(normalize(pin.images.orig.url))
}
};
let proximo = res.data.resource?.options?.bookmarks?.[0] || res.data.resource_response?.bookmark || null;
if (proximo === "-end-") proximo = null;
return {
ok: true,
count: urls.length,
urls,
bookmark: proximo
};
} catch (e) {
return {
ok: false,
msg: e.message,
urls: [],
bookmark: null
}
}
};

// histórico por chat + termo: guarda as imagens já enviadas e a página (bookmark) da busca,
// assim cada "NOVA BUSCA" traz fotos diferentes das anteriores.
const historico = new Map();
const HIST_TTL = 30 * 60 * 1000;

function getHist(key) {
const agora = Date.now();
for (const [k, v] of historico) {
if (agora - v.ts > HIST_TTL) historico.delete(k);
}
let h = historico.get(key);
if (!h) {
h = { seen: new Set(), bookmark: null, ts: agora };
historico.set(key, h);
}
h.ts = agora;
return h;
}

// pega até `qtd` imagens inéditas; avança de página se precisar; recomeça se esgotar
async function buscarIneditas(q, h, qtd) {
const novas = [];
const naLista = new Set();
const coletar = (urls) => {
for (const u of urls) {
if (!h.seen.has(u) && !naLista.has(u)) { naLista.add(u); novas.push(u); }
}
};
for (let i = 0; i < 3 && novas.length < qtd; i++) {
const r = await pinterestSearch(q, h.bookmark);
if (!r.ok) { if (!novas.length && i === 0) return r; break; }
coletar(r.urls);
h.bookmark = r.bookmark;
if (!h.bookmark) break;
}
if (!novas.length) {
// esgotou tudo: recomeça do zero
h.seen.clear();
h.bookmark = null;
const r = await pinterestSearch(q, null);
if (!r.ok) return r;
coletar(r.urls);
h.bookmark = r.bookmark;
}
return { ok: true, urls: novas };
}

module.exports = {
nome: ["pinterest","pin"],
executar: async ({
from,
prefix,
command,
q,
quoted,
reagir,
reply,
selo,
kira
}) => {

try {
if (!q) return reply(`📌 \`PINTEREST\`\n\n> 🙇‍♂️ Digite o que deseja buscar! Ex: ${prefix}${command} paisagens vintage`);
await reagir(from, '💖');
const hist = getHist(`${from}|${String(q).trim().toLowerCase()}`);
const resulty = await buscarIneditas(q, hist, 10);
const urlsy = resulty.urls || [];
if (urlsy.length > 0) {
// embaralha e pega até 10 candidatas; o bot descarta as que não forem jpeg/png (máx. 10 cards)
const lista = [...urlsy].sort(() => Math.random() - 0.5).slice(0, 10);
for (const u of lista) hist.seen.add(u);
const cards = lista.map((img) => ({
title: `📌 \`PINTEREST\`\n\n> 🙇‍♂️ ${q}`,
footer: "Sunset SYSTEM",
image: { url: img },
buttons: [
{
name: "cta_url",
buttonParamsJson: JSON.stringify({ display_text: "ABRIR IMAGEM", url: img, merchant_url: img })
},
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({ display_text: "🔄 NOVA BUSCA", id: `${prefix + command} ${q}` })
}
]
}));
try {
await kira.sendMessage(from, {
interactiveMessage: {
title: "\u200e",
footer: "Sunset SYSTEM",
carousel: cards
}
}, { quoted: selo });
} catch (err) {
console.log("[pinterest] carrossel falhou, mandando imagem única:", err?.message || err);
await kira.sendMessage(from, {
interactiveMessage: {
title: `📌 \`PINTEREST\`\n\n> 🙇‍♂️ ${q}`,
footer: `*Sunset SYSTEM*`,
buttons: [
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({ display_text: "⏩ PRÓXIMO", id: `${prefix + command} ${q}` })
}
],
image: { url: lista[0] }
}
}, { quoted: selo });
}
} else {
reply("❌️ `PINTEREST`\n> Nenhuma imagem encontrada!");
}
} catch (error) {
console.log(error);
reply("❌️ `PINTEREST`\n> Erro ao processar a busca, tenta de novo!");
}
}
};
