// Logos da Yuta APIs: /api/logos/<rota>?text=<texto>
// A lista fica em settings/logos-yuta.json -> ["comando", "rota da API", "TÍTULO"]
// Pra adicionar uma logo nova, é só incluir mais uma linha lá (o menu se atualiza sozinho).
const axios = require("axios");
const LOGOS = require("../../../settings/logos-yuta.json");

const POR_COMANDO = {};
for (const [comando, rota, titulo] of LOGOS) POR_COMANDO[comando.toLowerCase()] = { rota, titulo };

// nome do parâmetro de texto na API (tenta um por vez até algum funcionar)
const PARAMETROS = ["text", "texto", "nome"];

async function baixarImagem(urlApi, tag) {
  const inicio = Date.now();
  const r = await axios.get(urlApi, {
    responseType: "arraybuffer",
    timeout: 90000,
    maxContentLength: 30 * 1024 * 1024,
    validateStatus: () => true,
  });
  const tipo = String(r.headers["content-type"] || "").toLowerCase();
  const dados = Buffer.from(r.data);
  console.log(`[${tag}] resposta: HTTP ${r.status} | ${tipo || "sem tipo"} | ${dados.length} bytes | ${((Date.now() - inicio) / 1000).toFixed(1)}s`);
  if (r.status !== 200 || tipo.includes("json") || tipo.includes("text") || dados.length < 500) {
    let msg = "";
    try { const j = JSON.parse(dados.toString("utf8")); msg = j.msg || j.message || j.error || ""; } catch {}
    throw new Error(`HTTP ${r.status} (${tipo || "sem tipo"}) ${msg}`.trim());
  }
  return dados;
}

module.exports = {
  nome: LOGOS.map((l) => l[0]),
  executar: async ({ kira, from, reagir, reply, selo, q, prefix, command, API_kira, KEY_kira }) => {
    const cmd = String(command || "").toLowerCase();
    const logo = POR_COMANDO[cmd];
    if (!logo) return;

    const texto = (q || "").trim();
    if (!texto) {
      return reply(`🎨 \`${logo.titulo}\`\n\n> 🙇‍♂️ Envie um texto! Ex: ${prefix}${cmd} Marks`);
    }

    reagir(from, "🎨");
    const base = String(API_kira || "").replace(/\/+$/, "");
    for (const param of PARAMETROS) {
      const urlApi = `${base}/api/logos/${logo.rota}?${param}=${encodeURIComponent(texto)}&apitoken=${encodeURIComponent(KEY_kira)}`;
      try {
        console.log(`[logos] pedindo: api/logos/${logo.rota} (${param})`);
        const imagem = await baixarImagem(urlApi, "logos");
        await kira.sendMessage(from, {
          image: imagem,
          caption: `🎨 \`${logo.titulo}\`\n\n> 🙇‍♂️ Sua logo ficou pronta!`
        }, { quoted: selo });
        return;
      } catch (err) {
        console.log(`[logos] falhou (${logo.rota}, ${param}):`, err?.message || err);
      }
    }

    reagir(from, "❌");
    return reply(`⚠️ \`${logo.titulo}\`\n\n> 🙇‍♂️ Não consegui gerar a logo! Confira o token da API (pode ter expirado ou batido o limite diário).`);
  }
};
