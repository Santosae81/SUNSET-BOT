module.exports = {
nome: ["ytsearch","pesquisa-ytb"],
executar: async ({
prefix,
command,
mess,
q,
reply,
yts
}) => {

if (q.trim().length < 4) return reply(`▶️ \`YT SEARCH\`\n\n> 🙇‍♂️ Digite o que deseja pesquisar! Ex: ${prefix}${command} naruto`);
try {
const searchUrl = await yts(q);
const ABC = searchUrl.videos;
RST = ABC.map((v, index) =>
`*${index + 1}.* Título: *${v.title || "Não encontrado"}*\n• Descrição: *${v.description || "Não encontrado"}*\n• Duração: *${v.duration.timestamp || "Não encontrado"}*\n• Link: *${v.url || "Não encontrado"}*`
).join("\n–\n");
reply(`Hmph! Achei os resultados pra você... n-não se acostume, baka!\n> YouTube Search:\n–\n` + RST);
} catch (error) {
return reply(mess.error());
}
}
};
