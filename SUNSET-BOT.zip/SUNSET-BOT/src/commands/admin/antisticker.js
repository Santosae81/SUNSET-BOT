module.exports = {
nome: ["antisticker"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiSticker,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiSticker) {
dataGp[0].antisticker = false;
setGp(dataGp);
reply("❌ `ANTI STICKER`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antisticker = true;
setGp(dataGp);
reply("✅ `ANTI STICKER`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
