// /ban2 @usuario: BAN FAKE (zueira). Avisa que a pessoa tem 10 segundos pra se despedir,
// faz a contagem regressiva editando a mesma mensagem e depois revela que era brincadeira.
// NÃO remove ninguém do grupo.

const SEGUNDOS = 10;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

module.exports = {
nome: ["ban2"],
executar: async ({
prefix,
command,
from,
isGroup,
isGroupAdmins,
SoDono,
menc_os2,
reply,
reagir,
selo,
kira
}) => {

if (!isGroup) return reply("⚠️ `BAN2`\n\n> 🙇‍♂️ Este comando só pode ser usado em grupos!");
if (!isGroupAdmins && !SoDono) return reply("⚠️ `BAN2`\n\n> 🙇‍♂️ Apenas administradores podem usar este comando!");
if (!menc_os2) return reply(`🔨 \`BAN2\`\n\n> 🙇‍♂️ Marque a mensagem ou o @ do usuário! Ex: ${prefix}${command} @usuario`);

const alvo = menc_os2;
const nome = String(alvo).split("@")[0].split(":")[0];
const mentions = [alvo];

const textoContagem = (seg) =>
`🔨 \`BAN2\`\n\n> 🚨 @${nome} vai ser banido do grupo!\n> 🫡 Você tem *${seg} ${seg === 1 ? "segundo" : "segundos"}* pra se despedir...`;

try { reagir(from, "🔨"); } catch {}

try {
const enviada = await kira.sendMessage(from, {
text: textoContagem(SEGUNDOS),
mentions
}, { quoted: selo });

const key = enviada?.key;

// contagem regressiva editando a própria mensagem (se a edição falhar, segue em frente)
for (let seg = SEGUNDOS - 1; seg >= 1; seg--) {
await sleep(1000);
if (!key) continue;
try {
await kira.sendMessage(from, { text: textoContagem(seg), mentions, edit: key });
} catch (e) {
console.log("[ban2] erro ao editar contagem:", e?.message || e);
}
}

await sleep(1000);

await kira.sendMessage(from, {
text: `😂 \`BAN2\`\n\n> Zueira! Era só brincadeira, @${nome} continua no grupo. 🤝`,
mentions
});
} catch (e) {
console.log("[ban2] erro:", e?.message || e);
reply("❌️ `BAN2`\n> Deu erro ao executar o comando!");
}
}
};
