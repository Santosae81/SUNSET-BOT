module.exports = {
nome: ["modo18"],
executar: async ({
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  isModo18,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isModo18) {
dataGp[0].porno= false;
setGp(dataGp);
reply("❌ `MODO +18`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].porno = true;
setGp(dataGp);
reply("✅ `MODO +18`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
