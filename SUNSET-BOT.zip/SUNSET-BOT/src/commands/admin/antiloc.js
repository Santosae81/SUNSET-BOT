module.exports = {
nome: ["antiloc"],
executar: async ({
  Antiloc,
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (Antiloc) {
dataGp[0].antiloc = false;
setGp(dataGp);
reply("❌ `ANTI LOC`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antiloc = true;
setGp(dataGp);
reply("✅ `ANTI LOC`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
