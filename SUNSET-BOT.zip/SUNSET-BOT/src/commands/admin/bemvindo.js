module.exports = {
  nome: ["bemvindo", "welcome"],
  executar: async ({
    SoDono,
    args,
    dataGp,
    isGroup,
    isGroupAdmins,
    mess,
    prefix,
    reply,
    setGp,
    kira,
    from,
    selo
  }) => {
    if (!isGroup) return reply(mess.onlyGroup());
    if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());

    if (!dataGp[0].wellcome) dataGp[0].wellcome = [{}];
    if (!dataGp[0].wellcome[0]) dataGp[0].wellcome[0] = {};

    const config = dataGp[0].wellcome[0];

    if (!config.modos) {
      config.modos = {
        imagem: config.bemvindo1 === true,
        texto: false,
        audio: false,
        video: false,
        sticker: false
      };
    }
    if (config.modos.sticker === undefined) config.modos.sticker = false;

    const modos = [
      { id: "texto", emoji: "📄", cmd: "ᴛᴇxᴛᴏ", nome: "ᴛᴇxᴛᴏ", title: "📄 Bem-vindo em texto" },
      { id: "imagem", emoji: "🖼", cmd: "ғᴏᴛᴏ", nome: "ғᴏᴛᴏ", title: "🖼 Bem-vindo com foto" },
      { id: "audio", emoji: "🎵", cmd: "ᴀᴜᴅɪᴏ", nome: "ᴀᴜᴅɪᴏ", title: "🎵 Bem-vindo em áudio" },
      { id: "video", emoji: "🎬", cmd: "ᴠɪᴅᴇᴏ", nome: "ᴠɪᴅᴇᴏ", title: "🎬 Bem-vindo em vídeo" },
      { id: "sticker", emoji: "🧩", cmd: "sᴛɪᴄᴋᴇʀ", nome: "sᴛɪᴄᴋᴇʀ", title: "🧩 Bem-vindo em sticker" }
    ];

    const apelidos = {
      texto: "texto", foto: "imagem", imagem: "imagem", audio: "audio", áudio: "audio",
      video: "video", vídeo: "video", sticker: "sticker", figurinha: "sticker", fig: "sticker"
    };

    const escolhido = String(args?.[0] || "").toLowerCase();

    if (escolhido === "0") {
      for (const modo of modos) config.modos[modo.id] = false;
      config.bemvindo1 = false;
      setGp(dataGp);
      return reply("❌ `BEM-VINDO`\n\n> 🙇‍♂️ Sistema de boas-vindas desativado neste grupo!");
    }

    const id = apelidos[escolhido];

    if (id) {
      const ativo = config.modos[id] === true;
      const desligados = modos.filter(m => m.id !== id && config.modos[m.id] === true);

      for (const modo of modos) config.modos[modo.id] = false;
      config.modos[id] = !ativo;
      config.bemvindo1 = config.modos.imagem;
      setGp(dataGp);

      const nome = modos.find(m => m.id === id).title;
      let txt =
        `${!ativo ? "✅" : "❌"} \`BEM-VINDO\`\n\n` +
        `> 🙇‍♂️ ${nome} ${!ativo ? "ativado" : "desativado"} com sucesso neste grupo!`;

      if (!ativo && desligados.length) {
        txt += `\n> 🔄 Desativei: ${desligados.map(m => m.title).join(", ")}`;
      }

      return reply(txt);
    }

    const ativos = modos.filter(m => config.modos[m.id] === true);
    const status = ativos.length ? "✅ ᴀᴛɪᴠᴀᴅᴏ" : "❌ ᴅᴇsᴀᴛɪᴠᴀᴅᴏ";
    const modoAtual = ativos.length ? ativos.map(m => m.nome).join(", ") : "ɴᴇɴʜᴜᴍ";

    const rows = modos.map(m => ({
      title: `${config.modos[m.id] ? "🟢" : "🔴"} ${m.emoji} ${m.nome}`,
      description: config.modos[m.id] ? "ATIVADO" : "DESATIVADO",
      id: `${prefix}bemvindo ${m.id}`
    }));

    rows.push({
      title: "❌ ᴅᴇsᴀᴛɪᴠᴀʀ ᴛᴜᴅᴏ",
      description: "Desliga o sistema de boas-vindas",
      id: `${prefix}bemvindo 0`
    });

    const txt =
      "⚠️ `𝗕𝗘𝗠𝗩𝗜𝗡𝗗𝗢`\n" +
      "> *👋 sɪsᴛᴇᴍᴀ ᴅᴇ ʙᴏᴀs-ᴠɪɴᴅᴀs*\n\n" +
      `*📊 sᴛᴀᴛᴜs:* ${status}\n` +
      `*⚙️ ᴍᴏᴅᴏ:* ${modoAtual}`;

    await kira.sendMessage(from, {
      interactiveMessage: {
        title: txt,
        footer: "🟢 Ativado | 🔴 Desativado",
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "ESCOLHER MODO",
              sections: [{ title: "ᴍᴏᴅᴏs ᴅɪsᴘᴏɴɪ́ᴠᴇɪs", rows }]
            })
          }
        ]
      }
    }, { quoted: selo });
  }
};
