// /inativos: mostra os 20 primeiros membros com 0 mensagens (citados na lista)
// e um botão "REMOVER INATIVOS" (executa /removerinativos), tudo numa mensagem só.

const moment = require("moment-timezone");
const atividade = require("../../utils/atividade");

module.exports = {
nome: ["inativos", "inativo"],
executar: async ({
from,
prefix,
isGroup,
isGroupAdmins,
isBotGroupAdmins,
reply,
reagir,
selo,
logos,
botNumber,
numerodn,
kira
}) => {

if (!isGroup) return reply("⚠️ `INATIVOS`\n\n> 🙇‍♂️ Este comando só pode ser usado em grupos!");
if (!isGroupAdmins) return reply("⚠️ `INATIVOS`\n\n> 🙇‍♂️ Apenas administradores podem usar este comando!");

if (typeof reagir === "function") { try { reagir(from, "🗑"); } catch {} }

let meta;
try {
meta = await kira.groupMetadata(from);
} catch (e) {
console.log("[inativos] erro ao pegar membros:", e?.message || e);
return reply("❌️ `INATIVOS`\n> Não consegui pegar a lista de membros!");
}

const ignorar = new Set([atividade.chave(botNumber), atividade.chave(numerodn)]);
const inativos = [];
for (const p of meta.participants || []) {
const jid = p.phoneNumber || p.id;
if (!jid) continue;
if (p.admin === "admin" || p.admin === "superadmin") continue;
if (ignorar.has(atividade.chave(jid))) continue;
if (atividade.contagem(from, jid) === 0) inativos.push(jid);
}

const desde = moment.tz(atividade.desde(from), "America/Sao_Paulo").format("DD/MM/YYYY HH:mm");

if (!inativos.length) {
return reply(`✅ \`INATIVOS\`\n\n> 🙇‍♂️ Nenhum inativo! Todos os membros já mandaram mensagem.\n> 📅 Contando desde: ${desde}`);
}

const top = inativos.slice(0, 20);
let lista = `🗑 \`INATIVOS\`\n\n> 👥 Sem nenhuma mensagem: ${inativos.length}\n> 📅 Contando desde: ${desde}\n\n`;
top.forEach((jid, i) => { lista += `${i + 1}. @${atividade.chave(jid)}\n`; });
if (inativos.length > top.length) lista += `\n... e mais ${inativos.length - top.length}`;

// mensagem única: lista (com menções) + botão, sem foto
const botao = {
name: "quick_reply",
buttonParamsJson: JSON.stringify({ display_text: "🗑 REMOVER INATIVOS", id: `${prefix}removerinativos` })
};

try {
await kira.sendMessage(from, {
interactiveMessage: {
title: lista,
footer: "SUNSET",
buttons: [botao],
mentions: top
}
}, { quoted: selo });
} catch (err) {
console.log("[inativos] card falhou, mandando texto:", err?.message || err);
await kira.sendMessage(from, { text: lista + `\n\n> Use ${prefix}removerinativos para remover.`, mentions: top }, { quoted: selo });
}
}
};
