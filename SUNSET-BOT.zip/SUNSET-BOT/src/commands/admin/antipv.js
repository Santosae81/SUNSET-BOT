module.exports = {
nome: ["antipv"],
executar: async ({
SoDono,
isAntiPv,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isAntiPv) {
nescessario.antipv = true;
setNes(nescessario);
reply("✅ `ANTI PV`\n\n> 🙇‍♂️ Ativado com sucesso!");
} else if (isAntiPv) {
nescessario.antipv = false;
setNes(nescessario);
reply("❌ `ANTI PV`\n\n> 🙇‍♂️ Desativado com sucesso!");
}
}
};
