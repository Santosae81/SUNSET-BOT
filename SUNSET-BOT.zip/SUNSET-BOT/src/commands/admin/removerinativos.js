// /removerinativos (botão do /inativos): fecha o grupo, remove só quem tem 0 mensagens
// (nunca admins, dono ou o próprio bot), reabre o grupo e manda o relatório.

const atividade = require("../../utils/atividade");

// segurança: só remove se a contagem existe há pelo menos X horas (evita expulsar todo mundo
// logo depois de instalar). Coloque 0 para desativar.
const MIN_HORAS = 24;

const emAndamento = new Set();

module.exports = {
nome: ["removerinativos", "reminativos", "rminativos"],
executar: async ({
from,
isGroup,
isGroupAdmins,
isBotGroupAdmins,
reply,
reagir,
selo,
sleep,
botNumber,
numerodn,
kira
}) => {

if (!isGroup) return reply("⚠️ `REMOVER INATIVOS`\n\n> 🙇‍♂️ Este comando só pode ser usado em grupos!");
if (!isGroupAdmins) return reply("⚠️ `REMOVER INATIVOS`\n\n> 🙇‍♂️ Apenas administradores podem usar este comando!");
if (!isBotGroupAdmins) return reply("⚠️ `REMOVER INATIVOS`\n\n> 🙇‍♂️ Eu preciso ser administradora para executar este comando!");
if (emAndamento.has(from)) return reply("⚠️ `REMOVER INATIVOS`\n\n> 🙇‍♂️ Já estou removendo os inativos deste grupo!");

const horas = (Date.now() - atividade.desde(from)) / 3600000;
if (MIN_HORAS > 0 && horas < MIN_HORAS) {
const falta = Math.ceil(MIN_HORAS - horas);
return reply(`⚠️ \`REMOVER INATIVOS\`\n\n> 🙇‍♂️ Ainda estou contando as mensagens deste grupo. Aguarde mais ~${falta}h para remover com segurança.`);
}

emAndamento.add(from);
let fechou = false;
let estavaAberto = false;
try {
if (typeof reagir === "function") { try { reagir(from, "🗑"); } catch {} }

const meta = await kira.groupMetadata(from);
estavaAberto = meta.announce !== true;

const ignorar = new Set([atividade.chave(botNumber), atividade.chave(numerodn)]);
const alvos = [];
for (const p of meta.participants || []) {
const jid = p.phoneNumber || p.id;
if (!jid) continue;
if (p.admin === "admin" || p.admin === "superadmin") continue;
if (ignorar.has(atividade.chave(jid))) continue;
if (atividade.contagem(from, jid) === 0) alvos.push(jid);
}

if (!alvos.length) {
return reply("✅ `REMOVER INATIVOS`\n\n> 🙇‍♂️ Não há inativos para remover!");
}

// 1) fecha o grupo
if (estavaAberto) {
await kira.groupSettingUpdate(from, "announcement");
fechou = true;
}
await reply(`🔒 \`REMOVER INATIVOS\`\n\n> 🙇‍♂️ Grupo fechado. Removendo ${alvos.length} inativos...`);

// 2) remove só os inativos, em lotes pequenos
const removidos = [];
for (let i = 0; i < alvos.length; i += 5) {
const lote = alvos.slice(i, i + 5);
try {
await kira.groupParticipantsUpdate(from, lote, "remove");
removidos.push(...lote);
lote.forEach((j) => atividade.remover(from, j));
} catch (e) {
console.log("[removerinativos] falha no lote:", e?.message || e);
}
if (typeof sleep === "function") await sleep(1500);
}

// 3) reabre o grupo
if (fechou) {
try { await kira.groupSettingUpdate(from, "not_announcement"); fechou = false; }
catch (e) { console.log("[removerinativos] erro ao reabrir:", e?.message || e); }
}

let txt = `✅ \`INATIVOS REMOVIDOS\`\n\n> 🗑 Removidos: ${removidos.length}/${alvos.length}\n> 🔓 Grupo ${estavaAberto && !fechou ? "reaberto" : "mantido como estava"}\n\n`;
removidos.slice(0, 40).forEach((j, i) => { txt += `${i + 1}. @${atividade.chave(j)}\n`; });
if (removidos.length > 40) txt += `\n... e mais ${removidos.length - 40}`;
if (removidos.length < alvos.length) txt += `\n\n⚠️ ${alvos.length - removidos.length} não puderam ser removidos.`;
await kira.sendMessage(from, { text: txt, mentions: removidos.slice(0, 40) }, { quoted: selo });
} catch (e) {
console.log("[removerinativos] erro:", e?.message || e);
reply("❌️ `REMOVER INATIVOS`\n> Deu erro ao remover os inativos!");
} finally {
// garante que o grupo nunca fica fechado por causa de erro
if (fechou) { try { await kira.groupSettingUpdate(from, "not_announcement"); } catch {} }
emAndamento.delete(from);
}
}
};
