module.exports = {
nome: ["anticatalogo","anticatalg"],
executar: async ({
  args,
  command,
  dataGp,
  isAnticatalogo,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAnticatalogo) {
dataGp[0].anticatalogo = false;
setGp(dataGp);
reply("❌ `ANTI CATÁLOGO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].anticatalogo = true;
setGp(dataGp);
reply("✅ `ANTI CATÁLOGO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
