module.exports = {
nome: ["antiaudio"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiAudio,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiAudio) {
dataGp[0].antiaudio = false;
setGp(dataGp);
reply("❌ `ANTI ÁUDIO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antiaudio = true;
setGp(dataGp);
reply("✅ `ANTI ÁUDIO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
