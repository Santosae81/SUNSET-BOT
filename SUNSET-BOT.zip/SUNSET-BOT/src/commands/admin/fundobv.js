const { isUrl } = require("../../utils/helpers");
const { pedir, salvarFundo, salvarLink, removerFundo, sucesso } = require("../../handlers/fundoBv");

module.exports = {
  nome: ["fundobv", "fundobemvindo", "fundowelcome"],
  executar: async ({
    SoDono,
    args,
    q,
    dataGp,
    setGp,
    from,
    sender,
    info,
    isGroup,
    isGroupAdmins,
    mess,
    reply,
    reagir,
    downloadMediaMessage
  }) => {
    if (!isGroup) return reply(mess.onlyGroup());
    if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());

    const opcao = String(args?.[0] || "").toLowerCase();

    // /fundobv padrao -> volta pro fundo padrão do bot
    if (["padrao", "padrão", "reset", "remover"].includes(opcao)) {
      await removerFundo({ dataGp, setGp, from });
      return reply("✅ `FUNDO BEM-VINDO`\n\n> 🙇‍♂️ Voltei pro fundo padrão do bot neste grupo!");
    }

    // /fundobv https://link-da-imagem.png
    if (q && isUrl(q.trim())) {
      await salvarLink({ url: q.trim(), dataGp, setGp });
      return reply("✅ `FUNDO BEM-VINDO`\n\n> 🙇‍♂️ Fundo atualizado com sucesso neste grupo!\n> 🔗 " + q.trim());
    }

    // Imagem enviada com a legenda do comando OU imagem respondida
    const msg = info.message || {};
    const quoted =
      msg.extendedTextMessage?.contextInfo?.quotedMessage ||
      msg.imageMessage?.contextInfo?.quotedMessage;
    const midiaObj = msg.imageMessage || quoted?.imageMessage;

    if (midiaObj) {
      try {
        await reagir(from, "⏳");
        const buffer = await downloadMediaMessage({ message: { imageMessage: midiaObj } }, "buffer");
        if (!buffer || !buffer.length) throw new Error("download vazio");
        const r = await salvarFundo({ buffer, mimetype: midiaObj.mimetype, from, dataGp, setGp });
        await reagir(from, "✅");
        return reply(sucesso(r.host));
      } catch (e) {
        console.log("[fundobv]", e);
        await reagir(from, "❌");
        return reply("⚠️ `FUNDO BEM-VINDO`\n\n> 🙇‍♂️ Não consegui salvar o fundo! Tenta de novo.");
      }
    }

    // Sem imagem: pede a foto e fica esperando só esse admin por 3 minutos
    pedir(from, sender);
    return reply(
      "🖼️ `FUNDO BEM-VINDO`\n\n" +
      "> 🙇‍♂️ Envie a foto do novo fundo agora! (vale por 3 minutos)\n" +
      "> 🔒 Só aceito a foto de admin.\n" +
      "> ❌ Pra cancelar, mande: cancelar"
    );
  }
};
