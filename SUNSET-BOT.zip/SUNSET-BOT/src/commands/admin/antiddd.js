module.exports = {
nome: ["antiddd","anti_ddd","anti-ddd"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiDDD,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return await reply(mess.onlyGroup());
if (!isGroupAdmins) return await reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return await reply(mess.onlyBotAdmin());
if (isAntiDDD) {
dataGp[0].ANTI_DDD.active = false;
setGp(dataGp);
await reply("❌ `ANTI DDD`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].ANTI_DDD.active = true;
setGp(dataGp);
await reply("✅ `ANTI DDD`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
