module.exports = {
nome: ["autorepo"],
executar: async ({
  args,
  command,
  dataGp,
  isAutorepo,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAutorepo) {
dataGp[0].autoresposta = false;
setGp(dataGp);
reply("❌ `AUTO RESPOSTA`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].autoresposta = true;
setGp(dataGp);
reply("✅ `AUTO RESPOSTA`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
