module.exports = {
nome: ["so_adm"],
executar: async ({
  So_Adm,
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (So_Adm) {
dataGp[0].soadm = false;
setGp(dataGp);
reply("❌ `SÓ ADMINS`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].soadm = true;
setGp(dataGp);
reply("✅ `SÓ ADMINS`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
