module.exports = {
nome: ["antilinkgp"],
executar: async ({
  args,
  command,
  dataGp,
  isAntilinkgp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntilinkgp) {
dataGp[0].antilinkgp = false;
setGp(dataGp);
reply("❌ `ANTI LINK GRUPO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antilinkgp = true;
setGp(dataGp);
reply("✅ `ANTI LINK GRUPO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
