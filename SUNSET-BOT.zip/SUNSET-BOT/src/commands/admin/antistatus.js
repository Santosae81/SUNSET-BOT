module.exports = {
nome: ["antistatus"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiStatus,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiStatus) {
dataGp[0].antistatus = false;
setGp(dataGp);
reply("❌ `ANTI STATUS`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antistatus = true;
setGp(dataGp);
reply("✅ `ANTI STATUS`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
