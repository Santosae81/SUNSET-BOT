module.exports = {
nome: ["antiligar","antiligacao","antiligação"],
executar: async ({
SoDono,
isAnticall,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isAnticall) {
nescessario.anticall = true;
setNes(nescessario);
reply("✅ `ANTI LIGAÇÃO`\n\n> 🙇‍♂️ Ativado com sucesso! Quem me ligar será bloqueado");
} else if (isAnticall) {
nescessario.anticall = false;
setNes(nescessario);
reply("❌ `ANTI LIGAÇÃO`\n\n> 🙇‍♂️ Desativado com sucesso!");
}
}
};
