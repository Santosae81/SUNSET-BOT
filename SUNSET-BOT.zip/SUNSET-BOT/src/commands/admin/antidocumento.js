module.exports = {
nome: ["antidocumento","antidoc"],
executar: async ({
  Antidoc,
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (Antidoc) {
dataGp[0].antidoc = false;
setGp(dataGp);
reply("❌ `ANTI DOCUMENTO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antidoc = true;
setGp(dataGp);
reply("✅ `ANTI DOCUMENTO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
