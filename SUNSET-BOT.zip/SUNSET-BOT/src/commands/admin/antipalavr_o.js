module.exports = {
nome: ["antipalavrão","antipalavrao","antipalavra"],
executar: async ({
args,
command,
dataGp,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
isPalavrao,
mess,
prefix,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isPalavrao) {
dataGp[0].antipalavrao.active = false;
setGp(dataGp);
reply("❌ `ANTI PALAVRÃO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antipalavrao.active = true;
setGp(dataGp);
reply("✅ `ANTI PALAVRÃO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
