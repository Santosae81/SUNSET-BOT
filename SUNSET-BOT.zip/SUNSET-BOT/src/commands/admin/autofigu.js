module.exports = {
nome: ["autofigu","autosticker"],
executar: async ({
dataGp,
isAutofigu,
IsAutofigu,
autofigu,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAutofigu || IsAutofigu || autofigu) {
dataGp[0].autosticker.isAutofigu = false;
dataGp[0].autosticker.IsAutofigu = false;
dataGp[0].autosticker.autofigu = false;
setGp(dataGp);
reply("❌ `AUTO FIGURINHAS`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].autosticker.isAutofigu = true;
dataGp[0].autosticker.IsAutofigu = true;
dataGp[0].autosticker.autofigu = true;
setGp(dataGp);
reply("✅ `AUTO FIGURINHAS`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
