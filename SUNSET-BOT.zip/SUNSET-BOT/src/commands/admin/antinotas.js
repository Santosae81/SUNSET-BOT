module.exports = {
nome: ["antinotas"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiNotas,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiNotas) {
dataGp[0].antinotas = false;
setGp(dataGp);
reply("❌ `ANTI NOTAS`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antinotas = true;
setGp(dataGp);
reply("✅ `ANTI NOTAS`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
