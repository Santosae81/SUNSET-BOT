module.exports = {
nome: ["antiflood"],
executar: async ({
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess
}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (dataGp[0].anti_flood) {
dataGp[0].anti_flood = false;
setGp(dataGp);
reply("❌ `ANTI FLOOD`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].anti_flood = true;
setGp(dataGp);
reply("✅ `ANTI FLOOD`\n\n> 🙇‍♂️ Ativado! Quem floodar ou marcar todo mundo de uma vez será banido na hora");
}
}
};
