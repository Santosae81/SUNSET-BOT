module.exports = {
nome: ["antispam"],
executar: async ({
  kira,
  from,
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (dataGp[0].antispam?.active) {
dataGp[0].antispam.active = false;
setGp(dataGp);
reply("❌ `ANTI SPAM`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
if (!dataGp[0].antispam) dataGp[0].antispam = {};
dataGp[0].antispam.active = true;
setGp(dataGp);
reply("✅ `ANTI SPAM`\n\n> 🙇‍♂️ Ativado! Spam neste grupo será barrado");
}
}
};
