module.exports = {
nome: ["multiprefixo","multiprefix"],
executar: async ({
SoDono,
dataGp,
isGroup,
isGroupAdmins,
isMultiP,
mess,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isMultiP) {
dataGp[0].multiprefix = true;
setGp(dataGp);
reply("✅ `MULTIPREFIXO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
if (isMultiP) {
dataGp[0].multiprefix = false;
setGp(dataGp);
reply("❌ `MULTIPREFIXO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
}
}
};
