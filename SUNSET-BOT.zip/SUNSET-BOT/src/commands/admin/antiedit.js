module.exports = {
nome: ["antiedit", "antieditgrupo"],
executar: async ({
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess
}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (dataGp[0].anti_edit_grupo) {
dataGp[0].anti_edit_grupo = false;
setGp(dataGp);
reply("❌ `ANTI EDIT`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].anti_edit_grupo = true;
setGp(dataGp);
reply("✅ `ANTI EDIT`\n\n> 🙇‍♂️ Ativado! Quem não for admin e mudar nome, foto, descrição ou configurações do grupo será banido na hora");
}
}
};
