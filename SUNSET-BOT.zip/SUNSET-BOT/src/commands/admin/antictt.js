module.exports = {
nome: ["antictt","anticontato"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiCtt,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiCtt) {
dataGp[0].antictt = false;
setGp(dataGp);
reply("❌ `ANTI CONTATO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antictt = true;
setGp(dataGp);
reply("✅ `ANTI CONTATO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
