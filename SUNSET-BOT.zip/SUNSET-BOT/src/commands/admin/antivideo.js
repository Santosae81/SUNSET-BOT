module.exports = {
nome: ["antivideo"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiVid,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiVid) {
dataGp[0].antivideo = false;
setGp(dataGp);
reply("❌ `ANTI VÍDEO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antivideo = true;
setGp(dataGp);
reply("✅ `ANTI VÍDEO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
