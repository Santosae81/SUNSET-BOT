module.exports = {
nome: ["antifake"],
executar: async ({
  SoDono,
  args,
  command,
  dataGp,
  isAntifake,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntifake) {
dataGp[0].antifake = false;
setGp(dataGp);
reply("❌ `ANTI FAKE`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antifake = true;
setGp(dataGp);
reply("✅ `ANTI FAKE`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
