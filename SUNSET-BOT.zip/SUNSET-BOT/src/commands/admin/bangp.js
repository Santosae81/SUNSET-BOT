// /bangp: liga/desliga o banimento do grupo (usa 1x pra banir, 2x pra desbanir)
module.exports = {
nome: ["bangp"],
executar: async ({
SoDono,
dataGp,
isBanchat,
isGroup,
mess,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!SoDono) return reply(mess.onlyOwner());

if (!isBanchat) {
dataGp[0].bangp = true;
setGp(dataGp);
reply("🚫 `GRUPO BANIDO`\n\n> 🙇‍♂️ Grupo banido com sucesso!");
} else {
dataGp[0].bangp = false;
setGp(dataGp);
reply("✅ `GRUPO DESBANIDO`\n\n> 🙇‍♂️ Grupo desbanido com sucesso!");
}
}
};
