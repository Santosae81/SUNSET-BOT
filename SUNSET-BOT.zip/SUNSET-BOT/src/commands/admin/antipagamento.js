module.exports = {
nome: ["antipagamento"],
executar: async ({
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  isPayment,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isPayment) {
dataGp[0].antipagamento = false;
setGp(dataGp);
reply("❌ `ANTI PAGAMENTO`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antipagamento = true;
setGp(dataGp);
reply("✅ `ANTI PAGAMENTO`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
