module.exports = {
nome: ["modobrincadeira","modobrincadeiras"],
executar: async ({
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  isModobn,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isModobn) {
dataGp[0].jogos = false;
setGp(dataGp);
reply("❌ `MODO BRINCADEIRA`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].jogos = true;
setGp(dataGp);
reply("✅ `MODO BRINCADEIRA`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
