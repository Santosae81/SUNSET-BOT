module.exports = {
nome: ["antiimg"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiImg,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiImg) {
dataGp[0].antiimg = false;
setGp(dataGp);
reply("❌ `ANTI IMAGEM`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antiimg = true;
setGp(dataGp);
reply("✅ `ANTI IMAGEM`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
