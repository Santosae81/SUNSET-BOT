module.exports = {
nome: ["autodown"],
executar: async ({
  args,
  command,
  dataGp,
  isAutodown,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAutodown) {
dataGp[0].autodown = false;
setGp(dataGp);
reply("❌ `AUTODOWN`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].autodown = true;
setGp(dataGp);
reply("✅ `AUTODOWN`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
