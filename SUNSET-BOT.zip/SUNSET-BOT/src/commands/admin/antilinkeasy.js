module.exports = {
nome: ["antilinkeasy"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiLinkEasy,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (isAntiLinkEasy) {
dataGp[0].antilinkeasy = false;
setGp(dataGp);
reply("❌ `ANTI LINK EASY`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].antilinkeasy = true;
setGp(dataGp);
reply("✅ `ANTI LINK EASY`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
