module.exports = {
nome: ["alugar", "lojinha", "loja"],
executar: async ({ from, fs, logos, mess, reagir, reply, selo, prefix, kira, NomeDoBot, pushname }) => {

try {
await reagir(from, "🛒");
if (!fs.existsSync("./settings/planos.json")) return reply("Hmph! A loja ainda não tem planos cadastrados... Avisa o meu dono pra criar o arquivo *settings/planos.json*, baka!");
const planos = JSON.parse(fs.readFileSync("./settings/planos.json", "utf8"));
if (!Array.isArray(planos) || !planos.length) return reply("Hmph! Nenhum plano disponível no momento... Volta mais tarde, tá?!");

const rows = planos.map((p) => ({
title: p.nome,
description: `Hmph! Valor: R$ ${Number(p.preco).toFixed(2)} | Duração: ${p.dias} Dias`,
id: `${prefix}pix ${p.preco}`
}));

const corpoLoja = [
`🏪 *${NomeDoBot} STORE*`,
` `,
`Hmph! Olá ${pushname}, aqui estão nossos planos disponíveis para aluguel...`,
`Selecione o plano desejado no botão abaixo para gerar o seu PIX de pagamento, tá?! Não é como se eu quisesse seu dinheiro... bom, tanto faz!`,
` `,
`🚀 *Ativação instantânea após o pagamento!*`,
` `,
`〔 🛒 NOSSA LOJA 〕`
].join("\n");

await kira.sendMessage(from, { interactiveMessage: {
title: corpoLoja,
footer: "*Sunset SYSTEM*",
buttons: [
{ name: "single_select", buttonParamsJson: JSON.stringify({ title: "📋 VER PLANOS", sections: [{ title: "PLANOS DISPONÍVEIS", rows }] }) },
{ name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "📞 SUPORTE", url: "https://wa.me/556681147547" }) }
],
image: { url: logos.img }
} }, { quoted: selo });
} catch (e) {
console.log(e);
reply(mess.error());
}
}
};
