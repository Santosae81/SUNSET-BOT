module.exports = {
nome: ["visualizarmsg"],
executar: async ({
SoDono,
isVisualizar,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isVisualizar) {
nescessario.visualizarmsg = true;
setNes(nescessario);
reply("✅ `VER MENSAGENS`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo e nos privados!");
} else if (isVisualizar) {
nescessario.visualizarmsg = false;
setNes(nescessario);
reply("❌ `VER MENSAGENS`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo e nos privados!");
}
}
};
