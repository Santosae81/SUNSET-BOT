const fs = require("fs");
const path = require("path");
const { isUrl } = require("../../utils/helpers");

// Pasta onde a foto do menu fica salva: Bot-Base/arquivos/media
const MEDIA_DIR = path.join(__dirname, "..", "..", "..", "arquivos", "media");
const EXT = { "image/jpeg": "jpg", "image/jpg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" };

module.exports = {
nome: ["fotomenu"],
executar: async ({
SoDono,
downloadMediaMessage,
from,
info,
isnit,
logos,
mess,
q,
reagir,
reply,
saveJSON
}) => {

if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner());
try {
await reagir(from, "✅️");

// Caso 1: link direto (ex: !fotomenu https://...)
if (q && isUrl(q)) {
const url = q.trim();
logos.img = url;
saveJSON("./settings/logos.json", logos);
return reply(`✅ \`FOTO MENU \`\n\n> 🖼️ Foto do menu atualizada com sucesso!\n> 🔗 ${url}`);
}

// Caso 2: imagem enviada com a legenda do comando OU imagem respondida
const msg = info.message || {};
const quoted =
msg.extendedTextMessage?.contextInfo?.quotedMessage ||
msg.imageMessage?.contextInfo?.quotedMessage;
const midiaObj = msg.imageMessage || quoted?.imageMessage;
if (!midiaObj) return reply("⚠️ `FOTO MENU `\n\n> 🙇‍♂️ Não consegui coletar a imagem! Envie um link, uma imagem com a legenda do comando ou responda uma imagem.");

// Mesmo formato que o setfotogp usa (funciona com o zapo-js)
const buffer = await downloadMediaMessage({ message: { imageMessage: midiaObj } }, "buffer");
if (!buffer || !buffer.length) throw new Error("Download da imagem veio vazio");

// Salva em arquivos/media com nome novo (o cache do menu é por caminho, então não pode repetir)
fs.mkdirSync(MEDIA_DIR, { recursive: true });
const ext = EXT[midiaObj.mimetype] || "jpg";
const destino = path.join(MEDIA_DIR, `menu_${Date.now()}.${ext}`);
fs.writeFileSync(destino, buffer);

// Apaga a foto antiga se ela também estava em arquivos/media
const antiga = logos.img;
if (antiga && !isUrl(antiga) && path.resolve(antiga).startsWith(MEDIA_DIR) && fs.existsSync(antiga)) {
try { fs.unlinkSync(antiga); } catch {}
}

logos.img = destino;
saveJSON("./settings/logos.json", logos);
reply(`✅ \`FOTO MENU \`\n\n> 🖼️ Foto do menu atualizada com sucesso!\n> 📁 ${path.relative(process.cwd(), destino)}`);
} catch (e) {
console.log(e);
await reagir(from, "❌");
reply("⚠️ `FOTO MENU `\n\n> 🙇‍♂️ Erro ao tentar atualizar a foto do menu!");
}
}
};
