module.exports = {
  nome: ["novolink", "nlink", "redefinir", "revlink", "revlinkgp"],
  executar: async ({
    from,
    isBotGroupAdmins,
    isGroup,
    isGroupAdmins,
    reply,
    reagir,
    selo,
    sleep,
    logos,
    kira
  }) => {

    if (!isGroup) return reply("⚠️ `NOVO LINK`\n\n> 🙇‍♂️ Este comando só pode ser usado em grupos!");
    if (!isGroupAdmins) return reply("⚠️ `NOVO LINK`\n\n> 🙇‍♂️ Apenas administradores podem usar este comando!");
    if (!isBotGroupAdmins) return reply("⚠️ `NOVO LINK`\n\n> 🙇‍♂️ Eu preciso ser administradora para executar este comando!");

    if (typeof reagir === "function") {
      try { reagir(from, "⚙️"); } catch {}
    }

    let link;
    try {
      await kira.groupRevokeInvite(from);
      if (typeof sleep === "function") await sleep(1000);
      const codigo = await kira.groupInviteCode(from);
      link = `https://chat.whatsapp.com/${codigo}`;
    } catch (e) {
      console.log("[novolink] erro:", e?.message || e);
      return reply("⚠️ `NOVO LINK`\n\n> 🙇‍♂️ Não consegui redefinir o link do grupo!");
    }

    const texto = "- 📎 `NOVO LINK GP`\n\n> 🙇‍♂️ Link redefinido!\n> Clica no botão abaixo para copiar o novo link do grupo";

    try {
      const card = {
        title: texto,
        footer: "SUNSET",
        buttons: [{
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({ display_text: "COPIAR", copy_code: link })
        }]
      };
      if (logos?.img) card.image = { url: logos.img };
      // carrossel de 1 card; o link só vai dentro do botão
      await kira.sendMessage(from, { interactiveMessage: { title: "\u200e", footer: "SUNSET", carousel: [card] } }, { quoted: selo });
    } catch (err) {
      console.log("[novolink] carrossel falhou, mandando texto:", err?.message || err);
      await reply(`- 📎 \`NOVO LINK GP\`\n\n${link}`);
    }
  },
};
