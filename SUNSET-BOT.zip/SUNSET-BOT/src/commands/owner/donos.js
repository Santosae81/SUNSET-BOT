const donos = require("../../utils/donos");

module.exports = {
  nome: ["dono", "dono1", "dono2", "dono3", "dono4", "dono5", "dono6"],
  category: "owner",
  description: "Gerencia até 6 donos extras. Usar o mesmo comando duas vezes no mesmo número adiciona e depois remove.",
  usage: "<@usuario | número | responder mensagem>",
  executar: async ({ command, prefix, dono, ownerNumber, q, menc_os2, mentions, reply, from, kira }) => {
    // Só o dono principal (settings.json) gerencia a lista
    if (!dono) return reply("👑 `DONO`\n\n> 🙇‍♂️ Só o dono principal pode usar este comando!");

    // /dono sozinho: mostra a lista
    if (command === "dono") {
      const l = donos.lista();
      const numPrincipal = String(ownerNumber || "").replace(/\D/g, "");
      const linhas = l.map((n, i) => `${i + 1}. ${n ? "@" + n : "— vago —"}`).join("\n");
      const jids = l.filter(Boolean).map((n) => n + "@s.whatsapp.net");
      return kira.sendMessage(from, {
        text: `👑 \`MEUS DONOS\`\n\n😻 • Numero do meu dono principal → https://wa.me/${numPrincipal}\n\n${linhas}\n\n> Use ${prefix}dono1 até ${prefix}dono6 com @usuario ou número. Repetir o comando remove.`,
        mentions: jids,
        linkPreview: false
      });
    }

    const slot = Number(command.replace("dono", ""));
    const l = donos.lista();

    // Sem alvo: se o slot já tem alguém, remove (toggle); senão explica o uso
    let alvo = menc_os2 || (q ? q.replace(/\D/g, "") : "");
    if (!alvo) {
      if (l[slot - 1]) alvo = l[slot - 1];
      else return reply(`👑 \`DONO ${slot}\`\n\n> 🙇‍♂️ Marque o @, responda a mensagem ou digite o número! Ex: ${prefix}${command} 5511999999999`);
    }

    const n = donos.soNumero(alvo);
    if (n.length < 8) return reply("👑 `DONO`\n\n> 🙇‍♂️ Número inválido!");

    const r = donos.alternar(slot, n);
    const jid = n + "@s.whatsapp.net";
    const m = (t) => kira.sendMessage(from, { text: t, mentions: [jid] });

    if (r.acao === "add") return m(`✅ \`DONO ${slot}\`\n\n> 👑 @${n} agora é dono do bot!`);
    if (r.acao === "remove") return m(`🗑️ \`DONO ${slot}\`\n\n> @${n} foi removido da lista de donos!`);
    if (r.acao === "jaEmOutro") return m(`⚠️ \`DONO ${slot}\`\n\n> @${n} já está no slot ${r.slot}. Use ${prefix}dono${r.slot} pra remover.`);
    return reply(`⚠️ \`DONO ${slot}\`\n\n> O slot ${slot} já está ocupado por @${r.atual}. Remova primeiro com ${prefix}${command}.`);
  }
};
