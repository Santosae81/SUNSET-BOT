module.exports = {
nome: ["boton","botoff"],
executar: async ({
SoDono,
isBotoff,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isBotoff) {
nescessario.botoff = true;
setNes(nescessario);
reply("❌ `BOT`\n\n> 🙇‍♂️ Desativado! Todas as funções e comandos de membros foram parados");
} else if (isBotoff) {
nescessario.botoff = false;
setNes(nescessario);
reply("✅ `BOT`\n\n> 🙇‍♂️ Ativado! Todo mundo pode me usar de novo");
}
}
};
