module.exports = {
nome: ["prefixos"],
executar: async ({
command,
dataGp,
isGroup,
isMultiP,
mess,
  prefix,
reply
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isMultiP) return reply(`🛡️ \`PREFIXOS\`\n\n> 🙇‍♂️ Ative o multiprefixo primeiro! Ex: ${prefix}multiprefixo`);
if (dataGp[0].prefixos.length < 1) return reply("Hmph! Não contém nenhum prefixo extra adicionado neste grupo... Tanto faz, nada para mostrar mesmo!");
reply(`Hmph! Lista de prefixos para uso do bot, no Grupo: *${groupName}*:\n• *[Total: ${dataGp[0].prefixos.length}]* - ${dataGp[0].prefixos.map((v, index) => `( ${v} )`).join(", ")}\nFiz a listinha só para você, hein?! Não se acostume!`);
}
};
