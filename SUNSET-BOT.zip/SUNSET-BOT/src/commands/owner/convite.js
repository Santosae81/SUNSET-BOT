module.exports = {
nome: ["convite"],
executar: async ({
command,
kira,
from,
sender,
prefix,
reply,
selo,
reagir,
args,
budy,
mess}) => {

if (!budy.includes("chat.whatsapp.com"))
return reply(`📨 \`CONVITE\`\n\n> 🙇‍♂️ Envie o link do grupo! Ex: ${prefix}${command} https://chat.whatsapp.com/xxxx`);
reagir(from, "✅");
cnvt = args.join(" ");
reply(`O convite para eu entrar no seu grupo foi enviado... Agora é só esperar o dono aceitar. N-não fica ansioso, tá?! Não é como se eu estivesse animada com isso também...`);
await kira.sendMessage(SoDono, {text: mess.groupInvitation(sender, cnvt, prefix)}, {quoted: selo});
}
};
