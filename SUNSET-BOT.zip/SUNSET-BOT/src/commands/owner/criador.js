module.exports = {
nome: ["criador"],
executar: async ({ from, reagir, selo, kira }) => {

try { await reagir(from, "😻"); } catch {}
await kira.sendMessage(from, {
text: "😻 • Numero do meu criador → https://wa.me/5511980356416"
}, { quoted: selo });
}
};
