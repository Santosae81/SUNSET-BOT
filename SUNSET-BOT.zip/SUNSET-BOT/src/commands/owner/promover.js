module.exports = {
nome: ["promover"],
executar: async ({
prefix,
command,
from,
groupMembers,
isBotGroupAdmins,
isGroupAdmins,
menc_os2,
mentions,
mess,
reply,
kira
}) => {

if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!menc_os2) return reply(`👑 \`PROMOVER\`\n\n> 🙇‍♂️ Marque a mensagem ou o @ do usuário (apenas um)! Ex: ${prefix}${command} @usuario`);
if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Hmph! Este usuário foi removido do grupo ou saiu... Não será possível promover, tanto faz! Procure outra pessoa, bobinho(a)!");
kira.sendMessage(from, {text: `✅ \`PROMOVER\`\n\n> 👑 @${menc_os2.split("@")[0]} foi promovido(a) a administrador(a) com sucesso!`, mentions: [menc_os2]});
kira.groupParticipantsUpdate(from, [menc_os2], "promote");
}
};
