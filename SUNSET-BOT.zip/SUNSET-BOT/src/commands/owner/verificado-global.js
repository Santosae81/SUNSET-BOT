module.exports = {
nome: ["verificado-global"],
executar: async ({
SoDono,
isVerificado,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isVerificado) {
nescessario.verificado = true;
setNes(nescessario);
reply("❌ `VERIFICADO`\n\n> 🙇‍♂️ Desativado! O selo foi retirado de todos os comandos. Use o comando de novo pra reativar");
} else if (isVerificado) {
nescessario.verificado = false;
setNes(nescessario);
reply("✅ `VERIFICADO`\n\n> 🙇‍♂️ Ativado! O selo foi colocado em todos os comandos. Use o comando de novo pra remover");
}
}
};
