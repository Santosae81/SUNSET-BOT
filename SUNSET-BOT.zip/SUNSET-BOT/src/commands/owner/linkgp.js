// /linkgp (ou /linkgroup, /link): manda o carrossel com botão COPIAR (copia só o link do grupo).
// Se o card falhar, cai pra texto simples com o link.

module.exports = {
nome: ["linkgp", "linkgroup", "link"],
executar: async ({
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
reply,
reagir,
selo,
logos,
kira
}) => {

if (!isGroup) return reply("⚠️ `LINK GP`\n\n> 🙇‍♂️ Este comando só pode ser usado em grupos!");
if (!isGroupAdmins) return reply("⚠️ `LINK GP`\n\n> 🙇‍♂️ Apenas administradores podem usar este comando!");
if (!isBotGroupAdmins) return reply("⚠️ `LINK GP`\n\n> 🙇‍♂️ Eu preciso ser administradora para executar este comando!");

let link;
try {
const codigo = await kira.groupInviteCode(from);
link = `https://chat.whatsapp.com/${codigo}`;
} catch (e) {
console.log("[linkgp] erro ao pegar código:", e?.message || e);
return reply("⚠️ `LINK GP`\n\n> 🙇‍♂️ Não consegui pegar o link do grupo!");
}

if (typeof reagir === "function") { try { reagir(from, "📎"); } catch {} }

const texto = "- 📎 `LINK GP`\n\n> 🙇‍♂️ Clica no botão abaixo para copiar o link do grupo";

try {
const card = {
title: texto,
footer: "SUNSET",
buttons: [{
name: "cta_copy",
buttonParamsJson: JSON.stringify({ display_text: "COPIAR", copy_code: link })
}]
};
if (logos?.img) card.image = { url: logos.img };
// carrossel de 1 card; o link só vai dentro do botão
await kira.sendMessage(from, { interactiveMessage: { title: "\u200e", footer: "SUNSET", carousel: [card] } }, { quoted: selo });
} catch (err) {
console.log("[linkgp] carrossel falhou, mandando texto:", err?.message || err);
await reply(`- 📎 \`LINK GP\`\n\n${link}`);
}
}
};
