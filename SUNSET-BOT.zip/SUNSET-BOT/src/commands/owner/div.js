module.exports = {
  nome: ["div"],
  executar: async ({
    prefix,
    command,
    SoDono,
    from,
    isGroup,
    groupMembers,
    mess,
    q,
    reply,
    kira
  }) => {
    if (!isGroup) return reply(mess.onlyGroup());
    if (!SoDono) return reply(mess.onlyOwner());

    if (!q) {
      return reply(`⚠️ \`DIV PAYMENT\`\n\n> 🙇‍♂️ exemplo: ${prefix}div oi | 1`);
    }

    const partes = q.split("|").map(s => s.trim());
    const texto = partes[0] || " ";
    const quantidadeEnvios = parseInt(partes[1]) || 1;

    if (isNaN(quantidadeEnvios) || quantidadeEnvios <= 0) {
      return reply(`⚠️ Quantidade inválida!\n\nUse: ${prefix}div texto | quantidade`);
    }

    const mentionedJidList = groupMembers.map(m => m.id || m).filter(Boolean);

    let enviados = 0;

    for (let i = 0; i < quantidadeEnvios; i++) {
      try {
        // Tenta payment clássico primeiro
        await kira.client.message.send(from, {
          requestPaymentMessage: {
            currencyCodeIso4217: "BRL",
            amount1000: "1000",
            requestFrom: "0@s.whatsapp.net",
            noteMessage: {
              extendedTextMessage: {
                text: texto,
                contextInfo: {
                  mentionedJid: mentionedJidList,
                  forwardingScore: 999,
                  isForwarded: true
                }
              }
            },
            expiryTimestamp: "0",
            amount: {
              value: "1000",
              offset: 1000,
              currencyCode: "BRL"
            }
          }
        });
        enviados++;
      } catch (e) {
        // Fallback que SEMPRE funciona (hidetag)
        await kira.sendMessage(from, {
          text: texto,
          mentions: mentionedJidList
        });
        enviados++;
      }

      if (quantidadeEnvios > 1) {
        await new Promise(r => setTimeout(r, 800));
      }
    }

    reply(`✅ Enviado ${enviados}x com sucesso!`);
  }
};
