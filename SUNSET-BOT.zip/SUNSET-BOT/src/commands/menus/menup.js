const { fonte } = require("../../utils/fonte");
const F = (t) => fonte(t, "smallcaps");
module.exports = {
nome: ["menup"],
executar: async ({
kira, reagir, prefix, from, NomeDoBot,
emojimenu, pushname, isCargo, date,
hora, logos, linguagem, selo}) => {


await reagir(from, "🎭");
await kira.sendMessage(from, {interactiveMessage: {
title: linguagem.menuPrincipal(NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu),
footer: `Sunset-bot MD`,
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "𝗠𝗘𝗡𝗨𝗦",
sections: [
{
title: `📖 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗢𝗦`,
rows: [{ title: "📖 𝗠𝗘𝗡𝗨 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗢", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menup`, disabled: false }]
},
{
title: `👑 𝗦𝗢́ 𝗣𝗥𝗢 𝗗𝗢𝗡𝗢`,
rows: [{ title: "👑 𝗠𝗘𝗡𝗨 𝗢𝗪𝗡𝗘𝗥", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menudono`, disabled: false }]
},
{
title: `🛡️ 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗖̧𝗔̃𝗢`,
rows: [{ title: "🛡️ 𝗠𝗘𝗡𝗨 𝗔𝗗𝗠𝗜𝗡", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menuadm`, disabled: false }]
},
{
title: `🎉 𝗗𝗜𝗩𝗘𝗥𝗦𝗔̃𝗢`,
rows: [{ title: "🎉 𝗠𝗘𝗡𝗨 𝗗𝗜𝗩𝗘𝗥𝗦𝗔̃𝗢", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}brincadeiras`, disabled: false }]
},
{
title: `🎨 Logos @SECOES@ estilo`,
rows: [{ title: "🎨 𝗠𝗘𝗡𝗨 𝗟𝗢𝗚𝗢𝗦", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menulogos`, disabled: false }]
},
{
title: `🍥 𝗔𝗡𝗜𝗠𝗘𝗦`,
rows: [{ title: "🍥 𝗠𝗘𝗡𝗨 𝗔𝗡𝗜𝗠𝗘𝗦", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menuanimes`, disabled: false }]
},
{
title: `🖼️ 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔𝗦`,
rows: [{ title: "🖼️ 𝗠𝗘𝗡𝗨 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔𝗦", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menufig`, disabled: false }]
},
{
title: `📥 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗦`,
rows: [{ title: "📥 𝗠𝗘𝗡𝗨 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗦", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menudownloads`, disabled: false }]
},
{
title: `🪧 𝗣𝗟𝗔𝗤𝗨𝗜𝗡𝗛𝗔𝗦`,
rows: [{ title: "🪧 𝗠𝗘𝗡𝗨-𝗣𝗟𝗔𝗤", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menuplaq`, disabled: false }]
},
{
title: `😻 𝗠𝗘𝗨 𝗖𝗥𝗜𝗔𝗗𝗢𝗥`,
rows: [{ title: "😻 𝗠𝗘𝗨 𝗖𝗥𝗜𝗔𝗗𝗢𝗥", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}criador`, disabled: false }]
}
]
})
}
],
image: {url: logos.img},
ai: true}}, {quoted: selo});
}
};
