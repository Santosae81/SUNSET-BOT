module.exports = {
nome: ["menu"],
executar: async ({
kira, reagir, prefix, from, baileysVersion,
pushname, isCargo,
hora, logos, selo}) => {

await reagir(from, "🦇");

const up = process.uptime();
const uptime = `${Math.floor(up / 3600)}h ${Math.floor((up % 3600) / 60)}m ${Math.floor(up % 60)}s`;
const DESC = "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗";

await kira.sendMessage(from, {interactiveMessage: {
title: `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓\n` +
`┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}\n` +
`┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}\n` +
`┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}\n` +
`┃ ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎: ${prefix}\n` +
`┃ 📦 𝐁𝐀𝐈𝐋𝐄𝐘𝐒: ${baileysVersion}\n` +
`┃ ⏳ 𝐔𝐏𝐓𝐈𝐌𝐄: ${uptime}\n` +
`┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`,
footer: `Sunset-bot MD`,
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "𝗠𝗘𝗡𝗨𝗦",
sections: [
{
title: `📖 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗢𝗦`,
rows: [{ title: "📖 𝗠𝗘𝗡𝗨 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗢", description: DESC, id: `${prefix}menup`, disabled: false }]
},
{
title: `👑 𝗦𝗢́ 𝗣𝗥𝗢 𝗗𝗢𝗡𝗢`,
rows: [{ title: "👑 𝗠𝗘𝗡𝗨 𝗢𝗪𝗡𝗘𝗥", description: DESC, id: `${prefix}menudono`, disabled: false }]
},
{
title: `🛡️ 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗖̧𝗔̃𝗢`,
rows: [{ title: "🛡️ 𝗠𝗘𝗡𝗨 𝗔𝗗𝗠𝗜𝗡", description: DESC, id: `${prefix}menuadm`, disabled: false }]
},
{
title: `🎉 𝗗𝗜𝗩𝗘𝗥𝗦𝗔̃𝗢`,
rows: [{ title: "🎉 𝗠𝗘𝗡𝗨 𝗗𝗜𝗩𝗘𝗥𝗦𝗔̃𝗢", description: DESC, id: `${prefix}brincadeiras`, disabled: false }]
},
{
title: `🎨 𝗟𝗢𝗚𝗢𝗦 & 𝗘𝗦𝗧𝗜𝗟𝗢`,
rows: [{ title: "🎨 𝗠𝗘𝗡𝗨 𝗟𝗢𝗚𝗢𝗦", description: DESC, id: `${prefix}menulogos`, disabled: false }]
},
{
title: `🍥 𝗔𝗡𝗜𝗠𝗘𝗦`,
rows: [{ title: "🍥 𝗠𝗘𝗡𝗨 𝗔𝗡𝗜𝗠𝗘𝗦", description: DESC, id: `${prefix}menuanimes`, disabled: false }]
},
{
title: `🖼️ 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔𝗦`,
rows: [{ title: "🖼️ 𝗠𝗘𝗡𝗨 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔𝗦", description: DESC, id: `${prefix}menufig`, disabled: false }]
},
{
title: `📥 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗦`,
rows: [{ title: "📥 𝗠𝗘𝗡𝗨 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗦", description: DESC, id: `${prefix}menudownloads`, disabled: false }]
},
{
title: `🪧 𝗣𝗟𝗔𝗤𝗨𝗜𝗡𝗛𝗔𝗦`,
rows: [{ title: "🪧 𝗠𝗘𝗡𝗨-𝗣𝗟𝗔𝗤", description: DESC, id: `${prefix}menuplaq`, disabled: false }]
},
{
title: `😻 𝗠𝗘𝗨 𝗖𝗥𝗜𝗔𝗗𝗢𝗥`,
rows: [{ title: "😻 𝗠𝗘𝗨 𝗖𝗥𝗜𝗔𝗗𝗢𝗥", description: DESC, id: `${prefix}criador`, disabled: false }]
}
]
})
}
],
image: {url: logos.img},
ai: true}}, {quoted: selo});
}
};
