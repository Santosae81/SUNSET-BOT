module.exports = {
nome: ["menuplaq", "menu-plaq", "menuplaquinhas"],
executar: async ({
kira, reagir, prefix, from, pushname, isCargo,
hora, logos, selo}) => {

await reagir(from, "🪧");

const cmds = ["plaq","plaq1","plaq2","plaq3","plaq4","plaq5","plaq6","plaq7","plaq8","plaq9","plaq10"];
const lista = cmds.map((c) => `┃ ➜ ${prefix}${c}`).join("\n");

await kira.sendMessage(from, {interactiveMessage: {
title: `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓\n` +
`┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}\n` +
`┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}\n` +
`┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}\n` +
`┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛\n\n` +
`┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓\n` +
`┃ 𝗣𝗟𝗔𝗤𝗨𝗜𝗡𝗛𝗔𝗦\n` +
`${lista}\n` +
`┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`,
footer: `Sunset-bot MD`,
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "𝗠𝗘𝗡𝗨𝗦",
sections: [
{
title: `Comandos completos`,
rows: [{ title: "menu completo", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menup`, disabled: false }]
},
{
title: `Menu principal`,
rows: [{ title: "voltar ao menu", description: "𝗦𝗨𝗡𝗦𝗘𝗧-𝗕𝗢𝗧 𝗠𝗗", id: `${prefix}menu`, disabled: false }]
}
]
})
}
],
image: {url: logos.img},
ai: true}}, {quoted: selo});
}
};
