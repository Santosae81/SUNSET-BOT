module.exports = {
nome: ["menudownloads", "menu-downloads", "menudownload", "menudl"],
executar: async ({
kira, reagir, prefix, from, pushname, isCargo,
hora, logos, selo}) => {

await reagir(from, "📥");

const cmds = ["play","playvid","playdoc","tiktok","tiktok_audio","instagram","facebook","mediafire","pinterest","pinvideo","tiktok_video","tiktok2","face_video"];
const lista = cmds.map((c) => `┃ ➜ ${prefix}${c}`).join("\n");

const texto = `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓\n` +
`┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}\n` +
`┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}\n` +
`┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}\n` +
`┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛\n\n` +
`┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓\n` +
`┃ 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗦\n` +
`${lista}\n` +
`┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛\n\n> Sunset-bot MD`;

await kira.sendMessage(from, { image: { url: logos.img }, caption: texto }, { quoted: selo });
}
};
