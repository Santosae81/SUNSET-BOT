module.exports = {
nome: ["menulogos"],
executar: async ({
kira, reagir, prefix, from, NomeDoBot,
emojimenu, pushname, isCargo, date,
hora, logos, linguagem, selo}) => {

await reagir(from, "🎨");
const texto = linguagem.menulogos(NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) + "\n\n🖤 KIRA SYSTEM 🤍";

// só a imagem + a lista (sem o botão MENUS); se a imagem falhar, manda só o texto
try {
await kira.sendMessage(from, { image: { url: logos.img }, caption: texto }, { quoted: selo });
} catch (err) {
console.log("[menulogos] imagem falhou, mandando só texto:", err?.message || err);
await kira.sendMessage(from, { text: texto }, { quoted: selo });
}
}
};
