// /rankativo: ranking de atividade do grupo (mensagens, figurinhas, documentos, mídias e comandos).

const moment = require("moment-timezone");
const atividade = require("../../utils/atividade");

const MEDALHAS = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];
const fmt = (n) => Number(n || 0).toLocaleString("pt-BR");

module.exports = {
nome: ["rankativo", "rankativos", "rankingativo", "topativos"],
executar: async ({
from,
isGroup,
reply,
reagir,
selo,
botNumber,
kira
}) => {

if (!isGroup) return reply("⚠️ `RANKING DE ATIVIDADE`\n\n> 🙇‍♂️ Este comando só pode ser usado em grupos!");

if (typeof reagir === "function") { try { reagir(from, "🏆"); } catch {} }

let meta;
try {
meta = await kira.groupMetadata(from);
} catch (e) {
console.log("[rankativo] erro ao pegar membros:", e?.message || e);
return reply("❌️ `RANKING DE ATIVIDADE`\n> Não consegui pegar a lista de membros!");
}

// só quem ainda está no grupo (e não é o bot)
const membros = new Map();
for (const p of meta.participants || []) {
const jid = p.phoneNumber || p.id;
if (!jid) continue;
const k = atividade.chave(jid);
if (k && k !== atividade.chave(botNumber)) membros.set(k, jid);
}

const lista = atividade.ranking(from).filter((r) => membros.has(r.k)).slice(0, 10);
const desde = moment.tz(atividade.desde(from), "America/Sao_Paulo").format("DD/MM/YYYY HH:mm");

if (!lista.length) {
return reply(`🏆 \`RANKING DE ATIVIDADE\`\n\n> 🙇‍♂️ Ainda não tenho mensagens contadas neste grupo.\n> 📅 Contando desde: ${desde}`);
}

let txt = "🏆 `RANKING DE ATIVIDADE`\n";
txt += "👥 Membros mais ativos do grupo\n";
txt += "📊 Confira quem mais movimenta o grupo!\n\n";

lista.forEach((r, i) => {
txt += `${MEDALHAS[i]} @${r.k} — ${fmt(r.total)} mensagens\n`;
if (i < 3) {
txt += `> 💬 Mensagens: ${fmt(r.det.msg)}\n`;
txt += `> 🎭 Figurinhas: ${fmt(r.det.fig)}\n`;
txt += `> 📄 Documentos: ${fmt(r.det.doc)}\n`;
txt += `> 🎥 Mídias: ${fmt(r.det.midia)}\n`;
txt += `> ⚙️ Comandos: ${fmt(r.det.cmd)}\n`;
}
txt += "\n";
});

txt += "🔥 `TOP ATIVOS DO GRUPO`\n\n";
txt += "Quanto mais interações, maior sua posição no ranking!\n\n";
txt += `_📅 Contando desde ${desde} • Sunset-bot MD_`;

await kira.sendMessage(from, { text: txt, mentions: lista.map((r) => membros.get(r.k)) }, { quoted: selo });
}
};
