const { definir } = require("../../handlers/afk");

module.exports = {
  nome: ["afk"],
  executar: async ({ q, sender, isGroup, reply, reagir, from, mess }) => {
    if (!isGroup) return reply(mess.onlyGroup());
    const motivo = (q || "").trim() || "Sem motivo especificado";
    definir(sender, motivo);
    await reagir(from, "✅");
    return reply(
      "✅ `𝗔𝗨𝗦𝗘𝗡𝗧𝗘`\n\n" +
      "> *ᴍᴇɴsᴀɢᴇᴍ ᴅᴇ ᴀᴜsᴇɴᴄɪᴀ ᴄʀɪᴀᴅᴀ ᴄᴏᴍ sᴜᴄᴇssᴏ 🙅‍♂️*\n" +
      `> ᴍᴏᴛɪᴠᴏ: *${motivo}*`
    );
  },
};
