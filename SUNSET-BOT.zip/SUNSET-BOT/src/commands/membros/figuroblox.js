module.exports = require("../../utils/figuYuta")({ nome: ["figuroblox"], titulo: "FIGU ROBLOX", rota: "figu_roblox" });
