const { baixarYuta, acharLink, montarUrl } = require("../../utils/yutaDownload");

// sobe a imagem na Yuta (POST /api/upload) e devolve o link; se falhar usa o upload do bot
async function subirImagem(buffer, API_kira, KEY_kira, uploadBot) {
  try {
    const base = String(API_kira || "").replace(/\/+$/, "").replace(/\/api$/i, "");
    const form = new FormData();
    form.append("file", new Blob([buffer], { type: "image/jpeg" }), `img_${Date.now()}.jpg`);
    const r = await fetch(`${base}/api/upload?apitoken=${encodeURIComponent(KEY_kira || "")}`, { method: "POST", body: form });
    const json = await r.json();
    const link = acharLink(json);
    if (link) return link;
    throw new Error(json?.message || json?.msg || "upload sem link");
  } catch (e) {
    console.log("[hd] upload Yuta falhou:", e?.message || e);
    return uploadBot({ buffer, originalname: `img_${Date.now()}.jpg` });
  }
}

module.exports = {
  nome: ["hd"],
  executar: async ({ info, from, reagir, reply, kira, prefix, command, API_kira, KEY_kira, downloadMediaMessage, upload }) => {
    const msg = info.message || {};
    const quoted =
      msg.extendedTextMessage?.contextInfo?.quotedMessage ||
      msg.imageMessage?.contextInfo?.quotedMessage;
    const midiaObj = msg.imageMessage || quoted?.imageMessage;

    if (!midiaObj) {
      return reply(`🖼️ \`HD\`\n\n> 🙇‍♂️ Marque uma imagem ou envie uma com a legenda ${prefix}${command}!`);
    }

    reagir(from, "⏳");
    try {
      const original = await downloadMediaMessage({ message: { imageMessage: midiaObj } }, "buffer");
      if (!original || !original.length) throw new Error("download vazio");

      const link = await subirImagem(original, API_kira, KEY_kira, upload);
      const { buffer } = await baixarYuta("hd", { imagem: link }, API_kira, KEY_kira, "outros");

      await kira.sendMessage(from, {
        image: buffer,
        caption: "✅ `HD`\n\n> 🙇‍♂️ Imagem melhorada com sucesso!"
      }, { quoted: info });
      reagir(from, "✅");
    } catch (e) {
      console.log("[hd] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `HD`\n\n> 🙇‍♂️ Não consegui melhorar essa imagem! Tenta de novo.");
    }
  }
};
