module.exports = {
nome: ["rename","roubar"],
executar: async ({
Buffer,
author2,
bas64,
command,
convertSticker,
encmediats,
from,
getFileBuffer,
info,
isQuotedSticker,
mess,
pack,
prefix,
q,
quoted,
reagir,
reply,
selo,
sticker,
kira
}) => {

if (!isQuotedSticker) return reply(`🏷️ \`RENAME\`\n\n> 🙇‍♂️ Marque uma figurinha!`);
encmediats = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, "sticker");
[pack, author2] = q.split("|");
if (!q) return reply(`🏷️ \`RENAME\`\n\n> 🙇‍♂️ Digite o novo pacote e autor da figurinha! Ex: ${prefix}${command} pacote|autor`);
if (!pack) return reply(`🏷️ \`RENAME\`\n\n> 🙇‍♂️ Uso correto: ${prefix + command} pacote|autor (respondendo a figurinha)`);
if (!author2) return reply(`🏷️ \`RENAME\`\n\n> 🙇‍♂️ Uso correto: ${prefix + command} pacote|autor (respondendo a figurinha)`);
await reagir(from, '✅');
bas64 = `data:image/jpeg;base64,${encmediats.toString("base64")}`;
var mantap = await convertSticker(bas64, pack, author2);
var sti = new Buffer.from(mantap, "base64");
await kira.sendMessage(from, {sticker: sti}, {quoted: selo}).catch(async (error) => {
reply(mess.error());
});
}
};
