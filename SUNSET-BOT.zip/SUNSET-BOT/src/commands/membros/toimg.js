module.exports = {
nome: ["toimg"],
executar: async ({
from,
getFileBuffer,
info,
isQuotedSticker,
reply,
selo,
kira
}) => {

if (!isQuotedSticker)
return reply("🖼️ `TOIMG`\n\n> 🙇‍♂️ Marque uma figurinha para converter em imagem!");
try {
const buff = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, "sticker");
await kira.sendMessage(from, {image: buff}, {quoted: selo});
} catch (error) {
console.log("[toimg] erro:", error?.message || error);
reply("❌️ `TOIMG`\n> Ocorreu um erro ao converter a figurinha para imagem!");
}
}
};
