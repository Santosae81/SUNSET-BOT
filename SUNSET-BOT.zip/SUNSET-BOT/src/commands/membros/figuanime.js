module.exports = require("../../utils/figuYuta")({ nome: ["figuanime"], titulo: "FIGU ANIME", rota: "figu_anime" });
