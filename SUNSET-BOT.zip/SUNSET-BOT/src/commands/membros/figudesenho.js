module.exports = require("../../utils/figuYuta")({ nome: ["figudesenho"], titulo: "FIGU DESENHO", rota: "figu_desenho" });
