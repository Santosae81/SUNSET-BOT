module.exports = require("../../utils/figuYuta")({ nome: ["figumemes"], titulo: "FIGU MEMES", rota: "figu_engracadas" });
