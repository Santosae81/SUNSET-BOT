module.exports = require("../../utils/figuYuta")({ nome: ["figuraiva"], titulo: "FIGU RAIVA", rota: "figu_raiva" });
