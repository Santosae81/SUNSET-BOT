// /ttp_white <texto>: figurinha brat ESTÁTICA (rota /api/stickers/brat-img da Yuta)
const { yutaSticker, enviarFigurinha } = require("../../utils/yutaApi");

module.exports = {
nome: ["ttp_white", "ttp_brat"],
executar: async (ctx) => {
const { from, q, reagir, reply, prefix, command, API_kira, KEY_kira, NomeDoBot, pushname } = ctx;
const texto = String(q || "").trim();
if (!texto) return reply(`🎨 \`TTP BRANCO\`\n\n> 🙇‍♂️ Envie um texto! Ex: ${prefix}${command} seu texto aqui`);
try { reagir(from, "✅️"); } catch {}
try {
const buf = await yutaSticker(API_kira, KEY_kira, "brat-img", { text: texto });
await enviarFigurinha(ctx, from, buf, { packname: `🤖 ${NomeDoBot || "Bot"}`, author: `\n🌟 ${pushname || ""}` });
} catch (err) {
console.log("[ttp_white] falhou:", err?.message || err);
try { reagir(from, "❌"); } catch {}
reply("❌️ `TTP BRANCO`\n> Não consegui gerar a figurinha! Confira o token da API (pode ter expirado ou batido o limite diário).");
}
}
};
