module.exports = {
nome: ["simih"],
executar: async ({
args,
command,
dataGp,
isGroupAdmins,
isSimi,
mess,
prefix,
reply,
setGp
}) => {

if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (isSimi) {
dataGp[0].simi1 = false;
setGp(dataGp);
reply("❌ `SIMIH`\n\n> 🙇‍♂️ Desativado com sucesso neste grupo!");
} else {
dataGp[0].simi1 = true;
setGp(dataGp);
reply("✅ `SIMIH`\n\n> 🙇‍♂️ Ativado com sucesso neste grupo!");
}
}
};
