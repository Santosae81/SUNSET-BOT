module.exports = require("../../utils/figuYuta")({ nome: ["figucoreana", "figubebe"], titulo: "FIGU COREANA", rota: "figu_coreana" });
