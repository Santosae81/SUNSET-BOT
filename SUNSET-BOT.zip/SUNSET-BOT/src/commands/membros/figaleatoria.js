// /figaleatoria: avisa no grupo que está montando, cria um PACK com 60 figurinhas aleatórias
// e envia o pack no PRIVADO de quem pediu. Depois edita o aviso do grupo dizendo que foi enviado.
// O pack leva o NOME DE QUEM PEDIU (pushname). As figurinhas dentro do pack ficam com o nome em branco.

const BASE = "https://raw.githubusercontent.com/badDevelopper/Testfigu/main";
const TOTAL_REPO = 7050; // fig (1).webp até fig (7050).webp
const QUANTIDADE = 60;
// caractere invisível (braille em branco): autor da figurinha fica "em branco"
const BRANCO = "\u2800";
const TITULO = "FIGU ALEATÓRIA";

async function baixar(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 100) throw new Error("arquivo inválido");
  return buf;
}

// grava a tag no exif de cada figurinha (se falhar, usa a figurinha original)
async function colocarTag(buf, nomeFig) {
  try {
    const webp = require("node-webpmux");
    const img = new webp.Image();
    await img.load(buf);
    const json = {
      "sticker-pack-id": "sunset-stickers",
      "sticker-pack-name": nomeFig,
      "sticker-pack-publisher": BRANCO,
      emojis: ["💯"]
    };
    const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);
    img.exif = exif;
    return await img.save(null);
  } catch {
    return buf;
  }
}

async function criarCapa(webp) {
  const { createCanvas, loadImage } = require("@napi-rs/canvas");
  const img = await loadImage(webp);
  const c = createCanvas(252, 252);
  const g = c.getContext("2d");
  g.fillStyle = "#ffffff";
  g.fillRect(0, 0, 252, 252);
  const r = Math.min(252 / img.width, 252 / img.height);
  const w = img.width * r, h = img.height * r;
  g.drawImage(img, (252 - w) / 2, (252 - h) / 2, w, h);
  return c.toBuffer("image/jpeg", 85);
}

module.exports = {
  nome: ["figaleatoria"],
  executar: async ({ reply, from, sender, isGroup, kira, selo, reagir, pushname }) => {
    const nome = String(sender || "").split("@")[0].split(":")[0];
    // nome do pack = nome de quem pediu (se não tiver pushname, usa o número)
    const nomePack = String(pushname || "").trim() || nome;
    const mentions = sender ? [sender] : [];

    // edita o aviso do grupo (se a edição falhar, manda uma mensagem nova)
    let aviso = null;
    const atualizar = async (texto) => {
      try {
        if (aviso?.key) return await kira.sendMessage(from, { text: texto, mentions, edit: aviso.key });
      } catch (e) {
        console.log("[figaleatoria] erro ao editar aviso:", e?.message || e);
      }
      return kira.sendMessage(from, { text: texto, mentions });
    };

    try { await reagir(from, "🎲"); } catch {}

    try {
      aviso = await kira.sendMessage(from, {
        text: `📦 \`${TITULO}\`\n\n> 🙇‍♂️ @${nome}, estou montando seu pack com ${QUANTIDADE} figurinhas, aguarde...`,
        mentions
      }, { quoted: selo });

      const usados = new Set();
      const sorteia = () => {
        let n;
        do { n = Math.floor(Math.random() * TOTAL_REPO) + 1; } while (usados.has(n));
        usados.add(n);
        return n;
      };

      const stickers = [];
      let tentativas = 0;

      // baixa de 10 em 10; se alguma falhar, sorteia outra no lugar
      while (stickers.length < QUANTIDADE && tentativas < QUANTIDADE * 3) {
        const faltam = Math.min(10, QUANTIDADE - stickers.length);
        const lote = Array.from({ length: faltam }, sorteia);
        tentativas += faltam;
        const res = await Promise.all(lote.map(async (n) => {
          try {
            return await colocarTag(await baixar(`${BASE}/fig%20(${n}).webp`), nomePack);
          } catch { return null; }
        }));
        for (const media of res) {
          if (media && stickers.length < QUANTIDADE) {
            stickers.push({
              media,
              fileName: `fig_${stickers.length + 1}.webp`,
              emojis: ["💯"],
              mimetype: "image/webp"
            });
          }
        }
      }

      if (!stickers.length) {
        try { await reagir(from, "❌"); } catch {}
        return atualizar(`❌️ \`${TITULO}\`\n\n> 🙇‍♂️ Não consegui baixar as figurinhas, tenta de novo!`);
      }

      const capa = await criarCapa(stickers[0].media);
      const pack = {
        type: "sticker-pack",
        stickerPackId: `sunset-${Date.now()}`,
        name: nomePack,
        publisher: nomePack,
        stickers,
        trayIcon: { media: stickers[0].media, fileName: "tray.webp" },
        coverThumbnail: capa
      };

      // em grupo manda no privado de quem pediu; se já estiver no privado, manda ali mesmo
      const destino = isGroup ? sender : from;
      let noPv = true;
      try {
        await kira.client.message.send(destino, pack);
      } catch (e) {
        if (destino === from) throw e;
        console.log("[figaleatoria] falhou no privado, mandando no grupo:", e?.message || e);
        noPv = false;
        await kira.client.message.send(from, pack);
      }

      try { await reagir(from, "✅"); } catch {}

      if (isGroup) {
        await atualizar(noPv
          ? `✅ \`${TITULO}\`\n\n> 🙇‍♂️ @${nome}, pack enviado no seu privado!`
          : `⚠️ \`${TITULO}\`\n\n> 🙇‍♂️ @${nome}, não consegui chamar seu privado, então enviei o pack aqui no grupo!`);
      }
    } catch (e) {
      console.log("[figaleatoria] erro:", e?.message || e);
      try { await reagir(from, "❌"); } catch {}
      const msg = `❌️ \`${TITULO}\`\n\n> 🙇‍♂️ Deu erro ao montar o pack, tenta de novo daqui a pouco!`;
      if (aviso) await atualizar(msg).catch(() => reply(msg)); else reply(msg);
    }
  }
};
