// /wame: gera o link wa.me do número de quem usou o comando.
// Também aceita número digitado (/wame 11999999999), @marcação ou resposta a uma mensagem.

module.exports = {
nome: ["wame", "walink"],
executar: async ({
from,
sender,
q,
menc_os2,
reagir,
reply,
selo,
logos,
kira
}) => {

try {
if (typeof reagir === "function") { try { reagir(from, "🔗"); } catch {} }

const soNumero = (jid) => {
const s = String(jid || "");
if (/@lid$/i.test(s)) return "";
return s.split("@")[0].split(":")[0].replace(/\D/g, "");
};

let numero = "";
const digitado = String(q || "").replace(/\D/g, "");

if (digitado.length >= 8) {
numero = digitado;
// número BR sem DDI (10 ou 11 dígitos): adiciona 55
if (numero.length === 10 || numero.length === 11) numero = "55" + numero;
} else {
numero = soNumero(menc_os2) || soNumero(sender);
}

if (!numero || numero.length < 8) {
return reply("⚠️ `WAME`\n\n> 🙇‍♂️ Não consegui identificar o número! Use: /wame 11999999999");
}

const link = `https://wa.me/${numero}`;
const btnCopiar = { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPIAR", copy_code: link }) };
const btnAbrir = { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "ABRIR CONVERSA", url: link, merchant_url: link }) };
const textoCard = "- 🔗 `WAME`\n\n> 🙇‍♂️ Aqui está o link do número do WhatsApp";

const card = { title: textoCard, footer: "SUNSET", buttons: [btnCopiar, btnAbrir] };
if (logos?.img) card.image = { url: logos.img };

try {
// carrossel de 1 card com os 2 botões embaixo; o link só vai dentro dos botões
await kira.sendMessage(from, {
interactiveMessage: { title: "\u200e", footer: "SUNSET", carousel: [card] }
}, { quoted: selo });
} catch (err) {
console.log("[wame] carrossel falhou, mandando card simples:", err?.message || err);
try {
await kira.sendMessage(from, { interactiveMessage: card }, { quoted: selo });
} catch (err2) {
console.log("[wame] card falhou, mandando texto:", err2?.message || err2);
await reply(`- 🔗 \`WAME\`\n\n> 🙇‍♂️ Aqui está o link do número do WhatsApp\n\n${link}`);
}
}
} catch (e) {
console.log("[wame] erro:", e?.message || e);
reply("⚠️ `WAME`\n\n> 🙇‍♂️ Deu erro ao gerar o link!");
}
}
};
