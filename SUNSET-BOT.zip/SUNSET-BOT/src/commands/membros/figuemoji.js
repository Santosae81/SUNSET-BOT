module.exports = require("../../utils/figuYuta")({ nome: ["figuemoji"], titulo: "FIGU EMOJI", rota: "figu_emoji" });
