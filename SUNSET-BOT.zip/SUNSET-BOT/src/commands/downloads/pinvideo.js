const { baixarYuta } = require("../../utils/yutaDownload");

module.exports = {
  nome: ["pinvideo", "pinmp4"],
  executar: async ({ q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira }) => {
    const link = (q || "").trim().split(/\s+/)[0];
    if (!/^https?:\/\/\S+/i.test(link) || !/pin(terest)?\./i.test(link)) {
      return reply(`📌 \`PINTEREST\`\n\n> 🙇‍♂️ Envie o link do Pinterest! Ex: ${prefix}${command} https://pin.it/xxxx`);
    }
    reagir(from, "📌");
    try {
      const { buffer } = await baixarYuta("pinterest-mp4", { url: link }, API_kira, KEY_kira);
      await kira.sendMessage(from, { video: buffer, mimetype: "video/mp4" }, { quoted: info });
      reagir(from, "✅");
    } catch (e) {
      console.log("[pinvideo] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `PINTEREST`\n\n> 🙇‍♂️ Não consegui baixar esse pin!");
    }
  }
};
