const axios = require("axios");
const { baixarYuta } = require("../../utils/yutaDownload");

const CMD_AUDIO = "tiktokbaixaraudio";

// Uma linha só (dentro do ">" do WhatsApp não pode quebrar linha)
function limitar(txt, max) {
  const t = String(txt || "").replace(/\s+/g, " ").trim();
  if (!t) return "";
  return t.length > max ? t.slice(0, max - 1) + "…" : t;
}

// Legenda curta (autor/descrição). Se falhar, o vídeo vai sem legenda.
async function buscarLegenda(link) {
  try {
    const r = await axios.get("https://www.tikwm.com/api/", {
      params: { url: link },
      timeout: 10000,
      validateStatus: () => true
    });
    const d = r.data && Number(r.data.code) === 0 ? r.data.data : null;
    if (!d) return "";
    const nick = d.author?.nickname || "";
    const user = d.author?.unique_id ? `@${d.author.unique_id}` : "";
    const autor = [nick, user && nick ? `(${user})` : user].filter(Boolean).join(" ");
    const partes = [];
    if (autor) partes.push(`👤 ${limitar(autor, 60)}`);
    if (d.title) partes.push(`📝 ${limitar(d.title, 150)}`);
    return partes.length ? `🎥 \`TIKTOK\`\n\n> ${partes.join("\n> ")}` : "🎥 `TIKTOK`";
  } catch {
    return "";
  }
}

module.exports = {
  nome: ["tiktok", "tiktok_video", CMD_AUDIO],

  executar: async ({ prefix, command, from, q, reagir, reply, selo, info, kira, API_kira, KEY_kira }) => {
    const p = prefix || "!";
    const cmd = String(command || "").toLowerCase();
    const link = (q || "").trim().split(/\s+/)[0];

    if (!/^https?:\/\/\S+/i.test(link || "") || !/tiktok\.com/i.test(link)) {
      return reply(`🎥 \`TIKTOK\`\n\n> 🔗 Envie o link do vídeo!\n\n📌 Ex: ${p}tiktok https://vt.tiktok.com/xxxx`);
    }

    try {
      reagir(from, "⏳");

      if (cmd === CMD_AUDIO) {
        const { buffer } = await baixarYuta("tiktok-mp3", { url: link }, API_kira, KEY_kira);
        await kira.sendMessage(from, { audio: buffer, mimetype: "audio/mpeg" }, { quoted: info || selo });
      } else {
        const { buffer } = await baixarYuta("tiktok-mp4", { url: link }, API_kira, KEY_kira);
        const legenda = await buscarLegenda(link).catch(() => "");
        await kira.sendMessage(
          from,
          { video: buffer, mimetype: "video/mp4", caption: legenda || undefined },
          { quoted: selo }
        );
      }

      reagir(from, "✅");
    } catch (err) {
      console.log("[tiktok] Erro:", err.message);
      reagir(from, "❌");
      return reply(`⚠️ \`TIKTOK\`\n\n> ❌ Falha no download.\n\n> 📌 Motivo: ${err.message}`);
    }
  }
};
