const { YT_REGEX, baixarVideoYoutube } = require("../../utils/youtubeDownload");

module.exports = {
nome: ["ytmp4", "baixar_video"],
executar: async ({ kira, from, reagir, reply, API_kira, KEY_kira, info, prefix, command, q }) => {

const link = (q || "").trim().split(/\s+/)[0];
if (!link || !YT_REGEX.test(link)) return reply(`🎬 \`YTMP4\`\n\n> 🙇‍♂️ Envie o link do vídeo! Ex: ${prefix}${command} https://youtu.be/xxxx`);
reagir(from, "💽");
try {
  const video = await baixarVideoYoutube(link, API_kira, KEY_kira);
  await kira.sendMessage(from, { video, mimetype: "video/mp4" }, { quoted: info });
} catch (error) {
  console.log("[ytmp4] erro:", error?.message || error);
  reagir(from, "❌");
  return reply("⚠️ `YTMP4`\n\n> 🙇‍♂️ Não consegui baixar o vídeo!");
}
}
};
