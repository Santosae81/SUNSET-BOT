const { consultarYuta, acharLink, acharValor } = require("../../utils/yutaDownload");

module.exports = {
  nome: ["mediafire"],
  executar: async ({ q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira }) => {
    const link = (q || "").trim().split(/\s+/)[0];
    if (!/^https?:\/\/\S+/i.test(link) || !/mediafire\.com/i.test(link)) {
      return reply(`📥 \`MEDIAFIRE\`\n\n> 🙇‍♂️ Envie o link do Mediafire! Ex: ${prefix}${command} https://www.mediafire.com/file/xxxx`);
    }
    reagir(from, "📥");
    try {
      const json = await consultarYuta("mediafire-dl", { url: link }, API_kira, KEY_kira);
      const arquivo = acharLink(json);
      if (!arquivo) throw new Error(json.message || json.msg || "A API não retornou o link do arquivo.");

      const nome = String(acharValor(json, ["filename", "file_name", "nome", "name"]) || "arquivo").replace(/[\\/:*?"<>|]/g, "");
      const peso = acharValor(json, ["size", "peso", "filesize"]);
      const tipo = String(acharValor(json, ["filetype", "mimetype", "type", "ext"]) || "");

      await reply(`📥 \`MEDIAFIRE\`\n\n> 🙇‍♂️ Enviando o arquivo, aguarde...\n> 📄 Arquivo: ${nome}${peso ? `\n> 📦 Peso: ${peso}` : ""}`);
      await kira.sendMessage(from, {
        document: { url: arquivo },
        mimetype: tipo.includes("/") ? tipo : "application/octet-stream",
        fileName: nome,
      }, { quoted: info });
      reagir(from, "✅");
    } catch (e) {
      console.log("[mediafire] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `MEDIAFIRE`\n\n> 🙇‍♂️ Não consegui baixar esse arquivo!");
    }
  }
};
