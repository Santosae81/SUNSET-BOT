const { YT_REGEX, baixarAudioYoutube, prepararAudio } = require("../../utils/youtubeDownload");

module.exports = {
nome: ["playaudio"],
executar: async ({ kira, from, reagir, reply, API_kira, KEY_kira, info, q, prefix }) => {

const link = (q || "").trim().split(/\s+/)[0];
if (!link || !YT_REGEX.test(link)) {
  return reply(`⚠️ \`PLAY ÁUDIO\`\n\n> 🙇‍♂️ Envie um link válido do YouTube! Ex: ${prefix || "!"}playaudio https://youtu.be/...`);
}
reagir(from, "💽");

try {
  const bruto = await baixarAudioYoutube(link, API_kira, KEY_kira);
  const { buffer, mimetype } = await prepararAudio(bruto);
  // responde direto a mensagem do botão que a pessoa clicou
  await kira.sendMessage(from, { audio: buffer, mimetype }, { quoted: info });
  console.log(`[playaudio] áudio enviado (${mimetype}, ${buffer.length} bytes).`);
} catch (err) {
  console.log("[playaudio] erro:", err?.message || err);
  reagir(from, "❌");
  return reply("⚠️ `PLAY ÁUDIO`\n\n> 🙇‍♂️ Não consegui baixar o áudio! Confira o token da API (pode ter expirado ou batido o limite diário).");
}
}
};
