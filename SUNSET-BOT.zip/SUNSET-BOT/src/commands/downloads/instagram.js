const { baixarYuta } = require("../../utils/yutaDownload");

module.exports = {
  nome: ["instagram"],
  executar: async ({ q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira }) => {
    const link = (q || "").trim().split(/\s+/)[0];
    if (!/^https?:\/\/\S+/i.test(link) || !/instagram\.com/i.test(link)) {
      return reply(`📸 \`INSTAGRAM\`\n\n> 🙇‍♂️ Envie o link do Instagram! Ex: ${prefix}${command} https://www.instagram.com/p/xxxx`);
    }
    reagir(from, "📸");
    try {
      const { buffer, tipo } = await baixarYuta("instagram-video", { url: link }, API_kira, KEY_kira);
      if (tipo.startsWith("image/")) {
        await kira.sendMessage(from, { image: buffer }, { quoted: info });
      } else {
        await kira.sendMessage(from, { video: buffer, mimetype: "video/mp4" }, { quoted: info });
      }
      reagir(from, "✅");
    } catch (e) {
      console.log("[instagram] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `INSTAGRAM`\n\n> 🙇‍♂️ Não consegui baixar esse link!");
    }
  }
};
