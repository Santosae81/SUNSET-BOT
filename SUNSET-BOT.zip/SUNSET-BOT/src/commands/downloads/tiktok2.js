const { baixarYuta } = require("../../utils/yutaDownload");

module.exports = {
  nome: ["tiktok2", "tiktok_audio"],
  executar: async ({ q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira }) => {
    const link = (q || "").trim().split(/\s+/)[0];
    if (!/^https?:\/\/\S+/i.test(link) || !/tiktok\.com/i.test(link)) {
      return reply(`🎵 \`TIKTOK ÁUDIO\`\n\n> 🙇‍♂️ Envie o link do TikTok! Ex: ${prefix}${command} https://vm.tiktok.com/xxxx`);
    }
    reagir(from, "🎵");
    try {
      const { buffer } = await baixarYuta("tiktok-mp3", { url: link }, API_kira, KEY_kira);
      await kira.sendMessage(from, { audio: buffer, mimetype: "audio/mpeg" }, { quoted: info });
      reagir(from, "✅");
    } catch (e) {
      console.log("[tiktok2] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `TIKTOK ÁUDIO`\n\n> 🙇‍♂️ Não consegui baixar o áudio!");
    }
  }
};
