const { YT_REGEX, baixarAudioYoutube, prepararAudio } = require("../../utils/youtubeDownload");

module.exports = {
nome: ["ytmp3", "baixar_audio"],
executar: async ({ kira, from, reagir, reply, API_kira, KEY_kira, info, prefix, command, q }) => {

const link = (q || "").trim().split(/\s+/)[0];
if (!link || !YT_REGEX.test(link)) return reply(`🎶 \`YTMP3\`\n\n> 🙇‍♂️ Envie o link do vídeo! Ex: ${prefix}${command} https://youtu.be/xxxx`);
reagir(from, "💽");
try {
  const bruto = await baixarAudioYoutube(link, API_kira, KEY_kira);
  const { buffer, mimetype } = await prepararAudio(bruto);
  await kira.sendMessage(from, { audio: buffer, mimetype }, { quoted: info });
} catch (error) {
  console.log("[ytmp3] erro:", error?.message || error);
  reagir(from, "❌");
  return reply("⚠️ `YTMP3`\n\n> 🙇‍♂️ Não consegui baixar o áudio!");
}
}
};
