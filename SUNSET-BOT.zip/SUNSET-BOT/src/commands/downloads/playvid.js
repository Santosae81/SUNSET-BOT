const yts = require("yt-search");
const { YT_REGEX, baixarVideoYoutube } = require("../../utils/youtubeDownload");

const LIMITE_VIDEO = 64 * 1024 * 1024;

module.exports = {
nome: ["playvid", "playvideo"],
executar: async ({ prefix, command, kira, from, reagir, reply, API_kira, KEY_kira, info, q }) => {

const entrada = (q || "").trim();
if (!entrada) return reply(`🎬 \`PLAY VÍDEO\`\n\n> 🙇‍♂️ Digite o nome ou link! Ex: ${prefix}${command} nome da música`);
reagir(from, "💽");

try {
  let link = entrada.split(/\s+/)[0];
  let titulo = "";
  if (YT_REGEX.test(link)) {
    try {
      const id = (link.match(/(?:v=|youtu\.be\/|shorts\/)([\w-]{11})/) || [])[1];
      if (id) titulo = (await yts({ videoId: id }))?.title || "";
    } catch {}
  } else {
    const busca = await yts(entrada);
    const v = busca?.videos?.[0];
    if (!v) { reagir(from, "❌"); return reply("⚠️ `PLAY VÍDEO`\n\n> 🙇‍♂️ Não encontrei esse vídeo!"); }
    link = v.url;
    titulo = v.title;
  }

  const video = await baixarVideoYoutube(link, API_kira, KEY_kira);

  // responde direto a mensagem do botão que a pessoa clicou
  if (video.length > LIMITE_VIDEO) {
    await kira.sendMessage(from, {
      document: video, mimetype: "video/mp4",
      fileName: `${(titulo || "video").replace(/[\\/:*?"<>|]/g, "").slice(0, 80)}.mp4`
    }, { quoted: info });
  } else {
    await kira.sendMessage(from, {
      video, mimetype: "video/mp4",
      ...(titulo ? { caption: `🎬 ${titulo}` } : {})
    }, { quoted: info });
  }
  console.log(`[playvid] vídeo enviado (${video.length} bytes).`);
} catch (err) {
  console.log("[playvid] erro:", err?.message || err);
  reagir(from, "❌");
  return reply("⚠️ `PLAY VÍDEO`\n\n> 🙇‍♂️ Não consegui baixar o vídeo! Confira o token da API (pode ter expirado ou batido o limite diário).");
}
}
};
