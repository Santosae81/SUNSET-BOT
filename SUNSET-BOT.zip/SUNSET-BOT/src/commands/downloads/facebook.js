const { baixarYuta } = require("../../utils/yutaDownload");

module.exports = {
  nome: ["facebook", "fb", "face_video"],
  executar: async ({ q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira }) => {
    const link = (q || "").trim().split(/\s+/)[0];
    if (!/^https?:\/\/\S+/i.test(link) || !/(facebook|fb)\./i.test(link)) {
      return reply(`📘 \`FACEBOOK\`\n\n> 🙇‍♂️ Envie o link do vídeo do Facebook! Ex: ${prefix}${command} https://fb.watch/xxxx`);
    }
    reagir(from, "📘");
    try {
      const { buffer } = await baixarYuta("face-mp4", { url: link }, API_kira, KEY_kira);
      await kira.sendMessage(from, { video: buffer, mimetype: "video/mp4" }, { quoted: info });
      reagir(from, "✅");
    } catch (e) {
      console.log("[facebook] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `FACEBOOK`\n\n> 🙇‍♂️ Não consegui baixar esse vídeo!");
    }
  }
};
