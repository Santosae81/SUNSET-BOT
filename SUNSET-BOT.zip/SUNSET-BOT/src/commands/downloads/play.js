const yts = require("yt-search");
const moment = require("moment-timezone");
const { gerarCardPlay } = require("../../canvas/playCard");

function saudacao() {
  const h = moment().tz("America/Sao_Paulo").hour();
  if (h >= 5 && h < 12) return "Bom dia";
  if (h >= 12 && h < 18) return "Boa tarde";
  return "Boa noite";
}

module.exports = {
  nome: ["play"],
  executar: async ({ kira, from, sender, reagir, reply, selo, q, prefix, command }) => {
    const p = prefix || "!";

    if (!q) {
      return reply(`⚠️ \`PLAY\`\n\n> 🙇‍♂️ Digite o nome da música! Ex: ${p}${command || "play"} nome da música`);
    }

    reagir(from, "✅");

    try {
      const busca = await yts(q);
      const v = busca?.videos?.[0];

      if (!v || !v.url) {
        reagir(from, "❌");
        return reply("⚠️ `PLAY`\n\n> 🙇‍♂️ Não encontrei essa música!");
      }

      const duracao = v.duration?.timestamp || v.timestamp || "indisponível";
      const views = typeof v.views === "number"
        ? `${v.views.toLocaleString("pt-BR")} visualizações`
        : "indisponível";

      const desc = String(v.description || "").replace(/\s+/g, " ").trim();
      const descCurta = desc
        ? (desc.length > 110 ? desc.slice(0, 110).trimEnd() + "..." : desc)
        : "indisponível";

      const numero = String(sender || "").split("@")[0];

      const legenda = `🎶 \`𝗕𝗢𝗧 𝗣𝗟𝗔𝗬\`
> *👤 • ᴜsᴜᴀʀɪᴏ: @${numero}*
> *🎵 • ᴛɪᴛᴜʟᴏ: ${v.title}*
> *⏱️ • ᴅᴜʀᴀᴄᴀᴏ: ${duracao}*
> *👁️ • ᴠɪᴇᴡs: ${views}*
> *📺 • ᴄᴀɴᴀʟ: ${v.author?.name || "indisponível"}*
> *🔗 • ʟɪɴᴋ: ${v.url}*
> *📝 • ᴅᴇsᴄʀɪᴄᴀᴏ: ${descCurta}*
> *⌛ • sɪsᴛᴇᴍᴀ: ᴇsᴄᴏʟʜᴀ ᴀ ᴏᴘᴄᴀᴏ ᴀʙᴀɪxᴏ...*
> *✨ • ${saudacao()}*`;

      const botoes = [
        {
          name: "quick_reply",
          buttonParamsJson: JSON.stringify({
            display_text: "🎧 BAIXAR ÁUDIO",
            id: `${p}playaudio ${v.url}`
          })
        },
        {
          name: "quick_reply",
          buttonParamsJson: JSON.stringify({
            display_text: "🎬 BAIXAR VÍDEO",
            id: `${p}playvid ${v.url}`
          })
        }
      ];

      try {
        const card = await gerarCardPlay({
          titulo: v.title,
          canal: v.author?.name || "YouTube",
          duracao,
          thumb: v.thumbnail || v.image
        });

        await kira.sendMessage(from, {
          interactiveMessage: {
            title: legenda,
            footer: "Toque em um botão para baixar",
            image: { url: card },
            buttons: botoes
          }
        }, { quoted: selo });

      } catch (err) {
        console.log("[PLAY CARD]", err?.message || err);

        await reply(
          `${legenda}\n\n` +
          `🎧 Áudio: ${p}playaudio ${v.url}\n` +
          `🎬 Vídeo: ${p}playvid ${v.url}`
        );
      }

    } catch (e) {
      reagir(from, "❌");
      console.log("[PLAY]", e);
      return reply("⚠️ `PLAY`\n\n> 🙇‍♂️ Erro ao buscar a música!");
    }
  }
};
