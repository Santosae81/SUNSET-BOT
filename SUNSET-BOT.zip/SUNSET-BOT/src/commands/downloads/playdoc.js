const yts = require("yt-search");
const { YT_REGEX, baixarAudioYoutube, prepararAudio } = require("../../utils/youtubeDownload");

module.exports = {
  nome: ["ytdoc", "playdoc"],
  executar: async ({ prefix, command, kira, from, reagir, reply, API_kira, KEY_kira, info, q }) => {
    const entrada = (q || "").trim();
    if (!entrada) return reply(`📄 \`PLAY DOC\`\n\n> 🙇‍♂️ Digite o nome ou link da música! Ex: ${prefix}${command} nome da música`);
    reagir(from, "💽");

    try {
      let link = entrada.split(/\s+/)[0];
      let titulo = "";
      if (YT_REGEX.test(link)) {
        const id = (link.match(/(?:v=|youtu\.be\/|shorts\/)([\w-]{11})/) || [])[1];
        if (id) titulo = (await yts({ videoId: id }).catch(() => null))?.title || "";
      } else {
        const busca = await yts(entrada);
        const v = busca?.videos?.[0];
        if (!v) { reagir(from, "❌"); return reply("⚠️ `PLAY DOC`\n\n> 🙇‍♂️ Não encontrei essa música!"); }
        link = v.url;
        titulo = v.title;
      }

      const bruto = await baixarAudioYoutube(link, API_kira, KEY_kira);
      const { buffer, mimetype } = await prepararAudio(bruto);
      const nome = (titulo || "audio").replace(/[\\/:*?"<>|]/g, "").slice(0, 80);
      await kira.sendMessage(from, {
        document: buffer,
        mimetype,
        fileName: `${nome}.${mimetype.includes("mp4") ? "m4a" : "mp3"}`
      }, { quoted: info });
      reagir(from, "✅");
    } catch (e) {
      console.log("[playdoc] erro:", e?.message || e);
      reagir(from, "❌");
      return reply("⚠️ `PLAY DOC`\n\n> 🙇‍♂️ Não consegui baixar a música!");
    }
  }
};
