module.exports = {
nome: ["antilinkhard","antilink"],
executar: async ({
  args,
  dataGp,
  isAntiLinkHard,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());

// Sem argumento: alterna (1x ativa, 2x desativa). Com 1 ou 0 ainda força.
let ativar = !isAntiLinkHard;
if (args[0] === "1") ativar = true;
else if (args[0] === "0") ativar = false;

dataGp[0].antilinkhard = ativar;
setGp(dataGp);
reply(ativar
  ? "🔗 `ANTILINK`\n\n> ✅ Ativado! Qualquer link (menos de grupos) será apagado e o autor removido"
  : "🔗 `ANTILINK`\n\n> ❌ Desativado!");
}
};
