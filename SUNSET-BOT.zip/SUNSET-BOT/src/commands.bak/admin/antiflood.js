module.exports = {
nome: ["antiflood"],
executar: async ({
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess,
  prefix,
  q
}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q === "1") {
dataGp[0].anti_flood = true;
setGp(dataGp);
reply("✅ Hmph! Anti flood ativado... Agora quem floodar ou marcar todo mundo de uma vez vai ser banido na hora, viu?!");
} else if (q === "0") {
dataGp[0].anti_flood = false;
setGp(dataGp);
reply("❌ Hmph! Anti flood desativado... Tanto faz, baka!");
} else {
reply(`🛡️ \`ANTIFLOOD\`\n\n> 🙇‍♂️ Use 1 para ativar ou 0 para desativar! Ex: ${prefix}antiflood 1`);
}
}
};
