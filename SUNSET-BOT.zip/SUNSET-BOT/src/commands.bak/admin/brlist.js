module.exports = {
nome: ["brlist", "listabr"],
executar: async ({ botNumber, from, groupMembers, isGroup, isGroupAdmins, mention, mess, reagir, reply }) => {

if (!isGroup) return reply(mess.onlyGroup());
reagir(from, "🇧🇷");
let txt = `Hmph! 🇧🇷 *Lista de números brasileiros presentes neste grupo:*\n`;
const br = groupMembers.map((m) => m.id).filter((id) => id.startsWith("55") && id !== botNumber);
for (const id of br) txt += `⇒ ${isGroupAdmins ? "@" : "wa.me/"}${id.split("@")[0]}\n`;
txt += `\nHmph! 🇧🇷 Total: ${br.length}`;
if (!br.length) return reply("Hmph! Não há números brasileiros neste grupo... Tanto faz, baka!");
return isGroupAdmins ? mention(txt, br) : reply(txt);
}
};
