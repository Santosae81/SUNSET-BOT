module.exports = {
nome: ["setantispam"],
executar: async ({
command,
  kira,
  from,
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess,
  prefix,
  q}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!q) return reply(`🛡️ \`SET ANTISPAM\`\n\n> 🙇‍♂️ Digite o limite do antispam! Ex: ${prefix}${command} 5`);
const tempoSpam = Number(q);
if (isNaN(tempoSpam) || tempoSpam < 1) {
return reply(`🛡️ \`SET ANTISPAM\`\n\n> 🙇‍♂️ Digite um número válido! Ex: ${prefix}${command} 5`);
}
if (!dataGp[0].antispam) dataGp[0].antispam = {};
dataGp[0].antispam.tempo = tempoSpam;
setGp(dataGp);
reply(`✅ Hmph! Tempo definido para ${tempoSpam} segundos... Prontinho, mas não se acostume com isso, viu?!`);
}
};
