module.exports = {
nome: ["antispam"],
executar: async ({
  kira,
  from,
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess,
  prefix,
  q}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q === "1") {
if (!dataGp[0].antispam) dataGp[0].antispam = {};
dataGp[0].antispam.active = true;
setGp(dataGp);
reply("✅ Hmph! Anti spam ativado... Não se acostume com isso, viu?! Só fiz porque quis!");
} else if (q === "0") {
if (!dataGp[0].antispam) dataGp[0].antispam = {};
dataGp[0].antispam.active = false;
setGp(dataGp);
reply("❌ Hmph! Anti spam desativado... Tanto faz, baka!");
} else {
reply(`🛡️ \`ANTISPAM\`\n\n> 🙇‍♂️ Use 1 para ativar ou 0 para desativar! Ex: ${prefix}antispam 1`);
}
}
};
