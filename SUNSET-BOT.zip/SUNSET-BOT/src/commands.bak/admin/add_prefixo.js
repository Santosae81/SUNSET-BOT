module.exports = {
nome: ["add_prefixo"],
executar: async ({
  command,
  dataGp,
  isGroup,
  isGroupAdmins,
  isMultiP,
  mess,
  prefix,
  q,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isMultiP) return reply(`➕ \`ADD PREFIXO\`\n\n> 🙇‍♂️ Ative o multiprefixo primeiro! Ex: ${prefix}multiprefixo`);
if (!q.trim()) return reply(`➕ \`ADD PREFIXO\`\n\n> 🙇‍♂️ Digite o novo prefixo! Ex: ${prefix}${command} _`);
if (q.trim() > 1) return reply(`➕ \`ADD PREFIXO\`\n\n> 🙇‍♂️ Adicione um prefixo por vez! Ex: ${prefix}${command} _`);
if (dataGp[0].prefixos.indexOf(q.trim()) >= 0) return reply(`➕ \`ADD PREFIXO\`\n\n> 🙇‍♂️ Esse prefixo já está na lista! Ex: ${prefix}prefixos`);
dataGp[0].prefixos.push(q.trim());
setGp(dataGp);
reply(`Hmph! Prefixo ${q.trim()} foi adicionado com sucesso na lista de prefixos para uso do bot, neste grupo... Não se acostume com isso, viu?! Só fiz porque quis!`);
}
};
