module.exports = {
nome: ["totalcmd","totalcomando"],
executar: async ({
totalcmds,
reply
}) => {

reply(`📊 \`TOTAL DE COMANDOS\`\n\n- > ✨️ Eu tenho ${totalcmds} comandos disponíveis!`);
}
};
