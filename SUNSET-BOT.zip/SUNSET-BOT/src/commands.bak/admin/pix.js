// Usado pelos botões do /alugar. Lê settings/pix.json -> { "chave": "...", "nome": "..." }
module.exports = {
nome: ["pix"],
executar: async ({ fs, q, reply, prefix }) => {

const valor = Number(String(q || "").replace(",", "."));
if (!valor || valor <= 0) return reply(`Hmph! Escolha um plano pelo *${prefix}alugar*, baka!`);
let cfg = null;
try { cfg = JSON.parse(fs.readFileSync("./settings/pix.json", "utf8")); } catch {}
if (!cfg?.chave) return reply(`Hmph! O PIX ainda não foi configurado... Fala com o suporte: https://wa.me/556681147547\n💰 Plano escolhido: R$ ${valor.toFixed(2)}`);
return reply(`💳 *PAGAMENTO VIA PIX*\n\n💰 Valor: *R$ ${valor.toFixed(2)}*\n🔑 Chave: ${cfg.chave}\n👤 Nome: ${cfg.nome || "—"}\n\nDepois de pagar, manda o comprovante pro suporte: https://wa.me/556681147547 🖤`);
}
};
