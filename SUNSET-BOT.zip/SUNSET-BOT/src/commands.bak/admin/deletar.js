module.exports = {
nome: ["deletar","delete","del","d"],
executar: async ({
prefix,
command,
SoDono,
from,
fromMe,
info,
isBotGroupAdmins,
isGroupAdmins,
menc_os2,
mess,
reply,
kira
}) => {

{
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!menc_os2) return reply(`🗑️ \`DELETAR\`\n\n> 🙇‍♂️ Marque a mensagem que deseja apagar!`);
const msg = info.message.extendedTextMessage.contextInfo;
await kira.sendMessage(from, {delete: {remoteJid: from, fromMe: false, id: msg.stanzaId, participant: msg.participant}});
}
}
};
