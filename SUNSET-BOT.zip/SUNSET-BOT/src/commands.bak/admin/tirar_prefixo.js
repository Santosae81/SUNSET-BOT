module.exports = {
nome: ["tirar_prefixo"],
executar: async ({
  command,
  dataGp,
  isGroup,
  isGroupAdmins,
  isMultiP,
  mess,
  prefix,
  q,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isMultiP) return reply(`🛡️ \`TIRAR PREFIXO\`\n\n> 🙇‍♂️ Ative o multiprefixo primeiro! Ex: ${prefix}multiprefixo`);
if (!q.trim()) return reply(`🛡️ \`TIRAR PREFIXO\`\n\n> 🙇‍♂️ Digite o prefixo que deseja remover! Ex: ${prefix}${command} _`);
if (q.trim() > 1) return reply(`🛡️ \`TIRAR PREFIXO\`\n\n> 🙇‍♂️ Remova um prefixo por vez! Ex: ${prefix}${command} _`);
if (dataGp[0].prefixos.indexOf(q.trim()) < 0) return reply(`Hmph! Esse prefixo não está incluso, confere na lista dos prefixos. Veja: ${prefix}prefixos`);
if (dataGp[0].prefixos.length == 1) return reply("Hmph! Adicione um prefixo para pode tirar este, tem que ter pelo menos 1 prefixo já incluso dentro do sistema para tirar outro... Presta atenção, idiota!");
dataGp[0].prefixos.splice(dataGp[0].prefixos.indexOf(q.trim()), 1);
setGp(dataGp);
reply(`Hmph! Prefixo ${q.trim()} tirado com sucesso da lista de prefixos de uso deste grupo.. Só fiz porque quis, tá?! Não se acostume!`);
}
};
