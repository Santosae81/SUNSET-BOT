const registry = require("./registry");
const { similarityCmd } = require("../utils/helpers");

async function handleCommand(ctx) {
  if (!ctx.isCmd) return false;

  const cmd = registry.get(ctx.command);
  if (!cmd) return false;

  // Permission checks
  if (cmd.ownerOnly && !ctx.SoDono) {
    await ctx.reply(ctx.mess?.onlyOwner?.() || "Hmph! Só o meu dono pode usar este comando... N-não fica chateado, são as regras!");
    return true;
  }

  if (cmd.groupOnly && !ctx.isGroup) {
    await ctx.reply(ctx.mess?.onlyGroup?.() || "Hmph! Esse comando só funciona em grupos... N-não é porque eu quero sua companhia, tá?!");
    return true;
  }

  if (cmd.adminOnly && !ctx.isGroupAdmins && !ctx.SoDono) {
    await ctx.reply(ctx.mess?.onlyAdmins?.() || "Hmph! Só administradores podem usar este comando... Você ainda não tem esse poder, bobinho(a)!");
    return true;
  }

  if (cmd.botAdminOnly && !ctx.isBotGroupAdmins) {
    await ctx.reply(ctx.mess?.onlyBotAdmin?.() || "Hmph! Preciso ser administradora pra executar este comando... Me promove logo, idiota!");
    return true;
  }

  try {
    if (typeof cmd.execute === "function") {
      await cmd.execute(ctx);
    } else if (typeof cmd.executar === "function") {
      await cmd.executar(ctx);
    }
    return true;
  } catch (err) {
    console.error(`[CommandDispatcher] Error executing ${cmd.name}:`, err);
    await ctx.reply(ctx.mess?.error?.() || "Hmph! Ocorreu um erro ao executar o comando... N-não fica bravo, tenta de novo, tá?!");
    return true;
  }
}

async function suggestCommand(command, prefix, comandos, similarityCmd, reagir, from, kira, selo, q = "") {
  const result = similarityCmd(command);
  const suggestion = result[0];
  const temSugestao = !!suggestion.comando && suggestion.comando !== "não encontrado";
  const msg = `- *⚠️ \`𝗖𝗢𝗠𝗔𝗡𝗗𝗢 𝗡𝗔𝗢 𝗘𝗡𝗖𝗢𝗡𝗧𝗥𝗔𝗗𝗢\`*\n` +
    `> *🚫 • ᴏ ᴄᴏᴍᴀɴᴅᴏ『 ${prefix}${command} 』ɴᴀᴏ ꜰᴏɪ ʀᴇᴄᴏɴʜᴇᴄɪᴅᴏ ɴᴏ ᴍᴇᴜ ʙᴀɴᴄᴏ ᴅᴇ ᴅᴀᴅᴏꜱ.` +
    (temSugestao ? ` ǫᴜᴇ ᴛᴀʟ ᴜꜱᴀʀ ᴏ ᴄᴏᴍᴀɴᴅᴏ ${suggestion.comando}? ᴇʟᴇ ᴛᴇᴍ ${suggestion.porcentagem}% ᴅᴇ ᴄʜᴀɴᴄᴇ ᴅᴇ ꜱᴇʀ ᴏ ǫᴜᴇ ᴠᴏᴄᴇ ᴘʀᴏᴄᴜʀᴀ.*` : `*`);

  reagir(from, "🫦");

  // Botões: MENU (volta pro menu) e SUGESTÃO (roda o comando sugerido com os mesmos argumentos que a pessoa digitou)
  const buttons = [{
    name: "quick_reply",
    buttonParamsJson: JSON.stringify({ display_text: "MENU", id: `${prefix}menu` })
  }];
  if (temSugestao) {
    const argumentos = String(q || "").trim();
    buttons.push({
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: "SUGESTÃO",
        id: argumentos ? `${suggestion.comando} ${argumentos}` : suggestion.comando
      })
    });
  }

  try {
    await kira.sendMessage(from, {
      interactiveMessage: { title: msg, footer: "Toque em um botão", buttons }
    }, { quoted: selo });
  } catch (err) {
    console.log("Falha ao enviar botões da sugestão:", err?.message || err);
    await kira.sendMessage(from, { text: msg }, { quoted: selo });
  }
}

module.exports = { handleCommand, suggestCommand };
