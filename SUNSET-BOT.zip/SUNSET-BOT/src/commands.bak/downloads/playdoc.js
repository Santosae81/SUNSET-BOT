module.exports = {
nome: ["ytdoc", "playdoc"],
executar: async ({
prefix,
command,
kira,
from,
reagir,
reply,
API_kira,
KEY_kira,
selo,
q,
CACHE_TTL,
fetchJson}) => {

if (!q) return reply(`📄 \`PLAY DOC\`\n\n> 🙇‍♂️ Digite o nome da música! Ex: ${prefix}${command} nome da música`);
reagir(from, "✅");
try {
const resu = await fetchJson(`${API_kira}/yt-search?titulo=${q}&apitoken=${KEY_kira}`);
let TextoPlay = resu.resultado.title;
let PlayLimitado = TextoPlay.toLowerCase().slice(0, 20) + '..';
var bla = `\n> *lıl.ılı.lıl.ıl『 PLAY DOC 』lıl.ılı.lıl.ıl*
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> *Hmph! Eu sou a melhor, então achei isso pra você... só não se acostume com essa atenção, baka!*
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> *✞ Título:* ${PlayLimitado}
> *✞ Canal:* ${resu.resultado?.author.name}
> *✞ Postado:* ${resu.resultado.ago || "indisponivel"}
> *✞ Views:* ${resu.resultado?.views}
> *✞ Formato:* DOC
> *✞ Descrição:* ${resu.resultado?.description || "não encontrado."}
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> ▶︎ •၊၊||၊|။||||။။||။။|||။• ${resu.resultado?.duration?.timestamp || "indisponivel."}`;
kira.sendMessage(from, {image: {url: `${API_kira}/canvas/musicard4?logo=${resu.resultado.thumbnail}&titulo=${PlayLimitado}&canal=${resu.resultado?.author?.name}&duracao=${resu.resultado?.duration?.timestamp}&apitoken=${KEY_kira}`}, caption: bla}, {quoted: selo});
await kira.sendMessage(from, {document: {url: `${API_kira}/youtube-audio2?url=${resu.resultado.url}&apitoken=${KEY_kira}`}, mimetype: "audio/mpeg", fileName: `${resu.resultado?.title}.mp3`}, {quoted: selo}).catch(async (error) => {
await kira.sendMessage(from, {document: {url: `${API_kira}/youtube-audio3?url=${resu.resultado.url}&qualidade=92&apitoken=${KEY_kira}`}, mimetype: "audio/mpeg", fileName: `${resu.resultado?.title}.mp3`}, {quoted: selo});
});
} catch (e) {
reagir(from, "❌");
console.log(e);
return reply(mess.error());
}
}
};
