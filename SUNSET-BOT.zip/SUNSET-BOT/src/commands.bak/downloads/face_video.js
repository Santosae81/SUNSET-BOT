module.exports = {
nome: ["face_video"],
executar: async ({
from,
mess,
q,
reagir,
reply,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

try {
if (!q.includes("facebook") && !q.includes("fb.watch")) return reply(`📘 \`FACEBOOK\`\n\n> 🙇‍♂️ Envie o link do vídeo do Facebook! Ex: ${prefix}${command} https://fb.watch/xxxx`);
reagir(from, '✅');
kira.sendMessage(from, {video: {url: `${API_kira}/face-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"});
} catch (e) {
return reply(mess.error());
}
}
};
