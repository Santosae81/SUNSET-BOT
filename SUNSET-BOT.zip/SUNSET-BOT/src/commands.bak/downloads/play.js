const yts = require("yt-search");

module.exports = {
nome: ["play"],
executar: async ({
kira,
from,
reagir,
reply,
selo,
q,
prefix,
command
}) => {

if (!q) return reply(`⚠️ \`PLAY\`\n\n> 🙇‍♂️ Digite o nome da música! Ex: ${prefix || "!"}${command || "play"} nome da música`);
reagir(from, "✅");
try {
// A busca é feita direto no YouTube (yt-search), sem depender da API
const busca = await yts(q);
const v = busca?.videos?.[0];
if (!v) {
reagir(from, "❌");
return reply("⚠️ `PLAY`\n\n> 🙇‍♂️ Não encontrei essa música!");
}

const legenda = `🎵 \`PLAY\`\n\n> 🎧 *Título:* ${String(v.title).slice(0, 60)}\n> 📺 *Canal:* ${v.author?.name || "indisponível"}\n> 🕒 *Duração:* ${v.duration?.timestamp || v.timestamp || "indisponível"}\n> 👁️ *Views:* ${v.views ?? "indisponível"}\n> 📅 *Postado:* ${v.ago || "indisponível"}`;
const idBotao = `${prefix || "!"}playaudio ${v.url}`;

try {
// Card com a capa e o botão ABAIXAR ÁUDIO (o clique roda o /playaudio)
await kira.sendMessage(from, {
interactiveMessage: {
title: legenda,
footer: "Toque no botão para baixar",
image: { url: v.thumbnail || v.image },
buttons: [{
name: "quick_reply",
buttonParamsJson: JSON.stringify({ display_text: "ABAIXAR ÁUDIO", id: idBotao })
}]
}
}, { quoted: selo });
} catch (err) {
// Se o botão não puder ser enviado, manda texto com o comando manual
console.log("Falha ao enviar o card com botão do play:", err?.message || err);
await reply(`${legenda}\n\n> ⬇️ Para baixar o áudio use: ${idBotao}`);
}
} catch (e) {
reagir(from, "❌");
console.log(e);
return reply("⚠️ `PLAY`\n\n> 🙇‍♂️ Erro ao buscar a música!");
}
}
};
