module.exports = {
nome: ["twitter_video","twtdl","twitter"],
executar: async ({
from,
mess,
q,
reagir,
reply,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

try {
if (!q.includes("twitter"))
return reply(`🐦 \`TWITTER\`\n\n> 🙇‍♂️ Envie o link do vídeo do Twitter! Ex: ${prefix}${command} https://twitter.com/xxxx`);
reagir(from, '✅');
kira.sendMessage(from, {video: {url: `${API_kira}/twt-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"});
} catch (e) {
return reply(mess.error());
}
}
};
