module.exports = {
nome: ["tiktok","tiktok_video"],
executar: async ({
prefix,
command,
from,
mess,
q,
reagir,
reply,
selo,
kira,
API_kira,
KEY_kira
}) => {

try {
if (!q) return reply(`🎵 \`TIKTOK\`\n\n> 🙇‍♂️ Envie o link do TikTok! Ex: ${prefix}${command} https://vm.tiktok.com/xxxx`);
reagir(from, '✅');
await kira.sendMessage(from, {video: {url: `${API_kira}/tiktok-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo});
} catch (error) {
console.log(error);
return reply(mess.error());
}
}
};
