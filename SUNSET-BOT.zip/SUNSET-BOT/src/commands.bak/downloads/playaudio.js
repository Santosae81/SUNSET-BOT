// Comando chamado pelo botão "ABAIXAR ÁUDIO" do /play.
// Também funciona digitando: !playaudio <link do YouTube>
const axios = require("axios");

// Rotas da Yuta APIs (confirmadas no SDK oficial "yutaapis"): /api/downloads/<rota>
// {url} vira o link do vídeo. Se quiser adicionar outra rota de reserva, coloque na lista.
const AUDIO_ENDPOINTS = [
"api/downloads/ytaudio2?url={url}",
];

const YT_REGEX = /^https?:\/\/(www\.|m\.|music\.)?(youtube\.com|youtu\.be)\//i;

// Baixa o áudio e confere se veio mesmo áudio (a API devolve JSON quando dá erro)
async function baixarAudio(urlApi) {
const inicio = Date.now();
const r = await axios.get(urlApi, {
responseType: "arraybuffer",
timeout: 120000,
maxContentLength: 80 * 1024 * 1024,
validateStatus: () => true,
});
const tipo = String(r.headers["content-type"] || "").toLowerCase();
const dados = Buffer.from(r.data);
console.log(`[playaudio] resposta: HTTP ${r.status} | ${tipo || "sem tipo"} | ${dados.length} bytes | ${((Date.now() - inicio) / 1000).toFixed(1)}s`);
if (r.status !== 200 || tipo.includes("json") || tipo.includes("text") || dados.length < 2000) {
let msg = "";
try { const j = JSON.parse(dados.toString("utf8")); msg = j.msg || j.message || j.error || ""; } catch {}
throw new Error(`HTTP ${r.status} (${tipo || "sem tipo"}) ${msg}`.trim());
}
return dados;
}

module.exports = {
nome: ["playaudio"],
executar: async ({
kira,
from,
reagir,
reply,
API_kira,
KEY_kira,
selo,
q,
prefix
}) => {

const link = (q || "").trim().split(/\s+/)[0];
if (!link || !YT_REGEX.test(link)) return reply(`⚠️ \`PLAY ÁUDIO\`\n\n> 🙇‍♂️ Envie um link válido do YouTube! Ex: ${prefix || "!"}playaudio https://youtu.be/...`);
reagir(from, "💽");

// manda o aviso e guarda a key pra editar depois
const aviso = await kira.sendMessage(from, {
  text: "⏳ `PLAY ÁUDIO`\n\n> 🎧 Baixando o áudio, aguarde..."
}, { quoted: selo });

const editar = (texto) =>
  kira.sendMessage(from, { text: texto, edit: aviso.key }).catch(e =>
    console.log("[playaudio] falha ao editar:", e?.message || e));

const base = String(API_kira || "").replace(/\/+$/, "");
const codificado = encodeURIComponent(link);
for (const rota of AUDIO_ENDPOINTS) {
  const urlApi = `${base}/${rota.replace("{url}", codificado)}&apitoken=${encodeURIComponent(KEY_kira)}`;
  try {
    console.log(`[playaudio] pedindo: ${rota.split("?")[0]}`);
    const audio = await baixarAudio(urlApi);
    await editar("✅ `PLAY ÁUDIO`\n\n> 🎧 Download concluído! Enviando o áudio...");
    await kira.sendMessage(from, { audio, mimetype: "audio/mpeg" }, { quoted: selo });
    console.log("[playaudio] áudio enviado.");
    return;
  } catch (err) {
    console.log(`Rota de áudio falhou (${rota.split("?")[0]}):`, err?.message || err);
  }
}

reagir(from, "❌");
return editar("⚠️ `PLAY ÁUDIO`\n\n> 🙇‍♂️ Não consegui baixar o áudio! Confira o token da API (pode ter expirado ou batido o limite diário).");
}
};
