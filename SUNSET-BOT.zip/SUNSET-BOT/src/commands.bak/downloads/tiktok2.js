module.exports = {
nome: ["tiktok2","tiktok_audio"],
executar: async ({
from,
mess,
q,
reagir,
reply,
selo,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

try {
if (!q.includes("tiktok")) return reply(`🎵 \`TIKTOK\`\n\n> 🙇‍♂️ Envie o link do TikTok! Ex: ${prefix}${command} https://vm.tiktok.com/xxxx`);
reagir(from, '✅');
kira.sendMessage(from, {audio: {url: `${API_kira}/tiktok-audio?url=${q}&apitoken=${KEY_kira}`}}, {quoted: selo});
} catch (e) {
console.log(e);
return reply(mess.error());
}
}
};
