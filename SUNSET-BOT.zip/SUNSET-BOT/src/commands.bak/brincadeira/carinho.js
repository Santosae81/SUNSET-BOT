module.exports = {
nome: ["carinho"],
executar: async ({
prefix,
command,
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
quoted,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
 if (typeof isModobn !== 'undefined' && !isModobn) return reply("Hmph! O modo brincadeira tá desativado... N-não é como se eu quisesse brincar mesmo, tá?!");
 if (!menc_os2) return reply(`🤗 \`CARINHO\`\n\n> 🙇‍♂️ Marque a mensagem ou o @ de quem vai receber o carinho! Ex: ${prefix}${command} @usuario`);
await kira.sendMessage(from, {video: {url: `https://telegra.ph/file/2b6b4f4e38214bd6164ce.mp4` },
gifPlayback: true, caption: `Você acabou de dar um carinho no(a) *@${menc_os2.split("@")[0]}* ✨... Hmph, não é como se eu fosse fazer isso por qualquer pessoa, viu?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};
