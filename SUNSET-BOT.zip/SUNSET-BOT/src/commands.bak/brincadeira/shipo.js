module.exports = {
nome: ["shipo"],
executar: async ({
command,
isGroup,
isModobn,
menc_os2,
mention,
mess,
prefix,
reply,
groupMembers
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply(`💘 \`SHIPO\`\n\n> 🙇‍♂️ Marque uma pessoa do grupo pra encontrar o par dela! Ex: ${prefix}${command} @usuario`);
 await mention(`♥️ Hmph! E-eu shipo *@${groupMembers[Math.floor(Math.random() * groupMembers.length)].id.split("@")[0]} & @${menc_os2.split("@")[0]}* com uma porcentagem de *${Math.floor(Math.random() * 100) + "%"}*... Não fica achando que eu faço isso por qualquer um, tá?!`);
}
};
