module.exports = {
nome: ["matar","mata"],
executar: async ({
command,
from,
isGroup,
isModobn,
matarcmd,
menc_os2,
mentions,
mess,
prefix,
quoted,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply(`🔪 \`MATAR\`\n\n> 🙇‍♂️ Marque a mensagem ou o @ de quem vai ser alvo! Ex: ${prefix}${command} @usuario`);
kira.sendMessage(from, {video: {url: matarcmd}, gifPlayback: true, caption: `Você acabou de matar o(a) *@${menc_os2.split("@")[0]}*, seu... 😵‍💫💅🏻 Hmph! Não é como se eu aprovasse, mas... tanto faz, baka!`,
mentions: [menc_os2]}, {quoted: selo});
}
};
