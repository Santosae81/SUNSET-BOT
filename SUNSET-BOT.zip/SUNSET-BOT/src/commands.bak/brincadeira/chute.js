module.exports = {
nome: ["chute","chutar"],
executar: async ({
command,
chutecmd,
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply(`🦵 \`CHUTE\`\n\n> 🙇‍♂️ Marque a mensagem ou o @ de quem vai levar o chute! Ex: ${prefix}${command} @usuario`);
await kira.sendMessage(from, {video: {url: chutecmd}, gifPlayback: true, caption: `Você acabou de dar um chute em *@${menc_os2.split("@")[0]}*... E-eu só fiz isso porque você pediu, não se acostume, tá?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};
