module.exports = {
nome: ["tapa"],
executar: async ({
command,
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
quoted,
reply,
selo,
tapacmd,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply(`👋 \`TAPA\`\n\n> 🙇‍♂️ Marque a mensagem ou o @ de quem vai levar o tapa! Ex: ${prefix}${command} @usuario`);
await kira.sendMessage(from, {video: {url: tapacmd}, gifPlayback: true, caption: `Você acabou de dar um tapa na raba de *@${menc_os2.split("@")[0]}*. 😼 Hmph! Não é como se eu tivesse ajudado, claro, tá?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};
