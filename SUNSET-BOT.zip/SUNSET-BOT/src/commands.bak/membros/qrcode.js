module.exports = {
nome: ["qrcode","gerarqr"],
executar: async ({
prefix,
command,
from,
image,
mess,
q,
reply,
selo,
kira
}) => {

if (!q) return reply(`🔳 \`QRCODE\`\n\n> 🙇‍♂️ Digite um link ou texto! Ex: ${prefix}${command} https://google.com`);
try {
await kira.sendMessage(from, {image: {url: `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${q}`},
caption: `💫 Hmph! 𝐒𝐞𝐮 𝐪𝐫 𝐜𝐨𝐝𝐞 𝐟𝐨𝐢 𝐠𝐞𝐫𝐚𝐝𝐨 𝐜𝐨𝐧𝐭𝐞𝐧𝐝𝐨 𝐨 𝐭𝐞𝐱𝐭𝐨/𝐮𝐫𝐥 𝐞𝐬𝐩𝐞𝐜𝐢𝐟𝐢𝐜𝐚𝐝𝐨 𝐚𝐨 𝐥𝐚𝐝𝐨: *${q}*... Eu que fiz, então agradece, viu?!`}, {quoted: selo});
} catch (e) {
return reply(mess.error());
}
}
};
