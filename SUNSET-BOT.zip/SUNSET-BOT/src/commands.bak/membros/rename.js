module.exports = {
nome: ["rename","roubar"],
executar: async ({
Buffer,
author2,
bas64,
command,
convertSticker,
encmediats,
from,
getFileBuffer,
info,
isQuotedSticker,
mess,
pack,
prefix,
q,
quoted,
reagir,
reply,
selo,
sticker,
kira
}) => {

if (!isQuotedSticker) return reply(`🏷️ \`RENAME\`\n\n> 🙇‍♂️ Marque uma figurinha!`);
encmediats = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, "sticker");
[pack, author2] = q.split("|");
if (!q) return reply(`🏷️ \`RENAME\`\n\n> 🙇‍♂️ Digite o novo pacote e autor da figurinha! Ex: ${prefix}${command} pacote|autor`);
if (!pack) return reply(`Hmph! Faça o certo, invés do errado, senhor(a)! Aqui está a fórmula correta de uso: *${prefix + command} pacote|autor* (e não se esqueça de responder o sticker que quer renomear, certo?).. Eu não vou repetir, viu?!`);
if (!author2) return reply(`Hmph! Faça o certo, invés do errado, senhor(a)! Aqui está a fórmula correta de uso: *${prefix + command} pacote|autor* (e não se esqueça de responder o sticker que quer renomear, certo?).. Eu não vou repetir, viu?!`);
await reagir(from, '✅');
bas64 = `data:image/jpeg;base64,${encmediats.toString("base64")}`;
var mantap = await convertSticker(bas64, pack, author2);
var sti = new Buffer.from(mantap, "base64");
await kira.sendMessage(from, {sticker: sti}, {quoted: selo}).catch(async (error) => {
reply(mess.error());
});
}
};
