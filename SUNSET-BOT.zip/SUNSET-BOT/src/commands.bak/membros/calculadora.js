module.exports = {
nome: ["calculadora", "calcular", "calc"],
executar: async ({ q, reply, prefix, command }) => {

if (!q) return reply(`Hmph! Cadê a conta, baka? Ex: *${prefix + command} 2+2*5*`);
// só números e operadores — nada de eval em texto livre
const conta = q.replace(/,/g, ".").replace(/[x×]/gi, "*").replace(/÷/g, "/").replace(/\^/g, "**").replace(/\s+/g, "");
if (!/^[0-9+\-*/%.()]+$/.test(conta) || conta.length > 60) return reply("Hmph! Só aceito números e os sinais + - * / % ^ ( ), tá?! Não tenta me enganar, baka!");
try {
const r = Function(`"use strict"; return (${conta})`)();
if (typeof r !== "number" || !isFinite(r)) return reply("Hmph! Essa conta não tem resultado... divisão por zero, por acaso, bobinho(a)?!");
return reply(`Hmph! Eu que calculei pra você, então agradece.. Resultado: *${Math.round(r * 1e10) / 1e10}* ...não se acostume com isso, tá?!`);
} catch {
return reply("Hmph! Essa conta tá torta... confere os parênteses, baka!");
}
}
};
