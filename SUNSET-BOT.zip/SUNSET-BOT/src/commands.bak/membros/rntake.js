module.exports = {
nome: ["rntake"],
executar: async ({
command,
fs,
prefix,
q,
reply,
rgtake,
sender
}) => {

i8 = rgtake.map((i) => i.usuario).indexOf(sender);
if (i8 < 0) return reply(`Hmph! Como você quer renomear algo que você nem tem registro? Baka! Use *${prefix}rgtake* primeiro, viu?!`);
if (!q.includes("|")) return reply(`🏷️ \`RN TAKE\`\n\n> 🙇‍♂️ Digite o pacote e o autor separados por |! Ex: ${prefix}${command} wa|bot`);
var [MARCAD1, MARCAD2] = q.split("|");
if (!MARCAD1) return reply(`🏷️ \`RN TAKE\`\n\n> 🙇‍♂️ Digite o pacote e o autor separados por |! Ex: ${prefix}${command} wa|bot`);
if (!MARCAD2) return reply(`🏷️ \`RN TAKE\`\n\n> 🙇‍♂️ Digite o pacote e o autor separados por |! Ex: ${prefix}${command} wa|bot`);
rgtake[i8].mcdagua1 = MARCAD1;
rgtake[i8].mcdagua2 = MARCAD2;
reply(`Hmph! Sua marca ďágua foi alterada para *"${MARCAD1}|${MARCAD2}"* com sucesso.. N-não é porque eu me importo, tá? Só fiz porque quis!`);
}
};
