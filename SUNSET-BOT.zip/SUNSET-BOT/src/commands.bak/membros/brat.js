// /brat <texto>   -> figurinha brat estática (imagem)
// /brat 2 <texto> -> figurinha brat animada (vídeo)   (também: /brat2 <texto>)
// Rotas da Yuta APIs (confirmadas no SDK "yutaapis"): /api/stickers/brat-img e /api/stickers/brat-vid (param: text).
const ROTAS = {
  estatico: ["api/stickers/brat-img?text={texto}"],
  animado: ["api/stickers/brat-vid?text={texto}"],
};
const axios = require("axios");

async function baixarMidia(urlApi, tag) {
  const inicio = Date.now();
  const r = await axios.get(urlApi, {
    responseType: "arraybuffer",
    timeout: 90000,
    maxContentLength: 30 * 1024 * 1024,
    validateStatus: () => true,
  });
  const tipo = String(r.headers["content-type"] || "").toLowerCase();
  const dados = Buffer.from(r.data);
  console.log(`[${tag}] resposta: HTTP ${r.status} | ${tipo || "sem tipo"} | ${dados.length} bytes | ${((Date.now() - inicio) / 1000).toFixed(1)}s`);
  if (r.status !== 200 || tipo.includes("json") || tipo.includes("text") || dados.length < 500) {
    let msg = "";
    try { const j = JSON.parse(dados.toString("utf8")); msg = j.msg || j.message || j.error || ""; } catch {}
    throw new Error(`HTTP ${r.status} (${tipo || "sem tipo"}) ${msg}`.trim());
  }
  return dados;
}

module.exports = {
  nome: ["brat", "brat2", "bratvid"],
  executar: async ({
    kira, from, reagir, reply, selo, q, prefix, command,
    API_kira, KEY_kira, NomeDoBot, pushname,
    sendImageAsSticker2, sendVideoAsSticker2, DLT_FL
  }) => {
    let texto = (q || "").trim();
    let animado = command === "brat2" || command === "bratvid";
    if (command === "brat" && /^2(\s|$)/.test(texto)) {
      animado = true;
      texto = texto.replace(/^2\s*/, "");
    }
    const titulo = animado ? "BRAT 2" : "BRAT";
    if (!texto) {
      return reply(`🎨 \`BRAT\`\n\n> 🙇‍♂️ Envie um texto! Ex: ${prefix}brat seu texto\n> 🎬 Animada: ${prefix}brat 2 seu texto`);
    }

    const tag = animado ? "bratvid" : "brat";
    const base = String(API_kira || "").replace(/\/+$/, "");
    const codificado = encodeURIComponent(texto);
    const opcoes = {
      packname: `🤖 ${NomeDoBot || "Bot"}`,
      author: `\n🌟 ${pushname || ""}`,
    };

    reagir(from, "✅️");
    for (const rota of (animado ? ROTAS.animado : ROTAS.estatico)) {
      const urlApi = `${base}/${rota.replace("{texto}", codificado)}&apitoken=${encodeURIComponent(KEY_kira)}`;
      try {
        console.log(`[${tag}] pedindo: ${rota.split("?")[0]}`);
        const midia = await baixarMidia(urlApi, tag);
        const enviar = animado ? sendVideoAsSticker2 : sendImageAsSticker2;
        const enc = await enviar(kira, from, midia, selo, opcoes);
        if (typeof DLT_FL === "function") await DLT_FL(enc);
        return;
      } catch (err) {
        console.log(`[${tag}] rota falhou (${rota.split("?")[0]}):`, err?.message || err);
      }
    }

    reagir(from, "❌");
    return reply(`⚠️ \`${titulo}\`\n\n> 🙇‍♂️ Não consegui gerar a figurinha! Confira o token da API (pode ter expirado ou batido o limite diário).`);
  }
};
