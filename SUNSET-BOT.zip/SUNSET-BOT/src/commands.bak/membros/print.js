module.exports = {
nome: ["print","printsite"],
executar: async ({
command,
from,
prefix,
q,
quoted,
reagir,
reply,
selo,
kira,
API_kira,
KEY_kira
}) => {

if(!q.trim()) return reply(`📸 \`PRINT\`\n\n> 🙇‍♂️ Envie a URL do site! Ex: ${prefix}${command} https://google.com`)
reagir(from, "✅️");
try {
kira.sendMessage(from, {image: {url: `${API_kira}/screenshot?url=${q.trim()}&apitoken=${KEY_kira}`}}, {quoted: selo});
} catch {
reagir(from, "❌️");
}
}
};
