module.exports = {
nome: ["figumemes"],
executar: async ({
prefix,
command,
args,
isGroup,
q,
reply,
sender,
sleep,
kira
}) => {

if(!q) return reply(`🖼️ \`FIGU MEMES\`\n\n> 🙇‍♂️ Digite a quantidade de figurinhas! Ex: ${prefix}${command} 5`);
if (!Number(args[0]) || Number(q.trim()) > 10) return reply("❌️ Hmph! A quantidade acima de 10 não é permitida.. Eu sou boa nisso, sei bem o limite, baka!");
if (!isGroup) return reply("🤖♥️ Hmph! Vou enviar no pv pra não floodar o grupo.. Não é porque eu me importo com a sua figurinha, tá?!");
async function FigurinhasMemes() {
figk = `${Math.floor(Math.random() * 25)}`
await kira.sendMessage(sender, {sticker: {url: `https://raw.githubusercontent.com/badDevelopper/figus2/main/figengracada/${figk}.webp`}});
}
for (i = 0; i < q; i++) {
await sleep(500);
await FigurinhasMemes();
}
}
};
