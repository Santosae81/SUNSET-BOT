const axios = require("axios");
const { proximas, marcarUsada } = require("../../utils/pinterest");

// Busca de fotos engracadas no Pinterest pra cada comando
const BUSCA = {
aesthetic: "funny aesthetic memes",
anjing: "funny dog memes",
blackpink: "blackpink funny memes",
boneka: "funny dolls memes",
cecan: "funny girl memes",
cosplay: "funny cosplay fails",
dadu: "funny dice memes",
hekel: "funny hacker memes",
justina: "justin bieber funny memes",
kayes: "funny memes",
kpop: "kpop funny memes",
kucing: "funny cat memes",
mobil: "funny car memes",
montor: "funny motorcycle memes",
notnot: "funny profile picture memes",
profil: "funny profile picture",
pubg: "pubg funny memes",
rose: "rose blackpink funny memes",
ryujin: "ryujin itzy funny memes",
wallhp: "funny phone wallpaper",
wallml: "mobile legends funny memes"
};

module.exports = {
nome: ["aesthetic", "anjing", "blackpink", "boneka", "cecan", "cosplay", "dadu", "hekel", "justina", "kayes", "kpop", "kucing", "mobil", "montor", "notnot", "profil", "pubg", "rose", "ryujin", "wallhp", "wallml"],
executar: async ({ from, info, command, reagir, reply, kira }) => {
reagir(from, "😂");
try {
const termo = BUSCA[command] || `${command} funny memes`;
const legenda = `😂 \`${command.toUpperCase()}\`\n\n> 🖼️ Foto aleatória, essa não se repete!`;
// so traz imagens que ainda nao foram enviadas (nunca repete)
const tentativas = await proximas(termo, 3);
if (!tentativas.length) throw new Error("Pinterest sem resultados para: " + termo);

let enviado = false;
for (const url of tentativas) {
try {
await kira.sendMessage(from, { image: { url }, caption: legenda }, { quoted: info });
enviado = true; marcarUsada(termo, url); break;
} catch (e1) {
try {
const { data } = await axios.get(url, { responseType: "arraybuffer", timeout: 20000, headers: { "User-Agent": "Mozilla/5.0" } });
await kira.sendMessage(from, { image: Buffer.from(data), caption: legenda }, { quoted: info });
enviado = true; marcarUsada(termo, url); break;
} catch (e2) { /* proxima */ }
}
}
if (!enviado) throw new Error("nao consegui enviar nenhuma imagem");
reagir(from, "✅");
} catch (e) {
console.log("[imagensvariadas]", e?.message || e);
reagir(from, "❌");
reply(`😂 \`IMAGEM NÃO ENCONTRADA\`\n\n> 🙇‍♂️ Não achei essa imagem... tenta de novo!`);
}
}
};
