const { GPT } = require("../../../arquivos/funcoes/functions.js");

module.exports = {
nome: ["pergunta", "openai", "gpt", "chatgpt", "gpt-3.5", "chatgpt-3.5"],
executar: async ({ from, mess, q, reagir, reply, prefix, command }) => {

if (!q) return reply(`Hmph! Pergunta o quê, baka? Ex: *${prefix + command} qual a capital da França?*`);
try {
reagir(from, "✅");
const r = await GPT.handler("12345", q);
reply(`Hmph! Eu até perdi meu tempo pensando nisso pra você... toma: ${r.payload.response}`);
} catch {
return reply(mess.error());
}
}
};
