const axios = require("axios");
const { proximas, marcarUsada } = require("../../utils/pinterest");

// Termo de busca no Pinterest para cada comando (padrao: "<comando> anime")
const BUSCA = {
islamic: "islamic aesthetic wallpaper",
mountain: "mountain landscape wallpaper",
programming: "programming setup wallpaper",
kartun: "cartoon characters",
katakata: "anime quotes aesthetic",
wallhp2: "anime wallpaper phone",
cogan: "anime boy aesthetic",
cogan2: "cool anime boy",
nekonime: "neko anime girl",
waifu: "anime waifu",
onepiece: "one piece anime",
doraemon: "doraemon",
pokemon: "pokemon"
};

module.exports = {
nome: ["akira", "akiyama", "ana", "asuna", "ayuzawa", "boruto", "chiho", "chitoge", "cogan", "cogan2", "deidara", "doraemon", "eba", "elaina", "emilia", "erza", "gremory", "hestia", "hinata", "inori", "islamic", "isuzu", "itachi", "itori", "kaga", "kagura", "kakasih", "kaori", "kartun", "katakata", "keneki", "kotori", "kurumi", "madara", "megumin", "mikasa", "miku", "minato", "mountain", "naruto", "nekonime", "nezuko", "onepiece", "pokemon", "programming", "rize", "sagiri", "sakura", "sasuke", "shina", "shinka", "shinomiya", "shizuka", "tejina", "toukachan", "tsunade", "waifu", "wallhp2", "yotsuba", "yuki", "yumeko"],
executar: async ({ from, info, command, reagir, reply, kira }) => {
reagir(from, "🖼️");
try {
const termo = BUSCA[command] || `${command} anime`;
const tentativas = await proximas(termo, 3);
if (!tentativas.length) throw new Error("Pinterest sem resultados para: " + termo);
let enviado = false;
for (const url of tentativas) {
try {
await kira.sendMessage(from, { image: { url } }, { quoted: info });
enviado = true; marcarUsada(termo, url); break;
} catch (e1) {
try {
const { data } = await axios.get(url, { responseType: "arraybuffer", timeout: 20000, headers: { "User-Agent": "Mozilla/5.0" } });
await kira.sendMessage(from, { image: Buffer.from(data) }, { quoted: info });
enviado = true; marcarUsada(termo, url); break;
} catch (e2) { /* proxima */ }
}
}
if (!enviado) throw new Error("nao consegui enviar nenhuma imagem");
reagir(from, "✅");
} catch (e) {
console.log("[imagensanime]", e?.message || e);
reagir(from, "❌");
reply("Hmph! Essa imagem não veio... tenta de novo, bobinho(a)!");
}
}
};
