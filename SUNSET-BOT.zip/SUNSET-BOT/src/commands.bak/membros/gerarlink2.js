module.exports = {
nome: ["gerarlink2","imgpralink2","upload2"],
executar: async ({
prefix,
command,
fetchJson,
from,
gerarlinkUploadMedia,
getFileBuffer,
info,
isQuotedImage,
isQuotedSticker,
isQuotedVideo,
mediaBuffer,
reagir,
reply,
}) => {

{
try {
await reagir(from, "✅️");
if (isQuotedImage || isQuotedVideo || isQuotedSticker) {
const gerarlinkBoij = isQuotedImage ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.imageMessage : info.message.imageMessage;
const FormData = require("form-data");
async function gerarlinkUploadMedia(mediaBuffer) {
const gerarlinkForm = new FormData();
gerarlinkForm.append("image", mediaBuffer, {
filename: "media",
});

const gerarlinkData = await fetchJson("https://api.imgur.com/3/image", {
method: "POST",
body: gerarlinkForm,
headers: {
Authorization: "Client-ID 400116076ba4b73",
},
});

if (gerarlinkData && gerarlinkData.data && gerarlinkData.data.link) {
return gerarlinkData.data.link;
} else {
throw new Error("Falha ao recuperar o URL do Imgur.");
}
};
const gerarlinkMediaBuffer = await getFileBuffer(
gerarlinkBoij,
isQuotedImage ? "image" : "video");
const gerarlinkMediaUrl = await gerarlinkUploadMedia(gerarlinkMediaBuffer);
reply(`Hmph! ᥉ᥱᥙ ᥣιᥒk ᥴ᥆ᥒ᥎ᥱrtιd᥆:\n${gerarlinkMediaUrl}\nProntinho, viu?! Só desta vez!`);
} else {
reply(`🔗 \`GERAR LINK\`\n\n> 🙇‍♂️ Marque uma imagem, vídeo ou figurinha!`);
}
} catch (e) {
console.log(e);
await reagir(from, '❌');
reply("Hmph! Erro ao tentar converter a mídia para link.. Que droga, mas não se acostume com isso, tá?!");
}
}
}
};
