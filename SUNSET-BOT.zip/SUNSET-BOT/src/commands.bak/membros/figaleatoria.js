module.exports = {
nome: ["figaleatoria"],
executar: async ({
prefix,
command,
args,
isGroup,
q,
reply,
sender,
sleep,
kira
}) => {

if(!q) return reply(`🖼️ \`FIGU ALEATÓRIA\`\n\n> 🙇‍♂️ Digite a quantidade de figurinhas! Ex: ${prefix}${command} 5`);
if (!Number(args[0]) || Number(q.trim()) > 10) return reply("❌️ Hmph! Não é permitido colocar a quantidade acima de 10.. Acha que eu vou fazer esse trabalho todo por você?!");
if (!isGroup) return reply("🤖♥️ Hmph! Estou enviando no pv, por motivo de flood no grupo.. Não me entenda mal, é só pra não fazer bagunça, viu?!");
async function FigurinhasAleatorias() {
figs = `${Math.floor(Math.random() * 7050)}`
await kira.sendMessage(sender, {sticker: {url: `https://raw.githubusercontent.com/badDevelopper/Testfigu/main/fig (${figs}).webp`}});
}
for (i = 0; i < q; i++) {
await sleep(500);
await FigurinhasAleatorias();
}
}
};
