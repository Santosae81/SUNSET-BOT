module.exports = {
nome: ["rgtake"],
executar: async ({
fs,
q,
prefix,
command,
reply,
rgtake,
rgtakergtake,
sender
}) => {

var [TP, TP2] = q.split("|");
rgtakergtake = [];
for (i of rgtake) {
rgtakergtake.push(i.usuario);
}
if (rgtakergtake.indexOf(sender) >= 0)
return reply("Hmph! Você já registrou sua marca ďagua, não é possível usar esse comando novamente.. Tanto faz, baka!");
if (!q.includes("|")) return reply(`🏷️ \`RG TAKE\`\n\n> 🙇‍♂️ Digite o pacote e o autor separados por |! Ex: ${prefix}${command} wa|bot`);
if (!TP) return reply(`🏷️ \`RG TAKE\`\n\n> 🙇‍♂️ Digite o pacote e o autor separados por |! Ex: ${prefix}${command} wa|bot`);
if (!TP2) return reply(`🏷️ \`RG TAKE\`\n\n> 🙇‍♂️ Digite o pacote e o autor separados por |! Ex: ${prefix}${command} wa|bot`);
rgtake.push({ usuario: sender, mcdagua1: TP, mcdagua2: TP2 });
reply(`Hmph! Sucesso ao concluir o registro... Agora você pode usar o comando: *${prefix}take*.. Não se acostume, viu?!`);
}
};
