module.exports = {
nome: ["redacao"],
executar: async ({
prefix,
command,
fetchJson,
from,
mess,
q,
reply,
selo,
kira
}) => {

if (!q) return reply(`📝 \`REDAÇÃO\`\n\n> 🙇‍♂️ Digite o tema da redação! Ex: ${prefix}${command} violência`);
try {
let { key } = await kira.sendMessage(from, {text: `Hmph! Aguarda aí que eu estou processando sua solicitação.. Isso pode levar alguns segundos.. N-não fica impaciente, viu?!`}, {quoted: selo});
promptUser = `Crie um texto dissertativo-argumentativo com o tema: ${q}`;
anu1 = await fetchJson(`https://aemt.me/gpt4?text=${promptUser}`);
await kira.sendMessage(from, {text: mess.respostaRedacao(anu1), edit: key});
} catch (error) {
return reply(mess.error());
}
}
};
