
exports.menuPrincipal = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}
┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}
┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}
┃ ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎: ${prefix}
┃ 📦 𝐁𝐀𝐈𝐋𝐄𝐘𝐒: ${(() => { try { return require("zapo-js/package.json").version; } catch { return "-"; } })()}
┃ ⏳ 𝐔𝐏𝐓𝐈𝐌𝐄: ${(() => { const u = process.uptime(); return Math.floor(u / 3600) + "h " + Math.floor((u % 3600) / 60) + "m " + Math.floor(u % 60) + "s"; })()}
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗠𝗲 𝗰𝗼𝗻𝗵𝗲𝗰̧𝗮 𝗺𝗲𝗹𝗵𝗼𝗿
┃ ➜ ${prefix}dados
┃ ➜ ${prefix}criador
┃ ➜ ${prefix}infobv
┃ ➜ ${prefix}ping
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗕𝗮𝗶𝘅𝗮𝗿 𝗽𝗿𝗮 𝘃𝗼𝗰𝗲̂
┃ ➜ ${prefix}play
┃ ➜ ${prefix}playvid
┃ ➜ ${prefix}playdoc
┃ ➜ ${prefix}tiktok
┃ ➜ ${prefix}tiktok_audio
┃ ➜ ${prefix}instagram
┃ ➜ ${prefix}facebook
┃ ➜ ${prefix}mediafire
┃ ➜ ${prefix}pinterest
┃ ➜ ${prefix}pinvideo
┃ ➜ ${prefix}tiktok_video
┃ ➜ ${prefix}tiktok2
┃ ➜ ${prefix}face_video
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗕𝘂𝘀𝗰𝗮𝘀 𝗲 𝗽𝗲𝘀𝗾𝘂𝗶𝘀𝗮𝘀
┃ ➜ ${prefix}transcrever
┃ ➜ ${prefix}celular
┃ ➜ ${prefix}amazon
┃ ➜ ${prefix}printsite
┃ ➜ ${prefix}gimage
┃ ➜ ${prefix}pinterest
┃ ➜ ${prefix}ytsearch
┃ ➜ ${prefix}scep
┃ ➜ ${prefix}animesearch
┃ ➜ ${prefix}aptoide
┃ ➜ ${prefix}binance
┃ ➜ ${prefix}carbon
┃ ➜ ${prefix}clima
┃ ➜ ${prefix}codestral
┃ ➜ ${prefix}coin
┃ ➜ ${prefix}dafont
┃ ➜ ${prefix}deepseek
┃ ➜ ${prefix}encomenda
┃ ➜ ${prefix}futeareas
┃ ➜ ${prefix}futebol
┃ ➜ ${prefix}github
┃ ➜ ${prefix}gitrepo
┃ ➜ ${prefix}gptimage
┃ ➜ ${prefix}groq
┃ ➜ ${prefix}handwriting
┃ ➜ ${prefix}horoscopo
┃ ➜ ${prefix}igstalk
┃ ➜ ${prefix}imagine
┃ ➜ ${prefix}mistral
┃ ➜ ${prefix}nasa
┃ ➜ ${prefix}newsbbc
┃ ➜ ${prefix}newscnn
┃ ➜ ${prefix}newstube
┃ ➜ ${prefix}pensador
┃ ➜ ${prefix}pesquisaytb
┃ ➜ ${prefix}sauracnn
┃ ➜ ${prefix}sauranews
┃ ➜ ${prefix}saurasource
┃ ➜ ${prefix}screenshot
┃ ➜ ${prefix}spotify-search
┃ ➜ ${prefix}spotify
┃ ➜ ${prefix}tgstalk
┃ ➜ ${prefix}threadstalk
┃ ➜ ${prefix}tiktokstalk
┃ ➜ ${prefix}tradutor
┃ ➜ ${prefix}wallsearch
┃ ➜ ${prefix}worldnews
┃ ➜ ${prefix}ytplaylist
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗙𝗶𝗴𝘂𝗿𝗶𝗻𝗵𝗮𝘀 𝗽𝗿𝗮 𝘃𝗼𝗰𝗲̂
┃ ➜ ${prefix}rename
┃ ➜ ${prefix}fsticker
┃ ➜ ${prefix}sticker
┃ ➜ ${prefix}toimg
┃ ➜ ${prefix}attp
┃ ➜ ${prefix}roubar
┃ ➜ ${prefix}take
┃ ➜ ${prefix}rgtake
┃ ➜ ${prefix}ttp_white
┃ ➜ ${prefix}ttp_brat
┃ ➜ ${prefix}brat
┃ ➜ ${prefix}brat 2
┃ ➜ ${prefix}figaleatoria
┃ ➜ ${prefix}figuemoji
┃ ➜ ${prefix}figuflork
┃ ➜ ${prefix}figumemes
┃ ➜ ${prefix}figucoreana
┃ ➜ ${prefix}figuanime
┃ ➜ ${prefix}figuanimais
┃ ➜ ${prefix}figudesenho
┃ ➜ ${prefix}figuraiva
┃ ➜ ${prefix}figubebe
┃ ➜ ${prefix}figuroblox
┃ ➜ ${prefix}rntake
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗦𝗼́ 𝗽𝗿𝗮 𝗾𝘂𝗲𝗺 𝗲́ 𝗱𝗲 𝗺𝗮𝗶𝗼𝗿
┃ ➜ ${prefix}plaq
┃ ➜ ${prefix}plaq1
┃ ➜ ${prefix}plaq2
┃ ➜ ${prefix}plaq3
┃ ➜ ${prefix}plaq4
┃ ➜ ${prefix}plaq5
┃ ➜ ${prefix}plaq6
┃ ➜ ${prefix}plaq7
┃ ➜ ${prefix}plaq8
┃ ➜ ${prefix}plaq9
┃ ➜ ${prefix}plaq10
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗗𝗶𝘃𝗲𝗿𝘀𝗮̃𝗼 𝗲 𝗯𝗿𝗶𝗻𝗰𝗮𝗱𝗲𝗶𝗿𝗮
┃ ➜ ${prefix}getperfil
┃ ➜ ${prefix}metadinha
┃ ➜ ${prefix}obesidade
┃ ➜ ${prefix}gerarlink2
┃ ➜ ${prefix}imgpralink
┃ ➜ ${prefix}upload
┃ ➜ ${prefix}playstore
┃ ➜ ${prefix}encurtalink
┃ ➜ ${prefix}countdays
┃ ➜ ${prefix}gerarqr
┃ ➜ ${prefix}contardias
┃ ➜ ${prefix}fazernick
┃ ➜ ${prefix}calcular
┃ ➜ ${prefix}gitclone
┃ ➜ ${prefix}qrcode
┃ ➜ ${prefix}hd
┃ ➜ ${prefix}wame
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`;
};

exports.adms = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}
┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}
┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}
┃ ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎: ${prefix}
┃ 📦 𝐁𝐀𝐈𝐋𝐄𝐘𝐒: ${(() => { try { return require("zapo-js/package.json").version; } catch { return "-"; } })()}
┃ ⏳ 𝐔𝐏𝐓𝐈𝐌𝐄: ${(() => { const u = process.uptime(); return Math.floor(u / 3600) + "h " + Math.floor((u % 3600) / 60) + "m " + Math.floor(u % 60) + "s"; })()}
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗣𝗿𝗮 𝗾𝘂𝗲𝗺 𝗺𝗮𝗻𝗱𝗮 𝗻𝗼 𝗴𝗿𝘂𝗽𝗼
┃ ➜ ${prefix}antiimg
┃ ➜ ${prefix}antivideo
┃ ➜ ${prefix}antiaudio
┃ ➜ ${prefix}antisticker
┃ ➜ ${prefix}antiloc
┃ ➜ ${prefix}anticontato
┃ ➜ ${prefix}antidoc
┃ ➜ ${prefix}antilinkhard
┃ ➜ ${prefix}antilink
┃ ➜ ${prefix}antiporno
┃ ➜ ${prefix}bemvindo
┃ ➜ ${prefix}antilinkgp
┃ ➜ ${prefix}antispam
┃ ➜ ${prefix}setantispam
┃ ➜ ${prefix}agendargp
┃ ➜ ${prefix}delagendargp
┃ ➜ ${prefix}antilinkeasy
┃ ➜ ${prefix}prefixos
┃ ➜ ${prefix}add_prefixo
┃ ➜ ${prefix}tirar_prefixo
┃ ➜ ${prefix}multiprefix
┃ ➜ ${prefix}antinotas
┃ ➜ ${prefix}antistatus
┃ ➜ ${prefix}anticatalogo
┃ ➜ ${prefix}legendabv
┃ ➜ ${prefix}legendabv2
┃ ➜ ${prefix}legendasaiu
┃ ➜ ${prefix}mute
┃ ➜ ${prefix}desmute
┃ ➜ ${prefix}roletarussa
┃ ➜ ${prefix}simih
┃ ➜ ${prefix}autosticker
┃ ➜ ${prefix}autodown
┃ ➜ ${prefix}autorepo
┃ ➜ ${prefix}odelete
┃ ➜ ${prefix}autofigu
┃ ➜ ${prefix}x9visuunica
┃ ➜ ${prefix}x9
┃ ➜ ${prefix}so_adm
┃ ➜ ${prefix}descriçãogp
┃ ➜ ${prefix}fotogp
┃ ➜ ${prefix}linkgroup
┃ ➜ ${prefix}novolink
┃ ➜ ${prefix}recrutar
┃ ➜ ${prefix}aceitar
┃ ➜ ${prefix}recusar
┃ ➜ ${prefix}regras
┃ ➜ ${prefix}cita
┃ ➜ ${prefix}linkproibido
┃ ➜ ${prefix}addlink
┃ ➜ ${prefix}listalinks
┃ ➜ ${prefix}dellink
┃ ➜ ${prefix}marcarwa
┃ ➜ ${prefix}listadmins
┃ ➜ ${prefix}inativos
┃ ➜ ${prefix}deletar
┃ ➜ ${prefix}revelar
┃ ➜ ${prefix}add 5511...
┃ ➜ ${prefix}reviver
┃ ➜ ${prefix}kick [@]
┃ ➜ ${prefix}ban
┃ ➜ ${prefix}ban2
┃ ➜ ${prefix}promover [@]
┃ ➜ ${prefix}rebaixar [@]
┃ ➜ ${prefix}descgp
┃ ➜ ${prefix}nomegp
┃ ➜ ${prefix}totag
┃ ➜ ${prefix}grupo
┃ ➜ ${prefix}status
┃ ➜ ${prefix}limpar
┃ ➜ ${prefix}linkgp
┃ ➜ ${prefix}revlinkgp
┃ ➜ ${prefix}grupoinfo
┃ ➜ ${prefix}hidetag
┃ ➜ ${prefix}listafake
┃ ➜ ${prefix}listafakes
┃ ➜ ${prefix}brlist
┃ ➜ ${prefix}listabr
┃ ➜ ${prefix}listaddi
┃ ➜ ${prefix}ddilist
┃ ➜ ${prefix}listaddd
┃ ➜ ${prefix}dddlist
┃ ➜ ${prefix}marcar
┃ ➜ ${prefix}marcar2
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`;
};

exports.menudono = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}
┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}
┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}
┃ ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎: ${prefix}
┃ 📦 𝐁𝐀𝐈𝐋𝐄𝐘𝐒: ${(() => { try { return require("zapo-js/package.json").version; } catch { return "-"; } })()}
┃ ⏳ 𝐔𝐏𝐓𝐈𝐌𝐄: ${(() => { const u = process.uptime(); return Math.floor(u / 3600) + "h " + Math.floor((u % 3600) / 60) + "m " + Math.floor(u % 60) + "s"; })()}
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗥𝗲𝘀𝗲𝗿𝘃𝗮𝗱𝗼 𝗽𝗿𝗮 𝘃𝗼𝗰𝗲̂, 𝗺𝗲𝘂 𝗱𝗼𝗻𝗼
┃ ➜ ${prefix}prefixo-bot
┃ ➜ ${prefix}sairgp
┃ ➜ ${prefix}convite
┃ ➜ ${prefix}entrar
┃ ➜ ${prefix}seradm
┃ ➜ ${prefix}reiniciar
┃ ➜ ${prefix}getcase
┃ ➜ ${prefix}sermembro
┃ ➜ ${prefix}nome-bot
┃ ➜ ${prefix}nick-dono
┃ ➜ ${prefix}logoicon
┃ ➜ ${prefix}numero-dono
┃ ➜ ${prefix}setprefix
┃ ➜ ${prefix}listagp
┃ ➜ ${prefix}antipalavrão
┃ ➜ ${prefix}antiligar
┃ ➜ ${prefix}antipv
┃ ➜ ${prefix}so_adm
┃ ➜ ${prefix}boton
┃ ➜ ${prefix}botoff
┃ ➜ ${prefix}visualizarmsg
┃ ➜ ${prefix}ausente
┃ ➜ ${prefix}ativo
┃ ➜ ${prefix}addvip
┃ ➜ ${prefix}delvip
┃ ➜ ${prefix}viplist
┃ ➜ ${prefix}savegp
┃ ➜ ${prefix}lista-aluguel
┃ ➜ ${prefix}calendario
┃ ➜ ${prefix}iddogrupo
┃ ➜ ${prefix}verificado-global
┃ ➜ ${prefix}configurar-bot
┃ ➜ ${prefix}addaluguel
┃ ➜ ${prefix}modoaluguel
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`;
};

exports.brincadeiras = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}
┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}
┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}
┃ ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎: ${prefix}
┃ 📦 𝐁𝐀𝐈𝐋𝐄𝐘𝐒: ${(() => { try { return require("zapo-js/package.json").version; } catch { return "-"; } })()}
┃ ⏳ 𝐔𝐏𝐓𝐈𝐌𝐄: ${(() => { const u = process.uptime(); return Math.floor(u / 3600) + "h " + Math.floor((u % 3600) / 60) + "m " + Math.floor(u % 60) + "s"; })()}
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗕𝗿𝗶𝗻𝗰𝗮𝗱𝗲𝗶𝗿𝗮𝘀 𝗾𝘂𝗲 𝗲𝘂 𝗮𝗺𝗼
┃ ➜ ${prefix}feio
┃ ➜ ${prefix}carinho
┃ ➜ ${prefix}fiel
┃ ➜ ${prefix}infiel
┃ ➜ ${prefix}vesgo
┃ ➜ ${prefix}bebado
┃ ➜ ${prefix}gostoso
┃ ➜ ${prefix}gostosa
┃ ➜ ${prefix}sigma
┃ ➜ ${prefix}beta
┃ ➜ ${prefix}baiano
┃ ➜ ${prefix}baiana
┃ ➜ ${prefix}carioca
┃ ➜ ${prefix}louco
┃ ➜ ${prefix}louca
┃ ➜ ${prefix}safada
┃ ➜ ${prefix}safado
┃ ➜ ${prefix}macaco
┃ ➜ ${prefix}macaca
┃ ➜ ${prefix}puta
┃ ➜ ${prefix}matar
┃ ➜ ${prefix}tapa
┃ ➜ ${prefix}chute
┃ ➜ ${prefix}dogolpe
┃ ➜ ${prefix}nazista
┃ ➜ ${prefix}chance
┃ ➜ ${prefix}surubao
┃ ➜ ${prefix}quando
┃ ➜ ${prefix}mencionar
┃ ➜ ${prefix}death
┃ ➜ ${prefix}corno
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗥𝗮𝗻𝗸𝗶𝗻𝗴𝘀 𝗽𝗶𝗰𝗮𝗻𝘁𝗲𝘀
┃ ➜ ${prefix}rankgays
┃ ➜ ${prefix}rankfieis
┃ ➜ ${prefix}rankinfieis
┃ ➜ ${prefix}rankgados
┃ ➜ ${prefix}rankcornos
┃ ➜ ${prefix}suruba
┃ ➜ ${prefix}rankgostosos
┃ ➜ ${prefix}rankgostosas
┃ ➜ ${prefix}ranknazistas
┃ ➜ ${prefix}rankotaku
┃ ➜ ${prefix}ranksigmas
┃ ➜ ${prefix}rankbetas
┃ ➜ ${prefix}rankbaianos
┃ ➜ ${prefix}rankbaianas
┃ ➜ ${prefix}rankcariocas
┃ ➜ ${prefix}rankloucos
┃ ➜ ${prefix}rankloucas
┃ ➜ ${prefix}ranksafadas
┃ ➜ ${prefix}ranksafados
┃ ➜ ${prefix}rankmacacos
┃ ➜ ${prefix}rankmacacas
┃ ➜ ${prefix}rankputas
┃ ➜ ${prefix}rankgado
┃ ➜ ${prefix}rankcorno
┃ ➜ ${prefix}rankgostoso
┃ ➜ ${prefix}rankgostosa
┃ ➜ ${prefix}ranknazista
┃ ➜ ${prefix}rankotakus
┃ ➜ ${prefix}rankpau
┃ ➜ ${prefix}ranksigma
┃ ➜ ${prefix}rankbeta
┃ ➜ ${prefix}rankbaiano
┃ ➜ ${prefix}rankbaiana
┃ ➜ ${prefix}rankcarioca
┃ ➜ ${prefix}ranksafado
┃ ➜ ${prefix}ranksafada
┃ ➜ ${prefix}ranklouco
┃ ➜ ${prefix}ranklouca
┃ ➜ ${prefix}rankmacaco
┃ ➜ ${prefix}rankmacaca
┃ ➜ ${prefix}rankputa
┃ ➜ ${prefix}rankfiel
┃ ➜ ${prefix}rankinfiel
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`;
};

exports.menuanimes = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 👤 𝐔𝐒𝐔𝐀́𝐑𝐈𝐎: @${pushname}
┃ 👑 𝐂𝐀𝐑𝐆𝐎: ${isCargo}
┃ 🕒 𝐇𝐎𝐑𝐀: ${hora()}
┃ ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎: ${prefix}
┃ 📦 𝐁𝐀𝐈𝐋𝐄𝐘𝐒: ${(() => { try { return require("zapo-js/package.json").version; } catch { return "-"; } })()}
┃ ⏳ 𝐔𝐏𝐓𝐈𝐌𝐄: ${(() => { const u = process.uptime(); return Math.floor(u / 3600) + "h " + Math.floor((u % 3600) / 60) + "m " + Math.floor(u % 60) + "s"; })()}
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗜𝗺𝗮𝗴𝗲𝗻𝘀 𝗱𝗲 𝗮𝗻𝗶𝗺𝗲
┃ ➜ ${prefix}akira
┃ ➜ ${prefix}akiyama
┃ ➜ ${prefix}ana
┃ ➜ ${prefix}asuna
┃ ➜ ${prefix}ayuzawa
┃ ➜ ${prefix}boruto
┃ ➜ ${prefix}chiho
┃ ➜ ${prefix}chitoge
┃ ➜ ${prefix}cogan
┃ ➜ ${prefix}cogan2
┃ ➜ ${prefix}deidara
┃ ➜ ${prefix}doraemon
┃ ➜ ${prefix}eba
┃ ➜ ${prefix}elaina
┃ ➜ ${prefix}emilia
┃ ➜ ${prefix}erza
┃ ➜ ${prefix}gremory
┃ ➜ ${prefix}hestia
┃ ➜ ${prefix}hinata
┃ ➜ ${prefix}inori
┃ ➜ ${prefix}islamic
┃ ➜ ${prefix}isuzu
┃ ➜ ${prefix}itachi
┃ ➜ ${prefix}itori
┃ ➜ ${prefix}kaga
┃ ➜ ${prefix}kagura
┃ ➜ ${prefix}kakasih
┃ ➜ ${prefix}kaori
┃ ➜ ${prefix}kartun
┃ ➜ ${prefix}katakata
┃ ➜ ${prefix}keneki
┃ ➜ ${prefix}kotori
┃ ➜ ${prefix}kurumi
┃ ➜ ${prefix}madara
┃ ➜ ${prefix}megumin
┃ ➜ ${prefix}mikasa
┃ ➜ ${prefix}miku
┃ ➜ ${prefix}minato
┃ ➜ ${prefix}mountain
┃ ➜ ${prefix}naruto
┃ ➜ ${prefix}nekonime
┃ ➜ ${prefix}nezuko
┃ ➜ ${prefix}onepiece
┃ ➜ ${prefix}pokemon
┃ ➜ ${prefix}programming
┃ ➜ ${prefix}rize
┃ ➜ ${prefix}sagiri
┃ ➜ ${prefix}sakura
┃ ➜ ${prefix}sasuke
┃ ➜ ${prefix}shina
┃ ➜ ${prefix}shinka
┃ ➜ ${prefix}shinomiya
┃ ➜ ${prefix}shizuka
┃ ➜ ${prefix}tejina
┃ ➜ ${prefix}toukachan
┃ ➜ ${prefix}tsunade
┃ ➜ ${prefix}waifu
┃ ➜ ${prefix}wallhp2
┃ ➜ ${prefix}yotsuba
┃ ➜ ${prefix}yuki
┃ ➜ ${prefix}yumeko
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛
┏╾━𖤐━╼〔🦇〕╾━𖤐━╼┓
┃ 𝗜𝗺𝗮𝗴𝗲𝗻𝘀 𝗽𝗿𝗮 𝗿𝗶𝗿
┃ ➜ ${prefix}aesthetic
┃ ➜ ${prefix}anjing
┃ ➜ ${prefix}blackpink
┃ ➜ ${prefix}boneka
┃ ➜ ${prefix}cecan
┃ ➜ ${prefix}cosplay
┃ ➜ ${prefix}dadu
┃ ➜ ${prefix}hekel
┃ ➜ ${prefix}justina
┃ ➜ ${prefix}kayes
┃ ➜ ${prefix}kpop
┃ ➜ ${prefix}kucing
┃ ➜ ${prefix}mobil
┃ ➜ ${prefix}montor
┃ ➜ ${prefix}notnot
┃ ➜ ${prefix}profil
┃ ➜ ${prefix}pubg
┃ ➜ ${prefix}rose
┃ ➜ ${prefix}ryujin
┃ ➜ ${prefix}wallhp
┃ ➜ ${prefix}wallml
┗╾━𖤐━╼〔🦇〕╾━𖤐━╼┛`;
};
exports.menulogos = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
const lista = require("../logos-yuta.json").map((l) => `│ 🖤 → ${prefix}${l[0]} (texto)`).join("\n");
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🤍 𝗟𝗼𝗴𝗼𝘀 𝗰𝗼𝗺 𝗲𝘀𝘁𝗶𝗹𝗼 🖤
╰════════════════╯
╭════════════════╮
${lista}
╰════════════════╯`;
};
