#!/bin/bash
# Uso: bash fundo-welcome.sh /sdcard/Download/welcome.png
cd ~/Bot-Base || exit 1
ARQ="${1:-$HOME/Bot-Base/arquivos/media/welcome/fundo.png}"
[ -f "$ARQ" ] || { echo "Arquivo nao encontrado: $ARQ"; exit 1; }
UA="Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"
URL=""
tenta() { case "$1" in https://*) URL="$1";; esac; }
tenta "$(curl -s -A "$UA" -F "reqtype=fileupload" -F "fileToUpload=@$ARQ" https://catbox.moe/user/api.php | tr -d '\r\n ')"
[ -z "$URL" ] && tenta "$(curl -s -A "$UA" -F "file=@$ARQ" https://0x0.st | tr -d '\r\n ')"
[ -z "$URL" ] && tenta "$(curl -s -A "$UA" -F "files[]=@$ARQ" "https://uguu.se/upload?output=text" | tr -d '\r\n ')"
[ -z "$URL" ] && { echo "Nenhum site aceitou o upload. Use um link direto da imagem (ver instrucao)."; exit 1; }
node -e '
const fs=require("fs");const p="settings/links_img.json";
const d=JSON.parse(fs.readFileSync(p,"utf8"));d.fundo_welcome=process.argv[1];
fs.writeFileSync(p,JSON.stringify(d,null,2));console.log("fundo_welcome =",process.argv[1]);' "$URL"
